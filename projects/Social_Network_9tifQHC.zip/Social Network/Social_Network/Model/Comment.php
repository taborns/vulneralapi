<?php
class Comment {
    private $_Database = null;
    private $_User = null;

    public function __construct() {
        $this->_Database = Database::getInstance();
        $this->_User = new User();
    }

    public function getAllGroupPostComments($Post_ID) {
        $this->_Database->get("Group_Post_Comments", array("Post_ID", "=", $Post_ID));

        $_Comments = array();

        foreach ($this->_Database->result() as $Comment) {
            $_Comments[] = array(
                "User_ID" => htmlentities($this->_User->getUsername($Comment->User_ID)),
                "Post_Id" => htmlentities($Comment->Post_ID),
                "Date" => $Comment->Date,
                "Comment" => htmlentities($Comment->Comment)
            );
        }

        return $_Comments;
    }

    public function addGroupComment($Post_ID, $User_ID, $Comment) {
        $this->_Database->insert("Group_Post_Comments", array(
            "User_ID" => $User_ID,
            "Post_ID" => $Post_ID,
            "Date" => date("Y-m-d H:i:s"),
            "Comment" => $Comment
        ));
    }

    public function getAllPostComments($Post_ID) {
        $this->_Database->get("Comments", array("Post_ID", "=", $Post_ID));

        $_Comments = array();

        foreach ($this->_Database->result() as $Comment) {
            $_Comments[] = array(
                "User_ID" => htmlentities($this->_User->getUsername($Comment->User_ID)),
                "Post_Id" => htmlentities($Comment->Post_ID),
                "Date" => $Comment->Date,
                "Comment" => htmlentities($Comment->Comment)
            );
        }

        return $_Comments;
    }

    public function addPostComment($Post_ID, $User_ID, $Comment) {
        $this->_Database->insert("Comments", array(
            "User_ID" => $User_ID,
            "Post_ID" => $Post_ID,
            "Date" => date("Y-m-d H:i:s"),
            "Comment" => $Comment
        ));
    }
}
 ?>
