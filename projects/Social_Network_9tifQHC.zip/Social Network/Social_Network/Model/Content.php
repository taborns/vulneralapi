<?php
class Content {

    public static function getMessagePanel($User_ID, $Username, $Message, $Date, $Type, $Seen) {
        $Username = ($Type != "Sender") ? "You" : $Username;
        $Message = ($Seen == false) ? "<b> $Message </b> ":  $Message;
        $link = ($Username == "You") ? Link::get("Profile.php") :Link::get("User.php?ID={$User_ID}");

        return "<li class = 'list-group-item Message_Panel'> <a href = '".htmlentities($link)."' title = '".htmlentities($Username)."'> <span class = 'glyphicon glyphicon-user'> </span> {$Username} </a> <span class = 'text-success glyphicon glyphicon-dashboard'> </span> {$Date} <p class = 'text-muted'> <span class = 'glyphicon glyphicon-envelope'> </span>  {$Message} </p> </li>";
    }

    public static function getMessageGroupPanel($User_ID, $Name, $Last_Message, $Date, $Seen) {
        $link = Link::get("Message.php?ID={$User_ID}");
        $Message = ($Seen == false) ? "<b> $Last_Message </b> ": $Last_Message;
        return "<a class = 'list-group-item Message_Item' href = '".htmlentities($link)."'> <div class = 'MessageGroup'> <h4 class = 'text-primary'> <span class = 'glyphicon glyphicon-user'> </span> {$Name} </h4> <p class = 'text-muted'> <span class = 'glyphicon glyphicon-envelope'> </span>  {$Message}  <span class = 'text-success'> <span class = 'glyphicon glyphicon-dashboard'> </span> {$Date} </span> </p> </div> </a>";
    }

    public static function getNotificationItemRow($Notification_ID, $User_ID, $Notification) {
        $link = Link::get("Notifications.php");
        return "<tr> <td> <div class = 'row'> <div class = 'col-sm-10'> <a href = '".htmlentities($link)."'> <h5> </span> ".htmlentities($Notification)." </h5> </a> </div> <div class = 'col-sm-2'> <a href = '#' onclick = 'removeNotification({$Notification_ID}, {$User_ID})'> <span class = 'glyphicon glyphicon-remove'> </span> </a> </div> </div> </td> </tr>";
    }

    public static function getNotificationItemPanel($Notification_ID, $Notification ,$Date) {
        return "<tr> <td> <p class = 'text-primary'> {$Notification} </p> </td> <td> <p class = 'text-muted'> {$Date} </p> </td> </tr>";
    }
    public static function getGroupItemPanel($Group_ID, $Group_Name, $Group_Desription, $Number_of_Members) {
        $link = Link::get("Group.php?ID={$Group_ID}");
        return "<a href = '".htmlentities($link)."' class = 'list-group-item'> <h4> ".htmlentities($Group_Name)." (".htmlentities($Number_of_Members)." Members) </h4> ".htmlentities($Group_Desription)." <p> </p></a>";
    }

    public static function getFriendsItemPanel($Friend_ID, $Username, $Email) {
        $link = Link::get("User.php?ID={$Friend_ID}");
        return "<a href = '".htmlentities($link)."' class = 'list-group-item'> <div class = 'row'> <div class = 'col-sm-4'> <img src = '../../Images/boy-1.png'  alt = 'Profile Picture' width ='80' height = '80' class = 'img-thumbnail'> </div> <div class = 'col-sm-8'> <h3> ".htmlentities($Username) ." </h3> <div class = 'FriendsPanel'> <p> ".htmlentities($Email) ." </p> </div> </div> </div> </a>";
    }

    public static function getFriendRequestItemPanel($Friend_ID, $Username) {
        $link = Link::get("User.php?ID={$Friend_ID}");
        return "<a href = '".htmlentities($link)."' class = 'list-group-item'> <h5> ".htmlentities($Username) ." </h5> <button type = 'button' class = 'btn btn-primary'> <span class = 'glyphicon glyphicon-ok-sign'> </span> Accept Request </button> </a>";
    }

    public static function getFriendRequestItemRow($Friend_ID, $Username, $User_ID) {
        $link = Link::get("User.php?ID={$Friend_ID}");
        return "<tr id = '{$Friend_ID}_{$User_ID}_Requests'> <td> <a href = '".htmlentities($link)."' class = 'Accept_Request'> <h5> <span class = 'glyphicon glyphicon-user'> </span> ".htmlentities($Username) ." </h5> </td> <td> <button type = 'button' class = 'btn btn-primary btn-sm' onclick = 'acceptRequest({$Friend_ID}, {$User_ID})'> <span class = 'glyphicon glyphicon-ok-sign'> </span> Accept Request </button> </a> </td> </tr>";
    }

    public static function getGroupPostPanel($Post_ID, $Current_User_ID, $User_ID, $Username, $Date, $Message, $Likes, $Group_ID, $Comments) {
        $link = ($Username == "You") ? htmlentities(Link::get("Profile.php")) : htmlentities(Link::get("User.php?ID={$User_ID}"));

        $panel = "<div class = 'panel panel-default'>";
        $panel .= "<div class = 'panel-heading'>";
        $panel .= "<a href = '".htmlentities($link)."' title = '".htmlentities($Username)."'>".htmlentities($Username)."</a> <span class = 'sr-only' id = 'Post_ID'>".htmlentities($User_ID)."</span>";
        $panel .= "</div>";
        $panel .= "<div class = 'panel-body'>";
        $panel .= htmlentities($Message);
        $panel .= "</br> <small class = 'text text-primary'>".htmlentities($Date)."</small>";
        $panel .= "</div>";
        $panel .= "<div class = 'panel-footer'>";
        $panel .= "<div class = 'row'>";
        $panel .= "<div class = 'col-sm-3'>";
        $panel .= "<button class = 'btn btn-primary' onclick = 'addGroupPostLike({$Post_ID}, {$Current_User_ID},\"$Group_ID\")'> <span class = 'glyphicon glyphicon-hand-right'> </span> Likes <span class = 'badge' id = '{$Post_ID}_Likes'> ".htmlentities($Likes)." </span> </button>";
        $panel .= "</div>";
        $panel .= "<div class = 'col-sm-3'>";
        $panel .= "<button class = 'btn btn-primary' data-toggle = 'modal' data-target = '#{$Post_ID}_Comment_Modal'> <span class = 'glyphicon glyphicon-comment'> </span> Comments </button>";

        $panel .= "<div id = '{$Post_ID}_Comment_Modal' class = 'modal fade' role = 'dialog'>";
        $panel .= "<div class = 'modal-dialog'>";
        $panel .= "<div class = 'modal-content'>";
        $panel .= "<div class = 'modal-header'>";
        $panel .= "<button type = 'button' class = 'close' data-dismiss = 'modal'> &times; </button>";
        $panel .= "<h4 class = 'modal-title'> <span class = 'text-primary'> $Username </span> : $Message </h4>";
        $panel .= "</div>";
        $panel .= "<div class = 'modal-body'>";
        $panel .= self::getCommentBody($Comments, $Post_ID, $Current_User_ID);
        $panel .= "</div>";
        $panel .= "<div class = 'modal-footer'>";
        $panel .= " <button type = 'button' class = 'btn btn-default' data-dismiss='modal'>Close</button>";
        $panel .= "</div>";
        $panel .= "</div>";
        $panel .= "</div>";
        $panel .= "</div>";

        $panel .= "</div>";
        $panel .= "</div>";
        $panel .= "</div>";
        $panel .= "</div>";

        return $panel;
    }

    public static function getCommentBody($Comments, $Post_ID, $Current_User_ID) {
        $body = "";

        $body .= "<div class = 'form-group'>";
        $body .= "<label for = 'Comment_{$Post_ID}'> Add Comment: </label>";
        $body .= "<textarea class='form-control' rows='2' id='Comment_{$Post_ID}'></textarea>";
        $body .= "<button type = 'button' class = 'btn btn-primary' onclick = 'addComment({$Post_ID}, {$Current_User_ID})'> Comment </button>";
        $body .= "</div>";

        $body .= "<div id = 'Comments'>";
        $body .= "<ul class = 'list-group' id = '{$Post_ID}_Bar' >";

        if (count($Comments) > 0) {
            foreach ($Comments as $Comment) {
                $User = $Comment['User_ID'];
                $Comment = $Comment['Comment'];
                $body .= "<li class = 'list-group-item' id = 'Comments_Bar'> <h5 class = 'text-success'> <b> {$User} </b> <span class = 'text-muted'> Commented </span> </h5> <p> {$Comment} </p> </li>";
            }
        }
        else {
            $body .= "<li class = 'list-group-item'> <span class = 'text-danger'> No Comments </span> </li>";
        }

        $body .= "</ul>";
        $body .= "</div>";

        return $body;
    }

    public static function getPostPanel($User_ID, $Post_ID, $Text, $Date, $Like, $Poster_ID, $Username, $Comments, $Image) {
        $Username = ($User_ID == $Poster_ID) ? "You" : $Username ;
        $link = ($Username == "You") ? Link::get("Profile.php") : Link::get("User.php?ID={$User_ID}");

        $panel = "<div class = 'panel panel-default'>";
        $panel .= "<div class = 'panel-heading'>";
        $panel .= "<a href = '".htmlentities($link)."' title = '".htmlentities($Username)."'> ".htmlentities($Username)."</a>";
        $panel .= "</div>";
        $panel .= "<div class = 'panel-body'>";

        $panel .= Content::displayPostImages($Post_ID, $Image);

        $panel .= htmlentities($Text);
        $panel .= "</br> <small class = 'text text-primary'>". htmlentities($Date)."</small>";
        $panel .= "</div>";
        $panel .= "<div class = 'panel-footer'>";
        $panel .= "<div class = 'row'>";
        $panel .= "<div class = 'col-sm-3'>";
        $panel .= "<button class = 'btn btn-primary' onclick = 'addPostLike({$Post_ID}, {$User_ID})'> <span class = 'glyphicon glyphicon-hand-right'> </span> Likes <span class = 'badge' id = '{$Post_ID}_Likes'> ".htmlentities($Like)." </span> </button>";
        $panel .= "</div>";
        $panel .= "<div class = 'col-sm-3'>";
        $panel .= "<button class = 'btn btn-primary' data-toggle = 'modal' data-target = '#{$Post_ID}_Comment_Modal'> <span class = 'glyphicon glyphicon-comment'> </span> Comments </button>";
        $panel .= "<div id = '{$Post_ID}_Comment_Modal' class = 'modal fade' role = 'dialog'>";
        $panel .= "<div class = 'modal-dialog'>";
        $panel .= "<div class = 'modal-content'>";
        $panel .= "<div class = 'modal-header'>";
        $panel .= "<button type = 'button' class = 'close' data-dismiss = 'modal'> &times; </button>";
        $panel .= "<h4 class = 'modal-title'> <span class = 'text-primary'> $Username </span> : $Text </h4>";
        $panel .= "</div>";
        $panel .= "<div class = 'modal-body'>";
        $panel .= self::getPostCommentBody($Comments, $Post_ID, $User_ID);
        $panel .= "</div>";
        $panel .= "<div class = 'modal-footer'>";
        $panel .= " <button type = 'button' class = 'btn btn-default' data-dismiss='modal'>Close</button>";
        $panel .= "</div>";
        $panel .= "</div>";
        $panel .= "</div>";
        $panel .= "</div>";
        $panel .= "</div>";
        $panel .= "</div>";
        $panel .= "</div>";
        $panel .= "</div>";

        return $panel;

    }

    public static function displayPostImages($Post_ID, $Image_List) {
        $panel = "";
        if ($Image_List) {

            $panel .= "<div class = 'row'>";

            $Images = explode("*", $Image_List);

            $Size = Content::getImageSize($Images);

            foreach ($Images as $Item) {
                if ($Item) {
                    $panel .= "<div class = 'col-sm-".$Size."'>";
                    $panel .= "<a href = '".$Item."' title = 'Post' data-lightbox= '".$Post_ID."' class = 'thumbnail'>";
                    $panel .= "<img src = '". $Item."' title = 'Post' alt = 'Post'>";
                    $panel .= "</a>";
                    $panel .= "</div>";
                }

            }

            $panel .= "</div>";
        }

        return $panel;
    }

    public static function getImageSize($Images) {
        if (count($Images) == 2) {
            return 8;
        }
        else if (count($Images) == 3) {
            return 6;
        }
        else {
            return 4;
        }

    }

    public static function getPostCommentBody($Comments, $Post_ID, $User_ID) {
        $body = "";

        $body .= "<div class = 'form-group'>";
        $body .= "<label for = 'Comment_{$Post_ID}'> Add Comment: </label>";
        $body .= "<textarea class='form-control' rows='2' id='Comment_{$Post_ID}'></textarea>";
        $body .= "<button type = 'button' class = 'btn btn-primary' onclick = 'addComment({$Post_ID}, {$User_ID})'> Comment </button>";
        $body .= "</div>";

        $body .= "<div id = 'Comments'>";
        $body .= "<ul class = 'list-group' id = '{$Post_ID}_Bar' >";

        if (count($Comments) > 0) {
            foreach ($Comments as $Comment) {
                $User = $Comment['User_ID'];
                $Comment = $Comment['Comment'];
                $body .= "<li class = 'list-group-item' id = 'Comments_Bar'> <h5 class = 'text-success'> <b> {$User} </b> <span class = 'text-muted'> Commented </span> </h5> <p> {$Comment} </p> </li>";
            }
        }
        else {
            $body .= "<li class = 'list-group-item'> <span class = 'text-danger'> No Comments </span> </li>";
        }

        $body .= "</ul>";
        $body .= "</div>";

        return $body;
    }

    public static function getAlbumPanel($Album_Name, $Username, $User_ID) {

        $_Album = ($Album_Name == "") ? "Uploads" : $Album_Name;
        $_Type = ($Album_Name == "") ? "in" : " ";
        $_Album_Link = Content::getLinks($_Album);

        $_Directory = ($Album_Name == "") ? "../../Images/Users/{$Username}/" : "../../Images/Users/{$Username}/Albums/{$Album_Name}/";

        $Panel = "<div class = 'panel panel-default'>";
        $Panel .= "<div class = 'panel-heading'>";
        $Panel .= "<h4 class = 'panel-title'>";
        $Panel .= "<a data-toggle = 'collapse' data-parent = '#accordion' href = '#".$_Album_Link."'> {$_Album} </a>";
        $Panel .= "</h4>";
        $Panel .= "</div>";
        $Panel .= "<div id = '".$_Album_Link."' class = 'panel-collapse collapse ".$_Type."'>";
        $Panel .= "<div class = 'panel-body Images'>";

        $Panel .= Content::getImages(scandir($_Directory), $_Directory, $User_ID, $_Album_Link);

        $Panel .= "</div>";
        $Panel .= "</div>";
        $Panel .= "</div>";

        return $Panel;
    }

    public static function getImages($Files, $Directory, $User_ID, $Album_Name) {
        $_Images = array();
        $_Array = array("jpg", "png");

        if (count($Files) > 0) {
            foreach ($Files as $File) {
                $filename = explode(".", $File);
                if (count($filename) == 2) {
                    if (in_array($filename[1], $_Array)) {
                        $_Images[] = $File;
                    }
                }
            }
        }
        if (count($_Images) == 0) {
            return "<div class = 'alert alert-danger'> <strong> Empty : </strong> No Image ! </div>";
        }

        return Content::displayImages($_Images, $Directory, $User_ID, $Album_Name);;
    }

    public static function displayImages($_Images, $_Directory, $User_ID, $Album_Name) {
        $output = "";
        foreach ($_Images as $Image) {

            $output .= Content::displayImage($Image, $_Directory, $User_ID, $Album_Name);
        }
        return $output;
    }

    public static function displayImage($_Image, $_Directory, $User_ID, $Album_Name) {
        $File = $_Directory . $_Image;
        $Image = "<div class = 'col-sm-6'>";
        $Image .= "<a href = '" . $File . "' data-lightbox = '". $Album_Name ."' class = 'thumbnail'>";
        $Image .= "<img src = '" . $File . "' title = 'Images' alt = 'Images' width = '200' height = '200' class = 'img-thumbnail'>";
        $Image .= "</a>";
        $Image .= "<button type = 'button' class = 'Delete btn btn-primary col-sm-12' onclick = 'deleteImage(event,\"$File\", $User_ID)'> <span class = 'glyphicon glyphicon-trash'> </span> Delete </button>";
        $Image .= "</div>";
        return $Image;
    }

    public static function getLinks($Link) {
        return str_replace(" ", "_", $Link);
    }

    //Profile Picture Change Panels

    public static function getAlbumPanelForProfileChanger($Album_Name, $Username, $User_ID) {

        $_Album = ($Album_Name == "") ? "Uploads" : $Album_Name;
        $_Album_Link = Content::getLinks($_Album);

        $_Directory = ($Album_Name == "") ? "../../Images/Users/{$Username}/" : "../../Images/Users/{$Username}/Albums/{$Album_Name}/";

        $Panel = "<div class = 'panel panel-default'>";
        $Panel .= "<div class = 'panel-heading'>";
        $Panel .= "<h4 class = 'panel-title'>";
        $Panel .= "<a data-toggle = 'collapse' data-parent = '#accordion' href = '#".$_Album_Link."'> {$_Album} </a>";
        $Panel .= "</h4>";
        $Panel .= "</div>";
        $Panel .= "<div id = '".$_Album_Link."' class = 'panel-collapse collapse'>";
        $Panel .= "<div class = 'panel-body Images'>";

        $Panel .= Content::getImagesForProfileChanger(scandir($_Directory), $_Directory, $User_ID, $_Album_Link);

        $Panel .= "</div>";
        $Panel .= "</div>";
        $Panel .= "</div>";

        return $Panel;
    }

    public static function getImagesForProfileChanger($Files, $Directory, $User_ID, $Album_Name) {
        $_Images = array();
        $_Array = array("jpg", "png");

        if (count($Files) > 0) {
            foreach ($Files as $File) {
                $filename = explode(".", $File);
                if (count($filename) == 2) {
                    if (in_array($filename[1], $_Array)) {
                        $_Images[] = $File;
                    }
                }
            }
        }
        if (count($_Images) == 0) {
            return "<div class = 'alert alert-danger'> <strong> Empty : </strong> No Image ! </div>";
        }

        return Content::displayImagesForProfileChanger($_Images, $Directory, $User_ID, $Album_Name);;
    }

    public static function displayImagesForProfileChanger($_Images, $_Directory, $User_ID, $Album_Name) {
        $output = "";
        foreach ($_Images as $Image) {

            $output .= Content::displayImageForProfileChanger($Image, $_Directory, $User_ID, $Album_Name);
        }
        return $output;
    }

    public static function displayImageForProfileChanger($_Image, $_Directory, $User_ID, $Album_Name) {
        $user = new User();
        $File = $_Directory . $_Image;
        $Disable = ($user->isMyProfilePicture($User_ID, $File)) ?  "disabled" : "" ;

        $Image = "<div class = 'col-sm-4'>";
        $Image .= "<a href = '" . $File . "' data-lightbox = '". $Album_Name ."' class = 'thumbnail'>";
        $Image .= "<img src = '" . $File . "' title = 'Images' alt = 'Images' width = '200' height = '200' class = 'img-thumbnail'>";
        $Image .= "</a>";

        $Image .= "<button type = 'button' class = 'Delete btn btn-primary col-sm-12' onclick = 'setProfilePicture(event,\"$File\", $User_ID)' {$Disable}> <span class = 'glyphicon glyphicon-trash'> </span> Set Profile Picture </button>";
        $Image .= "</div>";
        return $Image;
    }

}
?>
