<?php

class Message {
    private $_Database;
    private $_Message_Data;

    public function __construct() {
        $this->_Database = Database::getInstance();
    }
    public function sendMessage($Sender_ID, $Reciever_ID, $Message) {
        $this->_Database->insert("Messages", array(
            "Sender_ID" => $Sender_ID,
            "Reciever_ID" => $Reciever_ID,
            "Message" => $Message,
            "Date" => date("Y-m-d H:i:s"),
            "Seen" => 0
        ));
    }

    public function getMessages($userID) {
        if ($userID) {
            $result = $this->_Database->get("Messages", array("User_ID", "=", $userID));
            $this->_Message_Data = $result->result();
        }
    }
    public function getMessageGroups($User_ID) {
        $sql = "SELECT DISTINCT `Sender_ID`, `Reciever_ID` FROM `Messages` WHERE `Reciever_ID` = ? OR `Sender_ID` = ?";

        $_Result = array();
        $_Message_Groups = array();

        $this->_Database->query($sql, array($User_ID, $User_ID));
        foreach ($this->_Database->result() as $Recievers) {
            if ($Recievers->Reciever_ID != $User_ID) {
                $_Result[] = array("Friend" => $Recievers->Reciever_ID);
            }
            else if ($Recievers->Sender_ID != $User_ID) {
                $_Result[] = array("Friend" => $Recievers->Sender_ID);
            }

        }

        foreach ($_Result as $Group) {
            if (!in_array($Group["Friend"], $_Message_Groups)) {
                $_Message_Groups[] = $Group["Friend"];
            }
        }

        return $_Message_Groups;
    }

    public function getUnreadMessageNumber($User_ID) {
        $this->_Database->get("Messages", array("Reciever_ID", "=", $User_ID, "Seen", "=", false));
        return $this->_Database->count();
    }

    public function getLastMessage($Sender_ID, $Reciever_ID) {
        $sql = "SELECT * FROM `Messages` WHERE (`Sender_ID` = ? AND `Reciever_ID` = ?) OR (`Sender_ID` = ? AND `Reciever_ID` = ?)";
        $this->_Database->query($sql, array($Sender_ID, $Reciever_ID, $Reciever_ID, $Sender_ID));

        $Number_Of_Result = $this->_Database->count();
        return array("Message" => $this->_Database->result()[$Number_Of_Result - 1]->Message, "Date" => $this->_Database->result()[$Number_Of_Result - 1]->Date, "Seen" => $this->_Database->result()[$Number_Of_Result - 1]->Seen);
    }

    public function getAllConversation($User_ID, $Other_User) {
        $sql = "SELECT * FROM `Messages` WHERE (`Sender_ID` = ? AND `Reciever_ID` = ?) OR (`Sender_ID` = ? AND `Reciever_ID` = ?)";
        $this->_Database->query($sql, array($User_ID, $Other_User, $Other_User, $User_ID));

        $_ALL_Message = array();

        foreach ($this->_Database->result() as $Message) {
            $Type = ($Message->Sender_ID == $User_ID) ? "Reciever" : "Sender" ;
            $_ALL_Message[] = array(
                "Type" => $Type,
                "Message" => $Message->Message,
                "Date" => $Message->Date,
                "Seen" => $Message->Seen
            );
        }

        return $_ALL_Message;
    }

    public function setConversationMessageSeen($Sender_ID, $Reciever_ID) {
        $sql = "UPDATE `Messages` SET `Seen` = ? WHERE `Sender_ID` = ? AND `Reciever_ID` = ?";
        $this->_Database->query($sql, array(1, $Reciever_ID, $Sender_ID));
    }
}
?>
