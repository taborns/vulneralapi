<?php
class Hash {
	public static function make($String, $Salt = "") {
		return hash("sha256", $String.$Salt);
	}
	
	public static function salt($length) {
		return mcrypt_create_iv($length);
	}
	
	public static function unique() {
		return self::make(uniqid());
	}	
}
?>
