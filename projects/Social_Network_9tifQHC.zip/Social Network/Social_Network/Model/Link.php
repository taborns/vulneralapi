<?php
class Link {
    private static $location = array(
        "Profile.php" => "/View/User/Profile.php",
        "AddGroup.php" => "/View/Group/AddGroup.php",
        "GroupList.php" => "/View/Group/GroupList.php",
        "ChangePassword.php" => "/View/User/ChangePassword.php",
        "EditProfile.php" => "/View/User/EditProfile.php",
        "Index.php"  => "/View/User/Index.php",
        "Login.php"  => "/View/Login.php",
        "Logout.php"  => "/View/Logout.php",
        "Register.php"  => "/View/User/Register.php",
        "Group.php" => "/View/Group/Group.php",
        "User.php" => "/View/User/User.php",
        "EditGroup.php" => "/View/Group/EditGroup.php",
        "JoinGroup.php" => "/View/Group/JoinGroup.php",
        "LeaveGroup.php" => "/View/Group/LeaveGroup.php",
        "FriendsList.php" => "/View/Friends/FriendsList.php",
        "Notifications.php" => "/View/Notifications/Notifications.php",
        "MessageList.php" => "/View/Message/MessageList.php",
        "Message.php" => "/View/Message/Message.php",
        "Pictures.php" => "/View/Pictures/Pictures.php",
        "ChangeProfilePicture.php" => "/View/User/ChangeProfilePicture.php"
    );

    public static function get($link) {
        try {
            $rootDirectory = Configuration::get("Directory/Root");
            if (strpos($link, "?")) {
                $array = explode("?", $link);
                $link = self::$location[$array[0]];
                $query = $array[1];

                $path = $rootDirectory . $link . "?" . $query;
                return $path;
            }
            else {

                $path = $rootDirectory . self::$location[$link];
                return $path;
            }

        }
        catch (Exception $e) {
            self::get("Index.php");
        }

    }
}

?>
