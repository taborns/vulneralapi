<?php
class Notification {
    private $_Database = null;

    public function __construct() {
        $this->_Database = Database::getInstance();
    }

    public function addNotification($User_ID, $Notification) {
        $this->_Database->insert("Notifications", array(
            "User_ID" => $User_ID,
            "Notification" => $Notification,
            "Date" => date("Y-m-d H:i:s"),
            "Seen" => 0
        ));
    }

    public function getNotifications($User_ID) {
        $this->_Database->get("Notifications", array("User_ID", "=", $User_ID, "Seen", "=", false));

        $_Notifications = array();

        foreach ($this->_Database->result() as $Notification) {
            $_Notifications[] = array(
                "Notification_ID" => htmlentities($Notification->Notification_ID),
                "Notification_ID" => htmlentities($Notification->Notification_ID),
                "User_ID" => htmlentities($Notification->User_ID),
                "Notification" => htmlentities($Notification->Notification),
                "Date" => htmlentities($Notification->Date)
            );
        }

        return $_Notifications;
    }

    public function getAllNotifications($User_ID) {
        $this->_Database->get("Notifications", array("User_ID", "=", $User_ID));

        $_Notifications = array();

        foreach ($this->_Database->result() as $Notification) {
            $_Notifications[] = array(
                "Notification_ID" => htmlentities($Notification->Notification_ID),
                "User_ID" => htmlentities($Notification->User_ID),
                "Notification" => htmlentities($Notification->Notification),
                "Date" => htmlentities($Notification->Date)
            );
        }

        return $_Notifications;
    }

    public function removeNotification($Notification_ID) {
        $this->_Database->delete("Notifications", array("Notification_ID", "=", $Notification_ID));
    }

    public function markRead($Notification_ID) {
        $this->_Database->update("Notifications", $Notification_ID , array("Seen" => true));
    }

    public function getNotificationsNumber($User_ID) {
        return count($this->getNotifications($User_ID));
    }

    public function clearNotification($User_ID) {
        $this->_Database->update("Notifications", array("Seen", "=", true));
    }
}
?>
