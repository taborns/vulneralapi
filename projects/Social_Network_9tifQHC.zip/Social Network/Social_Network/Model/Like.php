<?php

class Like {
    private $_Database = null;

    public function __construct() {
        $this->_Database = Database::getInstance();
    }
    public function addLike($Post_ID, $User_ID) {
        if (!$this->hasLiked($Post_ID, $User_ID)) {
            $this->_Database->get("Posts", array("Post_ID", "=", $Post_ID));
            $result = $this->_Database->first_result();
            $likes = $result->Likes + 1;

            $time = date("Y-m-d H:i:s");
            $this->_Database->update("Posts", $Post_ID, array("Likes" => $likes));
            $this->_Database->insert("Likes", array(
                "Post_ID" => $Post_ID,
                "User_ID" => $User_ID,
                "Time" => $time
            ));
        }
    }

    public function getNumberOfLikes($Post_ID) {
        if ($Post_ID) {
            $this->_Database->get("Posts", array("Post_ID", "=", $Post_ID));
            $result = $this->_Database->first_result();
            return $result->Likes;
        }

        return false;
    }

    public function hasLiked($Post_ID, $User_ID) {
        $this->_Database->get("Likes", array(
            "User_ID", "=", $User_ID,
            "Post_ID", "=", $Post_ID
        ));

        if ($this->_Database->count() > 0) {
            return true;
        }
        return false;
    }
}
?>
