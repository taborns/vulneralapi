<?php

class Database {
	private static $_Instance = null;
	private $_PDO, $_Query, $_Error = false, $_Results, $_Count = 0;

	public function __construct() {
		try {
			$this->_PDO = new PDO("mysql:host=" . Configuration::get("MySQL/Host") . ";dbname=". Configuration::get("MySQL/Database"), Configuration::get("MySQL/Username"), Configuration::get("MySQL/Password"));
		}
		catch (PDOException $exeption) {
			die($exception->getMessage());
		}
	}

	public static function getInstance() {
		if (!isset(self::$_Instance)) {
			self::$_Instance = new Database();
		}

		return self::$_Instance;
	}

	public function query($sql, $parameters = array()) {
		$this->_Error = false;
		$counter = 1;

		if ($this->_Query = $this->_PDO->prepare($sql)) {
			if (count($parameters)) {
				foreach ($parameters as $parameter) {
					$this->_Query->bindValue($counter, $parameter);
					$counter++;
				}
			}

			if ($this->_Query->execute()) {
				$this->_Results = $this->_Query->fetchAll(PDO::FETCH_OBJ);
				$this->_Count = $this->_Query->rowCount();
			}

			else {
				echo $this->_Query->errorInfo()[2];
				$this->_Error = true;
			}
		}
		return $this;
	}

	public function action($action, $table, $where = array()) {
		if (count($where) === 3) {
			$operators = array("=", "<", ">", ">=", "<=");

			$field = $where[0];
			$operator = $where[1];
			$value = $where[2];

			if (in_array($operator, $operators)) {
				$sql = "{$action} FROM {$table} WHERE {$field} {$operator} ?";

				if (!$this->query($sql, array($value))->error()) {
					return $this;
				}
				else {
					return $this;
				}
			}
		}

		else if (count($where) === 6) {
			$operators = array("=", "<", ">", ">=", "<=");

			$field_One = $where[0];
			$field_Two = $where[3];
			$operator_One = $where[1];
			$operator_Two = $where[4];
			$value_One = $where[2];
			$value_Two = $where[5];

			if (in_array($operator_One, $operators) && in_array($operator_Two, $operators)) {
				$sql = "{$action} FROM {$table} WHERE {$field_One} {$operator_One} ? AND {$field_Two} {$operator_Two} ?";
				if (!$this->query($sql, array($value_One, $value_Two))->error()) {
					return $this;
				}
				else {
					return $this;
				}
			}
		}

		else if (count($where) == 9) {
			$operators = array("=", "<", ">", ">=", "<=");

			$field_One = $where[0];
			$field_Two = $where[3];
			$field_Three = $where[6];
			$operator_One = $where[1];
			$operator_Two = $where[4];
			$operator_Three = $where[7];
			$value_One = $where[2];
			$value_Two = $where[5];
			$value_Three = $where[8];

			if (in_array($operator_One, $operators) && in_array($operator_Two, $operators) && in_array($operator_Three, $operators)) {
				$sql = "{$action} FROM {$table} WHERE {$field_One} {$operator_One} ? AND {$field_Two} {$operator_Two} ? AND {$field_Three} {$operator_Three} ?";
				if (!$this->query($sql, array($value_One, $value_Two, $value_Three))->error()) {
					return $this;
				}
				else {
					return $this;
				}
			}


		}
		return false;
	}

	public function get($table, $where) {
		return $this->action("SELECT * ", $table, $where);
	}

	public function getLimited($table, $field, $where) {
		return $this->action("SELECT LEFT(`{$field}`,10) as `{$field}`", $table, $where);
	}

	public function delete($table, $where) {
		return $this->action("DELETE", $table, $where);
	}

	public function insert($table, $fields){
		if (count($fields)) {
			$key = array_keys($fields);
			$values = "";
			$counter = 1;

			foreach($fields as $field) {
				$values .= "?";
				if ($counter < count($fields)) {
					$values .= ", ";
				}
				$counter++;
			}

			$sql = "INSERT INTO {$table} (`".implode('`, `', $key)."`) VALUES ({$values})";

			if (!($this->query($sql, $fields)->error())) {
				return true;
			}
		}
		return false;
	}

	public function update($table, $ID, $fields) {
		$set = "";
		$counter = 1;
		$ID_Row = array("Users" => "User_ID", "Posts" => "Post_ID", "Groups" => "Group_ID", "Notifications" => "Notification_ID");

		foreach ($fields as $name => $value) {
			$set .= "{$name} = ?";
			if ($counter < count($fields)) {
				$set .= ", ";
			}
			$counter++;
		}

		if (is_numeric($ID)) {
			$sql = "UPDATE {$table} SET {$set} WHERE {$ID_Row[$table]} = {$ID}";
		}
		else {
			$sql = "UPDATE {$table} SET {$set} WHERE {$ID_Row[$table]} = '{$ID}'";
		}

		if (!($this->query($sql, $fields)->error())) {
			return true;
		}
		return false;
	}

	public function error() {
		return $this->_Error;
	}

	public function count() {
		return $this->_Count;
	}

	public function result() {
		return $this->_Results;
	}

	public function first_result() {
		return $this->result()[0];
	}
}
