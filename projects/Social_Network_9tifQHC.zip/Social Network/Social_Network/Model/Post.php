<?php
class Post {
    private $_Database = null;
    private $_Friends = null;

    public function __construct() {
        $this->_Database = Database::getInstance();
        $this->_Friends = new Friend();
    }

    public function addPost($User_ID, $Text, $Likes, $Image = null) {
        $this->_Database->insert("Posts", array(
            "User_ID" => $User_ID,
            "Text" => $Text,
            "Image" => $Image,
            "Date" => date("Y-m-d H:i:s"),
            "Likes" => 0
        ));
    }

    public function getMyPosts($User_ID) {
        $_Posts = array();

        $sql = "SELECT * FROM `Posts` WHERE `User_ID` = ? ORDER BY `Date` DESC";
        $this->_Database->query($sql, array($User_ID));

        foreach ($this->_Database->result() as $Post) {
            $_Posts[] =  array(
                "Post_ID" => $Post->Post_ID,
                "User_ID" => $Post->User_ID,
                "Text" => $Post->Text,
                "Image" => $Post->Image,
                "Date" => $Post->Date,
                "Likes" => $Post->Likes
            );
        }

        return $_Posts;
    }

    public function getPostsOfUser($User_ID) {
        $_Posts = array();

        $sql = "SELECT `Posts`.`Post_ID`, `Posts`.`User_ID`, `Posts`.`Text`, `Posts`.`Image`, `Posts`.`Date`, `Posts`.`Likes`, `Friends`.`Friend_ID`";
        $sql .= "FROM `Posts`INNER JOIN `Friends` ";
        $sql .= "ON `Posts`.`User_ID` = `Friends`.`Friend_ID` ";
        $sql .= "WHERE `Friends`.`User_ID` = ?";
        $sql .= "ORDER BY `Posts`.`Date` DESC";

        $this->_Database->query($sql, array($User_ID));

        foreach ($this->_Database->result() as $Post) {
            $_Posts[] =  array(
                "Post_ID" => $Post->Post_ID,
                "User_ID" => $Post->User_ID,
                "Text" => $Post->Text,
                "Image" => $Post->Image,
                "Date" => $Post->Date,
                "Likes" => $Post->Likes,
                "Friend_ID" => $Post->Friend_ID
            );
        }

        return $_Posts;

    }
}
?>
