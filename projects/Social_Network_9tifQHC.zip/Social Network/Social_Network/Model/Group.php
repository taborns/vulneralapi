<?php
class Group {
    private $_Database;
    private $_Result = array();

    public function __construct () {
        $this->_Database = Database::getInstance();
    }

    public function create($fields = array()) {
        if (!$this->_Database->insert("Groups", $fields)) {
            throw new Exception("There was a problem creating a Group!");
        }
    }

    public function exists($Group_ID) {
        $this->_Database->get("Groups", array("Group_ID", "=", $Group_ID));
        if ($this->_Database->count() > 0) {
            return true;
        }
        return false;
    }

    public function update($Group_ID, $fields = array()) {
        $this->_Database->update("Groups", $Group_ID, $fields);
    }

    public function getUserGroups($User_ID) {
        $sql = "SELECT DISTINCT `Group_ID` FROM `Group_Members` WHERE `User_ID` = ?";
        $this->_Database->query($sql, array($User_ID));

        $_GroupIDList = array();
        $_GroupList = array();

        foreach ($this->_Database->result() as $GroupID) {
            $_GroupIDList[] = $GroupID->Group_ID;
        }

        foreach ($_GroupIDList as $Group) {
            $sql = "SELECT `Group_ID`,`Group_Name`,`Description`,`Number_of_Members` FROM `Groups` WHERE `Group_ID` = ? ORDER BY Number_of_Members";
            $this->_Database->query($sql, array($Group));

            foreach ($this->_Database->result() as $Group) {
                $_GroupList[] = $Group;
            }
        }

        return $_GroupList;

    }

    public function getGroupInformation($Group_ID) {
        $_Group_Name = $this->getGroupName($Group_ID);
        $_Group_Descritpion = $this->getGroupDescription($Group_ID);
        $_Group_Administrator = $this->getGroupAdministrator($Group_ID);
        $_Group_Date = $this->getGroupCreationDate($Group_ID);
        $_Group_Members = $this->getGroupMembers($Group_ID);
        $_Group_Member_Numbers = $this->getGroupMembersNumber($Group_ID);

        return array(
            "Group_Name" => $_Group_Name,
            "Group_Description" => $_Group_Descritpion,
            "Group_Administrator" => $_Group_Administrator,
            "Group_Date" => $_Group_Date,
            "Group_Members" => $_Group_Members,
            "Number_of_Members" => $_Group_Member_Numbers
        );
    }

    public function getGroupAdministrator($Group_ID) {
        $sql = "SELECT `Username` FROM `Users` WHERE `User_ID` = (SELECT `Administrator` FROM `Groups` WHERE `Group_ID` = ?)";
        $this->_Database->query($sql, array($Group_ID));

        return htmlentities($this->_Database->first_result()->Username);
    }

    public function getGroupDescription($Group_ID) {
        $this->_Database->get("Groups", array("Group_ID", "=", $Group_ID));
        return htmlentities($this->_Database->first_result()->Description);
    }

    public function getGroupName($Group_ID) {
        $this->_Database->get("Groups", array("Group_ID", "=", $Group_ID));
        return htmlentities($this->_Database->first_result()->Group_Name);
    }

    public function getGroupMembers($Group_ID) {
        $sql = "SELECT `User_ID` FROM `Group_Members` WHERE `Group_ID` = ?";
        $this->_Database->query($sql, array($Group_ID));

        $_User_ID_List = array();
        $_Group_Member_List = array();

        foreach ($this->_Database->result() as $User_ID) {
            $_User_ID_List[] = $User_ID->User_ID;
        }

        foreach ($_User_ID_List as $User) {
            $sql = "SELECT `First_Name`, `Last_Name` FROM `Users` WHERE `User_ID` = ?";
            $this->_Database->query($sql, array($User));

            $_Group_Member_List[] = htmlentities($this->_Database->first_result()->First_Name) . " " . htmlentities($this->_Database->first_result()->Last_Name);
        }
        return $_Group_Member_List;
    }

    public function getGroupMembersNumber($Group_ID) {
        $this->_Database->get("Groups", array("Group_ID", "=", $Group_ID));
        return htmlentities($this->_Database->first_result()->Number_of_Members);
    }

    public function getGroupCreationDate($Group_ID) {
        $this->_Database->get("Groups", array("Group_ID", "=", $Group_ID));
        return htmlentities($this->_Database->first_result()->Date);
    }


    public function getAllOtherGroups($User_ID) {
        $sql = "SELECT DISTINCT `Group_ID` FROM `Group_Members` WHERE `User_ID` != ?";
        $this->_Database->query($sql, array($User_ID));

        $_GroupIDList = array();
        $_GroupList = array();

        foreach ($this->_Database->result() as $GroupID) {
            $_GroupIDList[] = $GroupID->Group_ID;
        }

        foreach ($_GroupIDList as $Group) {
            $sql = "SELECT `Group_ID`,`Group_Name`,`Description`,`Number_of_Members` FROM `Groups` WHERE `Group_ID` = ?";
            $this->_Database->query($sql, array($Group));

            foreach ($this->_Database->result() as $Group) {
                if (!$this->hasMember($Group->Group_ID, $User_ID)) {
                    $_GroupList[] = $Group;
                }
            }
        }

        return $_GroupList;

    }
    public function hasMember($Group_ID, $User_ID) {
        $this->_Database->get("Group_Members", array("Group_ID", "=", $Group_ID, "User_ID", "=", $User_ID));
        if ($this->_Database->count() > 0) {
            return true;
        }
        return false;
    }

    public function getUserIDFromUsername($User_ID) {
        $this->_Database->get("Users", array("Username", "=", $User_ID));
        return htmlentities($this->_Database->first_result()->User_ID);
    }

    public function addPost($Group_ID, $User_ID, $Message) {
        try {
            $time = date("Y-m-d H:i:s");
            $this->_Database->insert("Group_Post", array(
                "Group_ID" => trim($Group_ID),
                "User_ID" => $this->getUserIDFromUsername(trim($User_ID)),
                "Date" =>$time,
                "Message" => trim($Message),
                "Likes" => 0
            ));
        }

        catch (Exception $e) {
            die();
        }

    }

    public function getGroupPosts($Group_ID) {
        $this->_Database->get("Group_Post", array("Group_ID", "=", $Group_ID));
        return $this->_Database->result();
    }

    public function getGroupPostsArray($Group_ID) {
        $_Posts = array();
        $this->_Database->get("Group_Post", array("Group_ID", "=", $Group_ID));

        foreach ($this->_Database->result() as $Post) {
            $_Posts[] = array(
                "Post_ID" => $Post->Post_ID,
                "Group_ID" => $Post->Group_ID,
                "User_ID" =>  $Post->User_ID,
                "Date" => $Post->Date,
                "Message" => $Post->Message,
                "Likes" => $Post->Likes
            );
        }

        return $_Posts;
    }

    public function getGroupPostLikes($Group_ID, $Post_ID) {
        $this->_Database->get("Group_Post", array("Group_ID", "=", $Group_ID, "Post_ID", "=", $Post_ID));
        return $this->_Database->first_result();
    }

    public function hasLiked($Group_ID, $User_ID, $Post_ID) {
        $this->_Database->get("Group_Likes", array(
            "User_ID", "=", $User_ID,
            "Post_ID", "=", $Post_ID
        ));

        if ($this->_Database->count() > 0) {
            return true;
        }
        return false;
    }

    public function addPostLike($Group_ID, $User_ID, $Post_ID) {
        if (!$this->hasLiked($Group_ID, $User_ID, $Post_ID)) {

            $_Result = $this->getGroupPostLikes($Group_ID, $Post_ID);
            $_Likes = (int)$_Result->Likes + 1;

            $sql = "UPDATE `Group_Post` SET `Likes` = ? WHERE `Group_ID` = ? AND `Post_ID` = ?";
            if ($this->_Database->query($sql, array($_Likes, $Group_ID, $Post_ID))) {
                $this->_Database->insert("Group_Likes", array(
                    "Post_ID" => $Post_ID,
                    "User_ID" => $User_ID,
                    "Group_ID" => $Group_ID
                ));
            }
        }

    }

    public function getMyGroupsNumber($User_ID) {
        return count($this->getUserGroups($User_ID));
    }
}
?>
