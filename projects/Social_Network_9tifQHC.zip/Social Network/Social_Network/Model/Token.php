<?php

class Token {
	public static function generateToken() {
		return Session::put(Configuration::get("Session/Token_Name"), sha1(uniqid()));
	}

	public static function checkToken($token) {
		$tokenName = Configuration::get("Session/Token_Name");

		if (Session::exists($tokenName) && $token == Session::get($tokenName)) {
			Session::delete($tokenName);
			return true;
		}

		return false;
	}
}

?>
