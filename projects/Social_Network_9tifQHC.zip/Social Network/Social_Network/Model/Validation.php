<?php

class Validation {
	private $_Passed = false;
	private $_Errors = array();
	private $_Database = null;
	private $_Items = array(
		"First_Name" => "First Name",
		"Last_Name" => "Last Name",
		"City" => "City",
		"Country" => "Country",
		"Birthday" => "Birthday",
		"Age" => "Age",
		"Username" => "Username",
		"Email" => "Email",
		"Password" => "Password",
		"Confirm_Password" => "Confirm Password",
		"New_Password" => "New Password",
		"Current_Password" => "Current Password",
		"Description" => "Description",
		"Gender" => "Gender",
		"Group_Name" => "Group Name"
	);

	public function __construct() {
		$this->_Database = Database::getInstance();
	}

	public function check($source, $items = array()) {
		try {
			foreach ($items as $item => $rules) {
				foreach ($rules as $rule => $rule_value) {

					$value = trim($source[$item]);

					$item = htmlentities($item, ENT_QUOTES, "UTF-8");

					if ($rule == "Required" && empty($value)) {
						$this->addError("{$this->_Items[$item]} Is Required!");
					}

					else if (!empty($value)) {
						switch ($rule) {
							case "Minimum":
								if (strlen($value) < $rule_value) {
									$this->addError("{$this->_Items[$item]} Must Be a Minimum Of {$rule_value} Characters!");
								}
								break;
							case "Maximum":
								if (strlen($value) > $rule_value) {
									$this->addError("{$this->_Items[$item]} Must Be a Maximum Of {$rule_value} Characters!");
								}
								break;
							case "Unique":
								$check = $this->_Database->get($rule_value, array($item, "=", $value));
								if ($check->count()) {
									$this->addError("{$this->_Items[$item]} Already Exists!");
								}
								break;
							case "Matches":
								if ($value != $source[$rule_value]) {
									$this->addError("{$this->_Items[$item]} Must Match {$this->_Items[$rule_value]}");
								}
								break;
						}
					}
				}
			}

			if (empty($this->_Errors)) {
				$this->_Passed = true;
			}

			return $this;
		}

		catch (Exception $e) {
			die();
		}

	}

	public function addError($error) {
		$this->_Errors[] = $error;
	}

	public function passed() {
		return $this->_Passed;
	}

	public function errors() {
		return $this->_Errors;
	}
}
?>
