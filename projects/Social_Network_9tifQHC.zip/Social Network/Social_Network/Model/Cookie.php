<?php

class Cookie {
	public static function exists($name) {
		return (isset($_COOKIE[$name])) ? true : false;
	}
	
	public static function get($name) {
		return $_SESSION[$name];
	}
	
	public static function put($name, $value, $expiry) {
		if (setcookie($name, $value, time() + $expiry)) {
			return true;
		}
		return false;
	}
	
	public static function delete($name) {
		self::put($name, null, time() - 3600);
	}
}
?>
