<?php
class Configuration {
    public static function get($path = null) {
        if ($path) {
            $path = explode("/", $path);

            $configuration = $GLOBALS["Configuration"];

            foreach ($path as $item) {
                if (isset($configuration[$item])) {
                    $configuration = $configuration[$item];
                }
            }
            return $configuration;
        }
        return false;
    }
}
?>
