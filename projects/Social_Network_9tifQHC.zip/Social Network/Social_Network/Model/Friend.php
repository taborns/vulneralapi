<?php
class Friend {
    private $_Database = null;

    public function __construct() {
        $this->_Database = Database::getInstance();
    }

    public function addFriendRequest($User_ID, $Friend_ID) {
        $this->_Database->insert("Friend_Request", array(
            "User_ID" => $User_ID,
            "Friend_ID" => $Friend_ID,
            "Date" => date("Y-m-d H:i:s")
        ));
    }

    public function acceptRequest($User_ID, $Friend_ID) {
        $this->_Database->delete("Friend_Request", array("User_ID", "=", $Friend_ID, "Friend_ID", "=", $User_ID));
        $this->_Database->insert("Friends", array(
            "User_ID" => $User_ID,
            "Friend_ID" => $Friend_ID,
            "Date" => date("Y-m-d H:i:s")
        ));
        $this->_Database->insert("Friends", array(
            "User_ID" => $Friend_ID,
            "Friend_ID" => $User_ID,
            "Date" => date("Y-m-d H:i:s")
        ));
    }

    public function getFriendRequests($User_ID) {
        $this->_Database->get("Friend_Request", array("Friend_ID", "=", $User_ID));

        $_Friend_Request_List = array();

        foreach ($this->_Database->result() as $Friend) {
            $this->_Database->get("Users", array("User_ID", "=", $Friend->User_ID));
            $_Friend_Request_List[] = array(
                "User_ID" => htmlentities($this->_Database->first_result()->User_ID),
                "Username" => htmlentities($this->_Database->first_result()->Username)
            );
        }

        return $_Friend_Request_List;
    }

    public function getFriendRequestsNumber($User_ID) {
        $this->_Database->get("Friend_Request", array("Friend_ID", "=", $User_ID));
        return $this->_Database->count();
    }

    public function getFriends($User_ID) {
        $this->_Database->get("Friends", array("User_ID", "=", $User_ID));

        $_Friend_List = array();

        foreach ($this->_Database->result() as $Friend) {
            $this->_Database->get("Users", array("User_ID", "=", $Friend->Friend_ID));
            $_Friend_List[] = array(
                "User_ID" => htmlentities($this->_Database->first_result()->User_ID),
                "Username" => htmlentities($this->_Database->first_result()->Username),
                "Email" => htmlentities($this->_Database->first_result()->Email)
            );
        }

        return $_Friend_List;
    }

    public function hasRequested($Friend_ID, $User_ID) {
        $this->_Database->get("Friend_Request", array("User_ID", "=", $User_ID, "Friend_ID", "=", $Friend_ID));

        if ($this->_Database->count() > 0) {
            return true;
        }
        return false;
    }

    public function isFriend($User_ID, $Friend_ID) {
        $this->_Database->get("Friends", array("User_ID", "=", $User_ID, "Friend_ID", "=", $Friend_ID));

        if ($this->_Database->count() > 0) {
            return true;
        }
        return false;
    }

    public function blockFriend($User_ID, $Friend_ID) {
        $this->_Database->delete("Friends", array("User_ID", "=", $User_ID, "Friend_ID", "=", $Friend_ID));
        $this->_Database->delete("Friends", array("User_ID", "=", $Friend_ID, "Friend_ID", "=", $User_ID));
    }

    public function cancelRequest($User_ID, $Friend_ID) {
        $this->_Database->delete("Friend_Request", array("User_ID", "=", $User_ID, "Friend_ID", "=", $Friend_ID));
    }

}
?>
