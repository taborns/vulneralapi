<?php
class Picture{

    private $_Database = null;

    public function __construct() {
        $this->_Database = Database::getInstance();
    }

    public function createAlbum($User_ID, $Name) {
        $this->_Database->get('Users', array("User_ID", "=", $User_ID));
        $Username = $this->_Database->first_result()->Username;

        $this->_Database->insert("Albums", array(
            "User_ID" => $User_ID,
            "Name" => $Name,
            "Date" => date("Y-m-d H:i:s")
        ));

        mkdir("../../Images/Users/$Username/Albums/" .  $Name);
    }

    public function getAlbumName($Album_ID) {
        $this->_Database->get("Albums", array("Album_ID", "=", $Album_ID));
        return $this->_Database->first_result()->Name;
    }

    public function getAlbumID($Name) {
        $this->_Database->get("Albums", array("Name", "=", $Name));
        return $this->_Database->first_result()->Album_ID;
    }

    public function getUserAlbums($User_ID) {
        $this->_Database->get("Albums", array("User_ID", "=", $User_ID));

        $_Albums = array();

        foreach ($this->_Database->result() as $Album) {
            $_Albums[] = array(
                "Album_ID" => $Album->Album_ID,
                "Name" => $Album->Name,
                "Date" => $Album->Date
            );
        }
        return $_Albums;
    }
}
?>
