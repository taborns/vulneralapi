<?php

class User {
    private $_Database;
    private $_User_Session;
    private $_User_Cookie;
    private $_User_Data;
    private $_isLoggedIn;

    public function __construct($user = null) {
        $this->_Database = Database::getInstance();
        $this->_User_Session = Configuration::get("Session/Session_Name");
        $this->_User_Cookie = Configuration::get("Remember/Cookie_Name");

        if (!$user) {
            if (Session::exists($this->_User_Session)) {
                $user = Session::get($this->_User_Session);
                if ($this->find($user)) {
                    $this->_isLoggedIn = true;
                }
            }
        }

        else {
            $this->find($user);
        }
    }

    public function create($fields = array()) {
        if (!$this->_Database->insert("Users", $fields)) {
            throw new Exception("There was a problem creating an Account!");
        }
    }

    public function addToGroup($fields) {
        if (!$this->_Database->insert("Group_Members", $fields)) {
            throw new Exception("There was a problem Adding User To the Group!");
        }
    }

    public function find($user = null) {
        if ($user) {
            $field = (is_numeric($user)) ? "User_ID" : "Username";
            $result = $this->_Database->get("Users", array($field, "=", $user));

            if ($result->count()) {
                $this->_User_Data = $result->first_result();
                return true;
            }
        }
        return false;
    }

    public function exists() {
        return (!empty($this->_User_Data)) ? true : false;
    }

    public function data() {
        return $this->_User_Data;
    }

    public function login($Username = null, $Password = null, $Remember = false) {
        if (!$Username && !$Password && $this->exists()) {
            Session::put($this->_User_Session, $this->data()->User_ID);
        }
        else {
            $user = $this->find($Username);

            if ($user) {
                if ($this->data()->Password === Hash::make($Password, $this->data()->Salt)) {
                    Session::put($this->_User_Session, $this->data()->User_ID);

                    if ($Remember) {
						$hash = Hash::unique();
						$hashCheck = $this->_Database->get("Session", array("User_ID", "=", $this->data()->User_ID));

						if (!$hashCheck->count()) {
							$this->_Database->insert("Session", array(
								"User_ID" => $this->data()->User_ID,
								"Hash" => $hash
							));
						}

						else {
							$hash = $hashCheck->first_Result()->User_ID;
						}

						Cookie::put($this->_User_Cookie, $hash, Configuration::get("Remember/Cookie_Expiry"));
					}
                    return true;
                }
            }
        }

        return false;
    }

    public function update($fields = array(), $ID = null) {
        if (!$ID && $this->isLoggedIn()) {
            $ID = $this->data()->User_ID;
        }
        $this->_Database->update("Users", $ID, $fields);
    }

    public function logout() {
        $this->_Database->delete("Session", array("User_ID", "=", $this->data()->User_ID));
        Session::delete($this->_User_Session);
		Cookie::delete($this->_User_Cookie);
    }

    public function getUserID($Fullname) {
        $name = explode(" ", $Fullname);
        $sql = "SELECT `User_ID` FROM `Users` WHERE `First_Name` = ? AND `Last_Name` = ?";
        $this->_Database->query($sql, array($name[0], $name[1]));

        return htmlentities($this->_Database->first_result()->User_ID);
    }

    public function getUserIDFromUsername($Username) {
        $sql = "SELECT `User_ID` FROM `Users` WHERE `Username` = ?";
        $this->_Database->query($sql, array($name[0], $name[1]));

        return htmlentities($this->_Database->first_result()->User_ID);
    }

    public function getUsername($User_ID){
        $sql = "SELECT `Username` FROM `Users` WHERE `User_ID` = ?";
        $this->_Database->query($sql, array($User_ID));
        return htmlentities($this->_Database->first_result()->Username);
    }

    public function isPresent($User_ID) {
        $this->_Database->get("Users", array("User_ID", "=", $User_ID));
        if ($this->_Database->count() > 0) {
            return true;
        }
        return false;
    }

    public function getProfilePictures($User_ID) {
        $this->_Database->get("Users", array("User_ID", "=", $User_ID));
        return htmlentities($this->_Database->first_result()->Profile_Picture);
    }

    public function getFullName($User_ID) {
        $this->_Database->get("Users", array("User_ID", "=", $User_ID));
        return htmlentities($this->_Database->first_result()->First_Name) . " " . htmlentities($this->_Database->first_result()->Last_Name);
    }

    public function getEmail($User_ID) {
        $this->_Database->get("Users", array("User_ID", "=", $User_ID));
        return htmlentities($this->_Database->first_result()->Email);
    }

    public function getAge($User_ID) {
        $this->_Database->get("Users", array("User_ID", "=", $User_ID));
        return htmlentities($this->_Database->first_result()->Age);
    }

    public function getAboutMe($User_ID) {
        $this->_Database->get("Users", array("User_ID", "=", $User_ID));
        return htmlentities($this->_Database->first_result()->About_Me);
    }

    public function getCountry($User_ID) {
        $this->_Database->get("Users", array("User_ID", "=", $User_ID));
        return htmlentities($this->_Database->first_result()->Country);
    }

    public function getCity($User_ID) {
        $this->_Database->get("Users", array("User_ID", "=", $User_ID));
        return htmlentities($this->_Database->first_result()->City);
    }

    public function getGender($User_ID) {
        $this->_Database->get("Users", array("User_ID", "=", $User_ID));
        return htmlentities($this->_Database->first_result()->Gender);
    }



    public function getUserInformation($User_ID) {
        $this->_Database->get("Users", array("User_ID", "=", $User_ID));

        return array(
            "Username" => htmlentities($this->_Database->first_result()->Username),
            "First_Name" => htmlentities($this->_Database->first_result()->First_Name),
            "Last_Name" => htmlentities($this->_Database->first_result()->Last_Name),
            "Email" => htmlentities($this->_Database->first_result()->Email),
            "Age" => htmlentities($this->_Database->first_result()->Age),
            "Birthday" => htmlentities($this->_Database->first_result()->Birthday),
            "About_Me" => htmlentities($this->_Database->first_result()->About_Me),
            "Country" => htmlentities($this->_Database->first_result()->Country),
            "City" => htmlentities($this->_Database->first_result()->City),
            "Gender" => htmlentities($this->_Database->first_result()->Gender),
            "Profile_Picture" => htmlentities($this->_Database->first_result()->Profile_Picture)
        );
    }

    public function changeProfilePicture($User_ID, $Picture) {
        $this->_Database->update("Users", $User_ID, array("Profile_Picture" => $Picture));
    }

    public function isLoggedIn() {
        return $this->_isLoggedIn;
    }

    public function isMyProfilePicture($User_ID, $Profile_Picture) {
        $this->_Database->get("Users", array("User_ID", "=", $User_ID, "Profile_Picture", "=", $Profile_Picture));
        if ($this->_Database->count() > 0) {
            return true;
        }
        return false;
    }

    public function areFriends($User_ID, $Friend_ID) {
        $this->_Database->get("Friends", array("User_ID", "=", $User_ID, "Friend_ID", "=", $Friend_ID));
        if ($this->_Database->count() > 0) {
            return true;
        }
        return false;
    }
}
?>
