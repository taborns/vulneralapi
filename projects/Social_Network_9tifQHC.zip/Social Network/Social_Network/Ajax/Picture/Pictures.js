function getAlbumPanels() {
    $.post("../../Ajax/Album/GetAlbumPanel.php", {}, function(data) {
        $("#AlbumsPanel").html(data);
    });
}

function setProgress(Value) {
    $("#ProgressBar").css("width", Value + "%");
    $("#ProgressBar").text(Value + "%");
}

$(document).ready(function() {

    document.getElementById("Submit").addEventListener("click", function(e) {
        e.preventDefault();

        var File = document.getElementById("Files");
        var ProgressBar = document.getElementById("ProgressBar");
        var data = new FormData();

        var album = $("#Album_Selector").val();

        if (File.files.length === 0) {
            return;
        }

        for (var i = 0; i < File.files.length; i++) {
            data.append("File[]", File.files[i]);
        }

        data.append("Album", album);

        $.ajax({
            url : "../../Ajax/Picture/UploadPicture.php",
            type : "POST",
            data : data,
            contentType : false,
            processData : false,
            beforeSend : function() {
                $("#ProgressBar").css("width", 0 + "%");
                $("#ProgressBar").text(0 + "%");
            },
            xhr : function() {
                var xhr = $.ajaxSettings.xhr();
                if (xhr.upload) {
                    xhr.upload.addEventListener("progress", function(e) {
                        var percent;
                        if (e.lengthComputable === true) {
            				percent = Math.round((e.loaded / e.total) * 100);
            				setProgress(percent);
            			}
                    }, false);
                }
                return xhr;
            },
            mimeType : "multipart/form-data"
        }).done(function(data) {
            if (data == "Success") {
                getAlbumPanels();
            }
            else {
                alert("Error");
            }
        });

    });

});
