<?php
require_once("../../../Tools/Initialization.php");

if (isset($_POST["Group_ID"])) {
    $user = new User();
    $group = new Group();
    $Comments = new Comment();

    $_Group_Posts = "";
    $_Group_ID = $_POST["Group_ID"];

    $Posts = $group->getGroupPosts($_Group_ID);

    foreach ($Posts as $Post) {
        $Username = ($Post->User_ID == $user->data()->User_ID) ? "You" : $user->getUsername($Post->User_ID);
        $_Comments_List = $Comments->getAllGroupPostComments($Post->Post_ID);
        $_Group_Posts .= Content::getGroupPostPanel($Post->Post_ID, $user->data()->User_ID ,$Post->User_ID, $Username , $Post->Date, $Post->Message, $Post->Likes, $Post->Group_ID, $_Comments_List);
    }

    echo $_Group_Posts;
}
?>
