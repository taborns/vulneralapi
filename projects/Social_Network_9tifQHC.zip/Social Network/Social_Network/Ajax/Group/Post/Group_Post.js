function addPost(User_ID, Group_ID, Text) {
    $.post("../../Ajax/Group/Post/AddPost.php", {User_ID: User_ID, Group_ID: Group_ID, Message: Text}, function(data) {
        if (data == "Success") {
            getPosts(Group_ID, User_ID);
        }
        else {
            alert(data);
        }
    });

}

function getPosts(Group_ID, User_ID) {
    $.post("../../Ajax/Group/Post/GetPost.php", {Group_ID: Group_ID}, function(data) {
        $("#Group_Posts").html(data);
    });
}


$(document).ready(function() {
    $("#PostButton").click(function() {
        var Group_ID = $("#Group_ID").text();
        var User_Name = $("#Username").text();
        var Message = $("#Message").val();
        addPost(User_Name, Group_ID, Message);
    });
});
