<?php
require_once("../../../Tools/Initialization.php");

if (isset($_POST["User_ID"]) && isset($_POST["Group_ID"]) && isset($_POST["Message"])) {
    $_Group_ID = $_POST["Group_ID"];
    $_User_ID = $_POST["User_ID"];
    $_Message = $_POST["Message"];

    $_Group = new Group();
    $_Group->addPost($_Group_ID, $_User_ID, $_Message);

    echo "Success";
}
?>
