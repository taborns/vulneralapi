<?php
require_once("../../../Tools/Initialization.php");

if (isset($_POST["Post_ID"]) && isset($_POST["User_ID"]) && isset($_POST["Group_ID"])) {
    $_Group = new Group();
    $_Group->addPostLike($_POST["Group_ID"], $_POST["User_ID"], $_POST["Post_ID"]);

    echo "Success";
}
 ?>
