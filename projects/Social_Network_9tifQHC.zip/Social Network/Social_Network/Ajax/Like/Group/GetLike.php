<?php
require_once("../../../Tools/Initialization.php");

if (isset($_POST["Post_ID"]) && isset($_POST["Group_ID"])) {
    $_Group = new Group();
    $_Result = $_Group->getGroupPostLikes($_POST["Group_ID"], $_POST["Post_ID"]);
    echo $_Result->Likes;
}

 ?>
