<?php
require_once("../../../Tools/Initialization.php");

if (isset($_POST["Post_ID"])) {
    $_Like = new Like();
    echo $_Like->getNumberOfLikes($_POST["Post_ID"]);
}

 ?>
