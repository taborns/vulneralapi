<?php
require_once("../../../Tools/Initialization.php");

if (isset($_POST["Post_ID"]) && isset($_POST["User_ID"])) {
    $_Like = new Like();
    $_Like->addLike($_POST["Post_ID"], $_POST["User_ID"]);
    
    echo "Success";
}
 ?>
