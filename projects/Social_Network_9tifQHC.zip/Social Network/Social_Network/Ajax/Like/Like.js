function addGroupPostLike(Post_ID, User_ID, Group_ID) {
    $.post("../../Ajax/Like/Group/AddLike.php", {Post_ID : Post_ID, User_ID : User_ID, Group_ID : Group_ID}, function(status) {
        if (status == "Success") {
            getGroupPostLike(Post_ID, Group_ID);
        }
        else {
            alert(status);
        }
    });
}

function getGroupPostLike(Post_ID, Group_ID) {
    $.post("../../Ajax/Like/Group/GetLike.php", {Post_ID : Post_ID, Group_ID : Group_ID}, function(data) {
        $("#"+Post_ID+"_Likes").text(data);
    });
}

function addPostLike(Post_ID, User_ID) {
    $.post("../../Ajax/Like/Post/AddLike.php", {Post_ID : Post_ID, User_ID : User_ID}, function(status) {
        if (status == "Success") {
            getPostLike(Post_ID);
        }
        else {
            alert(status);
        }
    });
}

function getPostLike(Post_ID) {
    $.post("../../Ajax/Like/Post/GetLike.php", {Post_ID : Post_ID}, function(data) {
        $("#"+Post_ID+"_Likes").text(data);
    });
}
