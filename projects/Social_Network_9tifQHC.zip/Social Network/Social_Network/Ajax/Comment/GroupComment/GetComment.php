<?php
require_once("../../../Tools/Initialization.php");

if (isset($_POST["Post_ID"])) {
    $_Comment = new Comment();
    $_Comments = $_Comment->getAllGroupPostComments($_POST["Post_ID"]);

    echo json_encode($_Comments);
}
?>
