function addComment(Post_ID, User_ID) {
    var comment = $("#Comment_" + Post_ID).val();

    $.post("../../Ajax/Comment/GroupComment/AddComment.php", {Post_ID : Post_ID, User_ID : User_ID, Comment : comment}, function(data) {
        if (data == "Success") {
            getComment(Post_ID);
        }
        else {
            alert(data);
        }
    });
}

function getComment(Post_ID) {
    $.post("../../Ajax/Comment/GroupComment/GetComment.php", {Post_ID : Post_ID}, function(data) {
        var result = JSON.parse(data);
        displayComments(result, Post_ID);
    });
}

function displayComments(Data, Post_ID) {
    var output = "";

    for (var i = 0; i < Data.length; i++) {
        output += "<li class = 'list-group-item' id = 'Comments_Bar'> <h5 class = 'text-success'> <b>" + Data[i].User_ID + "</b> <span class = 'text-muted'> Commented </span> </h5> </p> " + Data[i].Comment + " </p> </li>";
    }

    $("#" + Post_ID + "_Bar").html(output);
}
