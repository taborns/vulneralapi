<?php
require_once("../../../Tools/Initialization.php");

if (isset($_POST["Post_ID"]) && isset($_POST["User_ID"]) && isset($_POST["Comment"])) {
    $_Comment = new Comment();
    $_Comment->addPostComment($_POST["Post_ID"], $_POST["User_ID"], $_POST["Comment"]);

    echo "Success";
}
?>
