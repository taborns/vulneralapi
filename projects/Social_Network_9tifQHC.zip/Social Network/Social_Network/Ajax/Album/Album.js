function addAlbum(User_ID) {
    var Album_Name = $("#Album_Name").val();

    $.post("../../Ajax/Album/AddAlbum.php", {User_ID : User_ID, Name : Album_Name}, function(data) {
        if (data == "Success") {
            getAlbums(User_ID);
            getAlbumPanel(User_ID);
        }
    });
}

function getAlbums(User_ID) {
    $.post("../../Ajax/Album/GetAlbum.php", {User_ID : User_ID}, function(data) {
        var result = JSON.parse(data);
        updateAlbumSelector(result);
    });
}

function getAlbumPanel(User_ID) {
    $.post("../../Ajax/Album/GetAlbumPanel.php", {User_ID : User_ID}, function(data) {
        $("#AlbumsPanel").html(data);
    });
}

function updateAlbumSelector(data) {
    var output = "<option value = ''> Album </option>";

    if (data.length > 0) {
        for (var i = 0; i < data.length; i++) {
            output += "<option value = '" + data[i].Name + "'>" + data[i].Name + "</option>";
        }
    }

    $("#Album_Selector").html(output);
}

function deleteImage(Event, File, User_ID) {
    Event.preventDefault();

    $.post("../../Ajax/Album/DeleteImage.php", {File : File}, function(data) {
        if (data == "Success") {
            getAlbumPanel(User_ID);
        }
        else {
            alert(data);
        }
    });
}
