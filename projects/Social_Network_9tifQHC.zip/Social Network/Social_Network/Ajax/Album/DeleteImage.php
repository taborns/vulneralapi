<?php
require_once("../../Tools/Initialization.php");

$user = new User();

if(isset($_POST["File"])) {
    if ($user->isPresent($user->data()->User_ID)) {
        $user->changeProfilePicture($user->data()->User_ID, "../../Images/Default.png");

        unlink($_POST["File"]);
        echo "Success";
    }

}
?>
