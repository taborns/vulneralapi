<?php
require_once("../../Tools/Initialization.php");

if (isset($_POST["User_ID"])) {
    $Picture = new Picture();

    $_Albums = $Picture->getUserAlbums($_POST["User_ID"]);

    echo json_encode($_Albums);
}

?>
