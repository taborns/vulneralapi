<?php
require_once("../../Tools/Initialization.php");


if (isset($_POST["User_ID"])) {
    $Notification = new Notification();
    $_Notifications_List = $Notification->getNotifications($_POST["User_ID"]);

    echo json_encode($_Notifications_List);
}
?>
