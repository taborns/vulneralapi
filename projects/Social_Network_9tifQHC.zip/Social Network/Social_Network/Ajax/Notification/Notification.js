function removeNotification(Notification_ID, User_ID) {
    $.post("../../Ajax/Notification/RemoveNotification.php", {Notification_ID : Notification_ID}, function(status) {
        if (status == "Success") {
            getNotification(User_ID);
        }
    });
}

function getNotification(User_ID) {
    $.post("../../Ajax/Notification/GetNotifications.php", {User_ID : User_ID}, function(data) {
        var result = JSON.parse(data);
        displayNotifications(result, User_ID);
    });
}

function getURL() {
    return "/Files/PHP/Social_Network/View/Notifications/Notifications.php";
}

function displayNotifications(Data, User_ID) {
    var output = "";
    if (Data.length > 0) {
        for (var i = 0; i < Data.length; i++) {
            output += getNotificationBar(Data[i].Notification_ID, Data[i].Notification, User_ID);
        }
    }
    else {
        output = "<tr> <td> <span class = 'glyphicon glyphicon-remove'></span> No Notification </td> </tr>";
    }

    $("#Sidebar_Notification_Number").html(Data.length);
    $("#Navbar_Notification_Number").html(Data.length);
    $("#Notification_Panel").html(output);

}
function getNotificationBar(Notification_ID, Notification, User_ID) {
    var Bar = "<tr>";
    Bar += "<td>";
    Bar += "<div class = 'row'> <div class = 'col-sm-10'>";
    Bar += "<a href = '" + getURL() + "'>";
    Bar += "<h5>" + Notification + "</h5>";
    Bar += "</a>";
    Bar += "</div>";
    Bar += "<div class = 'col-sm-2'>";
    Bar += "<a href = '#' onclick = 'removeNotification(" + Notification_ID + ", " + User_ID + ")'>";
    Bar += "<span class = 'glyphicon glyphicon-remove'> </span>";
    Bar += "</a>";
    Bar += "</div> </div> </td> </tr>";

    return Bar;
}
