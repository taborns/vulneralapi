<?php
require_once("../../Tools/Initialization.php");

$user = new User();
$Notification = new Notification();

if (isset($_POST["Notification_ID"])) {
    $Notification->markRead($_POST["Notification_ID"]);

    echo "Success";
}

?>
