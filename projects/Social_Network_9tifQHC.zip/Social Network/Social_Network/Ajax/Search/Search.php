<?php
require_once("../../Tools/Initialization.php");

if (isset($_GET["Term"]) && isset($_GET["Username"])) {
    $_Database = Database::getInstance();
    $sql = "SELECT * FROM `Users` WHERE `Username` LIKE ? AND `Username` != ?";
    $_Database->query($sql, array("%".$_GET["Term"]."%", $_GET["Username"]));

    $_Result = array();

    foreach ($_Database->result() as $User) {
        $_Result[] = array(
            "User_ID" => $User->User_ID,
            "Username" => $User->Username,
            "Profile_Picture" => $User->Profile_Picture
        );
    }

    echo json_encode($_Result);

}

?>
