function search(Term) {
    var Username = $("#Username").text();
    $.get("../../Ajax/Search/Search.php", {Term : Term, Username : Username}, function(data) {
        var result = JSON.parse(data);
        displaySearchResult(result);
    });
}

function displaySearchResult(data) {
    var output = "";

    if (data.length > 0) {
        for(var i = 0; i < data.length; i++) {
            output += displayRow(data[i].User_ID, data[i].Username, data[i].Profile_Picture);
        }
    }

    else {
        output = "<a href = '#' class = 'list-group-item'> <div class = 'row'> <div class = 'col-sm-2'> <span class = 'glyphicon glyphicon-remove'> </span> </div> <div class = 'col-sm-10'> No Result </div> </div> </a>";
    }


    $("#SearchBar").html(output);
}

function displayRow(User_ID, Username, Profile_Picture) {

    var Panel = "<a href = '" + getUserURL(User_ID) + "' class = 'list-group-item Search_Item' title = '" + Username +"' >";
    Panel += "<div class = 'row'>";
    Panel += "<div class = 'col-sm-3'>";
    Panel += "<img src = '" + Profile_Picture +"' alt = 'Profile Picture' width = '100' height = '100' class = 'img-thumbnail'>";
    Panel += "</div>";
    Panel += "<div class = 'col-sm-9'>";
    Panel += Username;
    Panel += "</div>";
    Panel += "</div>";
    Panel += "</a>";

    return Panel;
}

function getUserURL(ID) {
    return "/Files/PHP/Social_Network/View/User/User.php?ID=" + ID;
}

$(document).ready(function() {
    $("#Search").keyup(function() {
        $("#SearchBar").css("display", "Block");
        var Term = $("#Search").val();
        search(Term);
    });

    $("#Search").focus(function() {
        $("#SearchBar").css("display", "Block");
        var Term = $("#Search").val();
        search(Term);
    });

    $("#SearchBar").blur(function() {
        $("#SearchBar").css("display", "None");
    });

});
