function sendMessage(Sender_ID, Reciever_ID) {
    var Message = $("#Message").val();
    var Username = $("#Conversation_Username").text();

    if (Message.length > 0) {
        $.post("../../Ajax/Message/SendMessage.php", {Sender_ID : Sender_ID, Reciever_ID : Reciever_ID, Message : Message}, function(status) {
            if (status == "Success") {
                getMessages(Sender_ID, Reciever_ID, Username);
            }
            else {
                alert(status);
            }
        });
    }

}

function getMessages(Sender_ID, Reciever_ID , Username) {
    $.post("../../Ajax/Message/GetMessage.php", {Sender_ID : Sender_ID, Reciever_ID : Reciever_ID}, function(data) {
        var result = JSON.parse(data);
        displayMessages(result, Reciever_ID, Username);
    });
}

function displayMessages(data, Reciever_ID, Username) {
    var output = "";
    if (data.length > 0) {
        for (var i = 0; i < data.length; i++) {
            output += getMessagePanel(Reciever_ID, Username , data[i].Message, data[i].Date, data[i].Type, data[i].Seen);
        }
    }
    else {
        output = ""
    }

    $("#Conversation").empty().html(output);
}


function getLink(Username, ID) {
    if (Username == "You") {
        return "/Files/PHP/Social_Network/View/User/Profile.php";
    }
    else {
        return "/Files/PHP/Social_Network/View/User/User.php?ID=" + ID ;
    }
}


function getMessagePanel(User_ID, Username, Message, Dates, Type, Seen) {
    var Message_Username = (Type != "Sender") ? "You" : Username;
    var Final_Message = (Seen != true) ? "<b>" + Message +"</b>" : Message;
    var url = getLink(Message_Username, User_ID);

    var Panel = "<li class = 'list-group-item Message_Panel'>";
    Panel += "<a href = '" + url + "' title = '" + Message_Username + "'>";
    Panel += "<span class = 'glyphicon glyphicon-user'> </span> ";
    Panel += Message_Username;
    Panel += " </a>";
    Panel += "<span class = 'text-success glyphicon glyphicon-dashboard'> </span> ";
    Panel += Dates;
    Panel += " <p class = 'text-muted'> <span class = 'glyphicon glyphicon-envelope'> </span> ";
    Panel += Final_Message;
    Panel += " </p> </li>";

    return Panel;

}
