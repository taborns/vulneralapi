<?php
require_once("../../Tools/Initialization.php");

$user = new User();
$Message = new Message();


if (isset($_POST["Sender_ID"]) && isset($_POST["Reciever_ID"])) {
    $_Messages = $Message->getAllConversation($_POST["Sender_ID"], $_POST["Reciever_ID"]);

    echo json_encode($_Messages);
}

?>
