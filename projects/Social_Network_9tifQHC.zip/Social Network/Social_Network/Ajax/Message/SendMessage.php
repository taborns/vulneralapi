<?php
require_once("../../Tools/Initialization.php");

$user = new User();
$Message = new Message();

if (isset($_POST["Sender_ID"]) && isset($_POST["Reciever_ID"]) && isset($_POST["Message"])) {
    $Message->sendMessage($_POST["Sender_ID"], $_POST["Reciever_ID"], $_POST["Message"]);
    echo "Success";
}

?>
