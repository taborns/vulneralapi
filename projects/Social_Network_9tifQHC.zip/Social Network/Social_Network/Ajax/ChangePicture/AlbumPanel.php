<?php
require_once("../../Tools/Initialization.php");

if (isset($_POST["User_ID"])) {
    $output = "";

    $user = new User();
    $Pictures = new Picture();
    $MyAlbums = $Pictures->getUserAlbums($_POST["User_ID"]);

    $output .= Content::getAlbumPanelForProfileChanger("", $user->getUsername($_POST["User_ID"]), $_POST["User_ID"]);

    foreach ($MyAlbums as $Album) {
        $output .= Content::getAlbumPanelForProfileChanger($Album["Name"], $user->getUsername($_POST["User_ID"]), $_POST["User_ID"]);
    }

    echo $output;
}

else {
    $user = new User();
    $Picture = new Picture();

    $_User_ID = $user->data()->User_ID;

    $MyAlbums = $Picture->getUserAlbums($_User_ID);

    $output = "";
    $output .= Content::getAlbumPanelForProfileChanger("", $user->getUsername($_User_ID), $_User_ID);

    foreach ($MyAlbums as $Album) {
        $output .= Content::getAlbumPanelForProfileChanger($Album["Name"], $user->getUsername($_User_ID), $_User_ID);
    }

    echo $output;
}
?>
