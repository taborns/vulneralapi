<?php
require_once("../../Tools/Initialization.php");

$user = new User();
$User_ID = $user->data()->User_ID;

echo $user->getProfilePictures($User_ID);
?>
