<?php
require_once("../../Tools/Initialization.php");

$user = new User();
$User_ID = $user->data()->User_ID;

if (isset($_POST["File"])) {
    $user->changeProfilePicture($User_ID, $_POST["File"]);

    echo "Success";
}
?>
