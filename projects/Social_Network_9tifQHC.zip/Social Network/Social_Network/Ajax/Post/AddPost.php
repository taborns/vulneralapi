<?php
header('Content-type: application/json');
require_once("../../Tools/Initialization.php");

$User = new User();
$Post = new Post();

$User_ID = $User->data()->User_ID;
$Username = $User->data()->Username;

$_Uploaded = [];
$_Allowed = ['jpg', 'png', 'svg'];
$_Images = "";

$_Succeeded = [];
$_Failed = [];

if (!empty($_FILES["File"]) && isset($_POST["Post"])) {
	$_Text = $_POST["Post"];

	foreach ($_FILES["File"]["name"] as $Key => $Name) {
		$_Temp = $_FILES["File"]["tmp_name"][$Key];

        $extension = explode(".", $Name);
		$extension = strtolower(end($extension));

        $_File = md5_file($_Temp).time().".".$extension;
        $_Directory = "../../Images/Posts/{$Username}/{$_File}";

        if (in_array($extension, $_Allowed) && move_uploaded_file($_Temp, $_Directory)) {
				$_Succeeded[] = array(
					"Name" => $Name,
					"File" => $_File
				);
                $_Images .= $_Directory . "*";
			}
	}

    $Post->addPost($User_ID, $_Text, 0, $_Images);

	echo "Success";

}
?>
