function setProgress(Value) {
    $("#ProgressBar").css("width", Value + "%");
    $("#ProgressBar").text(Value + "%");
}

$(document).ready(function() {

    document.getElementById("PostButton").addEventListener("click", function(e) {
        e.preventDefault();

        var File = document.getElementById("Files");
        var ProgressBar = document.getElementById("ProgressBar");
        var data = new FormData();

        var Post = $("#Post").val();

        if (File.files.length === 0) {
            return;
        }

        for (var i = 0; i < File.files.length; i++) {
            data.append("File[]", File.files[i]);
        }

        data.append("Post", Post);

        $.ajax({
            url : "../../Ajax/Post/AddPost.php",
            type : "POST",
            data : data,
            contentType : false,
            processData : false,
            beforeSend : function() {
                $("#ProgressBar").css("width", 0 + "%");
                $("#ProgressBar").text(0 + "%");
            },
            xhr : function() {
                var xhr = $.ajaxSettings.xhr();
                if (xhr.upload) {
                    xhr.upload.addEventListener("progress", function(e) {
                        var percent;
                        if (e.lengthComputable === true) {
            				percent = Math.round((e.loaded / e.total) * 100);
            				setProgress(percent);
            			}
                    }, false);
                }
                return xhr;
            },
            mimeType : "multipart/form-data"
        }).done(function(data) {
            if (data == "Success") {
                $("#Notifications").html("<div class = 'alert alert-success fade in'> <a href = '#' class = 'close' data-dismiss = 'alert' aria-label = 'close'> &times; </a> <strong> Success! </strong> Posted </div>");
            }
            else {
                $("#Notifications").html("<div class = 'alert alert-danger fade in'> <a href = '#' class = 'close' data-dismiss = 'alert' aria-label = 'close'> &times; </a> <strong> Error! </strong> Posting Failed </div>");
            }
        });

    });

});
