<?php
require_once("../../Tools/Initialization.php");

$user = new User();
$Notification = new Notification();

if (isset($_POST["User_ID"]) && isset($_POST["Friend_ID"])) {
    $friend = new Friend();
    $friend->blockFriend($_POST["User_ID"], $_POST["Friend_ID"]);

    $Notification->addNotification($_POST["Friend_ID"], $user->getUsername($_POST["User_ID"]) . " Has Blocked Your Account.");
    echo "Success";
}
?>
