function blockUser(Friend_ID, User_ID) {
    $.post("../../Ajax/Friends/BlockUser.php", {Friend_ID : Friend_ID, User_ID : User_ID}, function(status) {
        if (status == "Success") {
            var option = "<button class = 'btn btn-primary' onclick = 'sendRequest(" + Friend_ID + ", " + User_ID + ")'> <span class = 'glyphicon glyphicon-plus'> </span> Add Friend </button>";
            $("#AccountOption").empty().html(option);
        }
        else {
            alert(status);
        }
    });
}

function acceptRequest(Friend_ID, User_ID) {
    $.post("../../Ajax/Friends/AcceptFriendRequests.php", {Friend_ID : Friend_ID, User_ID : User_ID}, function(status) {
        if (status == "Success") {
            var option = "<button class = 'btn btn-primary' onclick = 'blockUser(" + Friend_ID + ", " + User_ID + ")'> <span class = 'glyphicon glyphicon-remove'> </span>  Block </button>";
            $("#AccountOption").empty().html(option);
        }
        else {
            alert(status);
        }
    });
}

function cancelRequest(Friend_ID, User_ID) {
    $.post("../../Ajax/Friends/CancelRequest.php", {Friend_ID : Friend_ID, User_ID : User_ID}, function(status) {
        if (status == "Success") {
            var option = "<button class = 'btn btn-primary' onclick = 'sendRequest(" + Friend_ID + ", " + User_ID + ")'> <span class = 'glyphicon glyphicon-plus'> </span>  Add Friend </button>";
            $("#AccountOption").empty().html(option);
        }
        else {
            alert(status);
        }
    });
}

function sendRequest(Friend_ID, User_ID) {
    $.post("../../Ajax/Friends/SendRequest.php", {Friend_ID : Friend_ID, User_ID : User_ID}, function(status) {
        if (status == "Success") {
            var option = "<button class = 'btn btn-primary' onclick = 'cancelRequest(" + Friend_ID + ", " + User_ID + ")'> <span class = 'glyphicon glyphicon-remove'> </span> Cancel Request </button>";
            $("#AccountOption").empty().html(option);
        }
        else {
            alert(status);
        }
    });
}
