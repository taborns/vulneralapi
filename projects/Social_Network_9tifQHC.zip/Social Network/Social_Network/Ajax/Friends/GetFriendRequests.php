<?php
require_once("../../Tools/Initialization.php");


if (isset($_POST["User_ID"])) {
    $friend = new Friend();
    $_Friends_Request_List = $friend->getFriendRequests($_POST["User_ID"]);

    echo json_encode($_Friends_Request_List);
}
?>
