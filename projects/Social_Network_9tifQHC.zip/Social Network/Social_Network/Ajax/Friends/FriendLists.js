function acceptRequest(Friend_ID, User_ID) {
    $.post("../../Ajax/Friends/AcceptFriendRequests.php", {Friend_ID : Friend_ID, User_ID : User_ID}, function(status) {
        if (status == "Success") {
            getRequest(User_ID);
            getUsers(User_ID);
        }
        else {
            alert(status);
        }
    });
}

function getRequest(User_ID) {
    $.post("../../Ajax/Friends/GetFriendRequests.php", {User_ID : User_ID}, function(data) {
        var result = JSON.parse(data);
        displayRequests(result, User_ID);
    });

    $.post("../../Ajax/Friends/GetFriendRequestNumber.php", {User_ID : User_ID}, function(data) {
        $("#Friend_Request_Number").text(data);
    });
}

function getUsers(User_ID) {
    $.post("../../Ajax/Friends/GetFriends.php", {User_ID : User_ID}, function(data) {
        var result = JSON.parse(data);
        displayUsers(result);
    });
}

function displayUsers(Data) {
    var output = "";

    if (Data.length > 0) {
        for (var i = 0; i < Data.length; i++) {
            output += getFriendsPanel(Data[i].User_ID, Data[i].Username, Data[i].Email);
        }

    }

    else {
        output = "<div class = 'alert alert-danger'>No Friends! </div>";
    }

    $("#Friends_Panel").empty().html(output);
    $("#Number_Of_Friends").empty().html("( " + Data.length +")");

}



function displayRequests(Data, User_ID) {
    var output = "";

    if (Data.length > 0) {
        for (var i = 0; i < Data.length; i++) {
            output += getRequestPanel(User_ID, Data[i].User_ID, Data[i].Username);
        }
    }

    else {
        output = "<div class = 'alert alert-danger'>No Friend Requests!</div>";
    }

    $("#Friend_Request_Panel").empty().html(output);
    $("#Number_Of_Requests").empty().html("( " + Data.length +")");

}

function getURL(ID) {
    return "/Files/PHP/Social_Network/View/User/User.php?ID=" + ID;
}

function getFriendsPanel(Friend_ID, Username, Email) {
    var Panel = "<a href = '" + getURL(Friend_ID) + "' class = 'list-group-item'>";
    Panel += "<div class = 'row'>";
    Panel += "<div class = 'col-sm-4'>";
    Panel += "<img src = '../../Images/boy-1.png' class = 'img-thumbnail'>";
    Panel += "</div>";
    Panel += "<div class = 'col-sm-8'>";
    Panel += "<h3>" + Username + "</h3>";
    Panel += "<div class ='FriendsPanel'>";
    Panel += "<p>" + Email + "</p>";
    Panel += "</div>";
    Panel += "</div>";
    Panel += "</div>";
    Panel += "</a>";

    return Panel;
}

function getRequestPanel(User_ID, Friend_ID, Friend_Username) {
    var Panel = "<tr id = '" + Friend_ID + "_" + User_ID + "_Requests" + "'>";
    Panel += "<td>";
    Panel += "<a href '" + getURL(Friend_ID) + "' class 'Accept_Request'>";
    Panel += "<h5>" + Friend_Username + "</h5>";
    Panel += "</td>";
    Panel += "<td>";
    Panel += "<button type = 'button' class = 'btn btn-primary btn-sm' onclick = 'acceptRequest(" + Friend_ID + ", " + User_ID +")'>";
    Panel += "<span class = 'glyphicon glyphicon-ok-sign'>";
    Panel += "</span> Accept Request </button> </a> </td> </tr>";

    return Panel;
}
