<?php
require_once("../../Tools/Initialization.php");
$user = new User();
$Notification = new Notification();

if (isset($_POST["User_ID"]) && isset($_POST["Friend_ID"])) {
    $friend = new Friend();
    $friend->cancelRequest($_POST["User_ID"], $_POST["Friend_ID"]);

    $Notification->addNotification($_POST["User_ID"], "You Have Cancelled Your Friend Request For " . $user->getUsername($_POST["Friend_ID"]));
    echo "Success";
}
?>
