<?php
require_once("../../Tools/Initialization.php");


if (isset($_POST["User_ID"]) && isset($_POST["Friend_ID"])) {
    $friend = new Friend();
    $friend->addFriendRequest($_POST["User_ID"], $_POST["Friend_ID"]);

    echo "Success";
}
?>
