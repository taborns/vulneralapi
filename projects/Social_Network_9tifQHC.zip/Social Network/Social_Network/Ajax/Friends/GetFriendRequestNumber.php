<?php
require_once("../../Tools/Initialization.php");


if (isset($_POST["User_ID"])) {
    $friend = new Friend();
    $_Friends_Request_Number = $friend->getFriendRequestsNumber($_POST["User_ID"]);

    echo $_Friends_Request_Number;
}
?>
