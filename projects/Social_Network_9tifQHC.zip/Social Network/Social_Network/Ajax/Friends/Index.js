function acceptRequest(Friend_ID, User_ID) {
    $.post("../../Ajax/Friends/AcceptFriendRequests.php", {Friend_ID : Friend_ID, User_ID : User_ID}, function(status) {
        if (status == "Success") {
            getRequest(User_ID);
        }
        else {
            alert(status);
        }
    });
}

function getRequest(User_ID) {
    $.post("../../Ajax/Friends/GetFriendRequests.php", {User_ID : User_ID}, function(data) {
        var result = JSON.parse(data);
        displayRequests(result, User_ID);
    });

    $.post("../../Ajax/Friends/GetFriendRequestNumber.php", {User_ID : User_ID}, function(data) {
        $("#Friend_Request_Number").text(data);
    });
}

function displayRequests(Data, User_ID) {
    var output = "";

    if (Data.length > 0) {
        for (var i = 0; i < Data.length; i++) {
            output += getPanel(User_ID, Data[i].User_ID, Data[i].Username);
        }
    }

    else {
        output = "<tr> <td> <span class = 'glyphicon glyphicon-remove'> </span> No Friend Requests </td> </tr>";
    }

    $("#Friend_Request_Panel").html(output);
}

function getURL(ID) {
    return "/Files/PHP/Social_Network/View/User/User.php?ID=" + ID;
}

function getPanel(User_ID, Friend_ID, Friend_Username) {
    var Panel = "<tr id = '" + Friend_ID + "_" + User_ID + "_Requests" + "'>";
    Panel += "<td>";
    Panel += "<a href '" + getURL(Friend_ID) + "' class 'Accept_Request'>";
    Panel += "<h5>  <span class = 'glyphicon glyphicon-user'> </span> " + Friend_Username + "</h5>";
    Panel += "</td>";
    Panel += "<td>";
    Panel += "<button type = 'button' class = 'btn btn-primary btn-sm' onclick = 'acceptRequest(" + Friend_ID + ", " + User_ID +")'>";
    Panel += "<span class = 'glyphicon glyphicon-ok-sign'>";
    Panel += "</span> Accept Request </button> </a> </td> </tr>";

    return Panel;
}
