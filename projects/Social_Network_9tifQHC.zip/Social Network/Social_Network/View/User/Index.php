<?php
require_once("../../Tools/Initialization.php");

$user = new User();
$group = new Group();
$friends = new Friend();
$Notification = new Notification();
$Comments = new Comment();
$Message = new Message();
$Post = new Post();



$_Notifications_List = $Notification->getNotifications($user->data()->User_ID);

if(!$user->isLoggedIn()) {
    Redirect::to("../Login.php");
}

?>

<!DOCTYPE html>
<HTML>
    <Head>
        <Title> Welcome to Social Network </Title>
        <link rel = "stylesheet" type = "text/css" href = "../../CSS/bootstrap/css/bootstrap.min.css">
        <link rel = "stylesheet" type = "text/css" href = "../../CSS/Custom/Page.css">
        <link rel = "stylesheet" type = "text/css" href = "../../Script/Lightbox/css/lightbox.css">
        <meta name = "viewport" content="width=device-width, initial-scale=1">
        <meta charset = "utf-8">
    </Head>
    <Body>
        <?php require_once("../Template/Navigation.php"); ?>

        <div class = "jumbotron">
            <div class = "row">
                <div class = "col-md-3 col-sm-10 container">
                    <?php require_once("../Template/LSidebar.php"); ?>
                </div>

                <div class = "col-md-6 col-sm-10 container">
                    <div class = "panel panel-default" id = "Content">
                        <form role = "form">
                            <div class="form-group">
                                <label for="comment"> Post </label>
                                <textarea class = "form-control" rows = "2" id = "Post"></textarea>
                                <div class = "row">
                                    <div class = "col-sm-8">
                                        <input type = "File" id = "Files" name = "File" required multiple>
                                        <div class = "progress">
                                            <div class = "progress-bar progress-bar-striped active" role = "progressbar" aria-valuenow = "40" aria-valuemin = "0" aria-valuemax = "100" id = "ProgressBar">
                                            </div>
                                        </div>
                                    </div>
                                    <div class = "col-sm-4">
                                        <button type = "button" id = "PostButton" class = "btn btn-primary"> <span class = "glyphicon glyphicon-upload"> </span> Post </button>
                                    </div>
                                </div>
                            </div>

                            <div id = "Notifications">

                            </div>
                        </form>

                        <div>
                            <?php
                            $_Posts = $Post->getPostsOfUser($user->data()->User_ID);

                            if (count($_Posts) > 0) {
                                foreach ($_Posts as $Post) {
                                    $_Comments_List = $Comments->getAllPostComments($Post["Post_ID"]);
                                    echo Content::getPostPanel($user->data()->User_ID, $Post["Post_ID"], $Post["Text"], $Post["Date"], $Post["Likes"], $Post["Friend_ID"], $user->getUsername($Post["Friend_ID"]), $_Comments_List, $Post["Image"]);
                                }
                            }
                            else {
                            }
                            ?>
                        </div>
                    </div>
                </div>
                <div class = "col-md-3 col-sm-10 container">
                    <?php require_once("../Template/RSidebar.php"); ?>
                </div>
            </div>
        </div>
        <script src = "../../Script/jQuery/jquery-2.2.3.min.js"> </script>
        <script src = "../../Script/Lightbox/js/lightbox.js"> </script>
        <script src = "../../CSS/bootstrap/js/bootstrap.min.js"> </script>
        <script src = "../../Ajax/Friends/Index.js"> </script>
        <script src = "../../Ajax/Notification/Notification.js"> </script>
        <script src = "../../Ajax/Like/Like.js"> </script>
        <script src = "../../Ajax/Comment/PostComment/Comment.js"> </script>
        <script src = "../../Ajax/Search/Search.js"> </script>
        <script src = "../../Ajax/Post/Post.js"> </script>
    </Body>
</HTML>
