<?php
require_once("../../Tools/Initialization.php");

$validator = null;
$validation = null;
$_Errors = array();
$_Success = false;

$Notification = new Notification();

if (Input::exists("POST")) {
    if (Token::checkToken(Input::get("Token"))) {
        $validator = new Validation();
        $validation = $validator->check($_POST, array(
            "Gender" => array(
                "Required" => true
            ),
            "First_Name" => array(
                "Required" => true,
                "Minimum" => 2,
                "Maximum" => 25
            ),
            "Last_Name" => array(
                "Required" => true,
                "Minimum" => 2,
                "Maximum" => 25
            ),
            "City" => array(
                "Required" => true
            ),
            "Country" => array(
                "Required" => true
            ),
            "Age" => array(
                "Required" => true
            ),
            "Username" => array(
                "Required" => true,
                "Minimum" => 3,
                "Maximum" => 25,
                "Unique" => "Users"
            ),
            "Email" => array(
                "Required" => true,
                "Minimum" => 8,
                "Maximum" => 25
            ),
            "Password" => array(
                "Required" => true,
                "Minimum" => 6,
                "Maximum" => 25
            ),
            "Confirm_Password" => array(
                "Required" => true,
                "Matches" => "Password"
            )
        ));
    }
}

if ($validation != null) {
    if ($validation->passed()) {
        $user = new User();

        $salt = Hash::salt(32);
        $password = Hash::make(Input::get("Password"), $salt);

        $birth_day = date("Y-m-d", strtotime(Input::get("BirthDay")));
        try {
            $user->create(array(
                "Username" => Input::get("Username"),
                "Password" => $password,
                "Salt" => $salt,
                "First_Name" => Input::get("First_Name"),
                "Last_Name" => Input::get("Last_Name"),
                "Email" => Input::get("Email"),
                "Age" => Input::get("Age"),
                "Birthday" => $birth_day,
                "About_Me" => Input::get("Description"),
                "Country" => Input::get("Country"),
                "City" => Input::get("City"),
                "Gender" => Input::get("Gender"),
                "Profile_Picture" => "../../Images/Default.png"
            ));

            $Notification->addNotification($user->getUserIDFromUsername( Input::get("Username")), "You Have Successfully Created An Account!");

            mkdir("../../Images/Users/" .  Input::get("Username"));
            mkdir("../../Images/Users/" .  Input::get("Username"). "/Albums");
            mkdir("../../Images/Posts/" .  Input::get("Username"));

            $_Success = true;

            Redirect::to("../Login.php");

        }
        catch (Exception $e) {
            die();
        }
    }

    else {
        $_Success = false;
        $_Errors = $validation->errors();

    }
}
?>


<!DOCTYPE HTML>
<HTML>
    <Head>
        <Title> Sign Up </Title>
        <link rel = "stylesheet" type = "text/css" href = "../../Script/jQuery-UI/jquery-ui.css">
        <link rel = "stylesheet" type = "text/css" href = "../../CSS/bootstrap/css/bootstrap.min.css">
        <link rel = "stylesheet" type = "text/css" href = "../../CSS/Custom/Register.css">


        <meta name = "viewport" content="width=device-width, initial-scale=1">
        <meta charset = "utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">

        <style>
            .row {
                margin-bottom: 20px;
            };
        </style>
    </Head>

    <Body>
        <nav class = "navbar navbar-inverse navbar-fixed-top" role = "navigation">
            <div class = "container-fluid">
                <div class = "navbar-header">
                    <button type = "button" class = "navbar-toggle" data-toggle = "collapse" data-target = "#navbar-collapse">
                        <span class = "sr-only"> Toggle Navigation </span>
                        <span class = "icon-bar"> </span>
                        <span class = "icon-bar"> </span>
                        <span class = "icon-bar"> </span>
                    </button>

                    <a class = "navbar-brand" href = "#"> Social Network </a>
                </div>

                <div class = "collapse navbar-collapse" id = "navbar-collapse">

                    <ul class="nav navbar-nav navbar-right">
                        <li>
                            <a href = "<?php echo Link::get("Login.php"); ?>" title = "Login"> Login </a>
                        </li>

                    </ul>
                </div>
            </div>
        </nav>


        <div class = "jumbotron">
            <div class = "col-md-offset-2 col-md-8 col-sm-10">
                <div class = "panel panel-primary">
                    <div class = "panel-heading">
                        <h4> Create a Free Account </h4>
                    </div>
                    <form class = "panel-body" autocomplete="off" method="POST">
                        <div class = "row">
                            <div class = "col-md-10 col-sm-10">
                                <h4> <span class="label label-success">1</span> Personal Information </h4>
                            </div>
                        </div>
                        <!--Gender-->
                        <div class = "row">
                            <div class = "col-md-8 container">
                                <label> Select a Gender : </label>
                                <div class = "radio-inline">
                                    <label> <input type = "radio" name = "Gender" value = "Male" required> Male </label>
                                </div>
                                <div class = "radio-inline">
                                    <label> <input type = "radio" name = "Gender" value = "Female"> Female </label>
                                </div>
                            </div>
                        </div>
                        <!-- Name-->
                        <div class = "row">
                            <div class = "col-md-6 col-sm-10">
                                <div class = "input-group">
                                    <span class = "input-group-addon"> <span class = "glyphicon glyphicon-user"> </span> </span>
                                    <input type = "Text" class = "form-control" id = "First_Name" name = "First_Name" placeholder = "First Name" value = "<?php echo Input::get("First_Name"); ?>" required>
                                </div>
                            </div>

                            <div class = "col-md-6 col-sm-10">
                                <div class = "input-group">
                                    <span class = "input-group-addon"> <span class = "glyphicon glyphicon-user"> </span> </span>
                                    <input type = "Text" class = "form-control" id = "Last_Name" name = "Last_Name" placeholder = "Last Name" value = "<?php echo Input::get("Last_Name"); ?>" required>
                                </div>
                            </div>
                        </div>

                        <!-- Address -->
                        <div class = "row">
                            <div class = "col-md-6 col-sm-10">
                                <div class = "input-group">
                                    <span class = "input-group-addon"> <span class = "glyphicon glyphicon-home"> </span> </span>
                                    <input type = "Text" class = "form-control" id = "City" name = "City" placeholder = "City" value = "<?php echo Input::get("City"); ?>" required>
                                </div>
                            </div>

                            <div class = "col-md-6 col-sm-10">
                                <div class = "input-group">
                                    <span class = "input-group-addon"> <span class = "glyphicon glyphicon-home"> </span> </span>
                                    <select id = "Country" name = "Country" class = "form-control" required>
                                        <option value=""> Country </option>
                                    	<option value="Afghanistan">Afghanistan</option>
                                    	<option value="Åland Islands">Åland Islands</option>
                                    	<option value="Albania">Albania</option>
                                    	<option value="Algeria">Algeria</option>
                                    	<option value="American">American Samoa</option>
                                    	<option value="Andorra">Andorra</option>
                                    	<option value="Angola">Angola</option>
                                    	<option value="Anguilla">Anguilla</option>
                                    	<option value="Antarctica">Antarctica</option>
                                    	<option value="Antigua and Barbuda">Antigua and Barbuda</option>
                                    	<option value="Argentina">Argentina</option>
                                    	<option value="Armenia">Armenia</option>
                                    	<option value="Aruba">Aruba</option>
                                    	<option value="Australia">Australia</option>
                                    	<option value="Austria">Austria</option>
                                    	<option value="Azerbaijan">Azerbaijan</option>
                                    	<option value="Bahamas">Bahamas</option>
                                    	<option value="Bahrain">Bahrain</option>
                                    	<option value="Bangladesh">Bangladesh</option>
                                    	<option value="Barbados">Barbados</option>
                                    	<option value="Belarus">Belarus</option>
                                    	<option value="Belgium">Belgium</option>
                                    	<option value="Belize">Belize</option>
                                    	<option value="Benin">Benin</option>
                                    	<option value="Bermuda">Bermuda</option>
                                    	<option value="Bhutan">Bhutan</option>
                                    	<option value="Bolivia, Plurinational State of">Bolivia, Plurinational State of</option>
                                    	<option value="Bonaire, Sint Eustatius and Sab">Bonaire, Sint Eustatius and Saba</option>
                                    	<option value="Bosnia and Herzegovina">Bosnia and Herzegovina</option>
                                    	<option value="Botswana">Botswana</option>
                                    	<option value=">Bouvet Island">Bouvet Island</option>
                                    	<option value="Brazil">Brazil</option>
                                    	<option value="British Indian Ocean Territory">British Indian Ocean Territory</option>
                                    	<option value="Brunei Darussalam">Brunei Darussalam</option>
                                    	<option value="Bulgaria">Bulgaria</option>
                                    	<option value="Burkina Faso">Burkina Faso</option>
                                    	<option value="Burundi">Burundi</option>
                                    	<option value="Cambodia">Cambodia</option>
                                    	<option value="Cameroon">Cameroon</option>
                                    	<option value="Canada">Canada</option>
                                    	<option value="Cape Verde">Cape Verde</option>
                                    	<option value="Cayman Islands">Cayman Islands</option>
                                    	<option value="Central African Republic">Central African Republic</option>
                                    	<option value="Chad">Chad</option>
                                    	<option value="Chile">Chile</option>
                                    	<option value="China">China</option>
                                    	<option value="Christmas Island</">Christmas Island</option>
                                    	<option value="Cocos (Keeling) Islands">Cocos (Keeling) Islands</option>
                                    	<option value="Colombia">Colombia</option>
                                    	<option value="Comoros">Comoros</option>
                                    	<option value="Congo">Congo</option>
                                    	<option value="Congo, the Democratic Republic of the">Congo, the Democratic Republic of the</option>
                                    	<option value="Cook Islands">Cook Islands</option>
                                    	<option value="Costa Rica">Costa Rica</option>
                                    	<option value="Côte d'Ivoire">Côte d'Ivoire</option>
                                    	<option value="Croatia">Croatia</option>
                                    	<option value="Cuba">Cuba</option>
                                    	<option value="Curaçao">Curaçao</option>
                                    	<option value="Cyprus">Cyprus</option>
                                    	<option value="Czech Republic">Czech Republic</option>
                                    	<option value="Denmark">Denmark</option>
                                    	<option value="Djibouti">Djibouti</option>
                                    	<option value="Dominica">Dominica</option>
                                    	<option value="Dominican Republic">Dominican Republic</option>
                                    	<option value="Ecuador">Ecuador</option>
                                    	<option value="Egypt">Egypt</option>
                                    	<option value="El Salvador">El Salvador</option>
                                    	<option value="Equatorial Guinea">Equatorial Guinea</option>
                                    	<option value="Eritrea">Eritrea</option>
                                    	<option value="Estonia">Estonia</option>
                                    	<option value="Ethiopia">Ethiopia</option>
                                    	<option value="Falkland Islands (Malvinas)">Falkland Islands (Malvinas)</option>
                                    	<option value="Faroe Islands">Faroe Islands</option>
                                    	<option value="Fiji">Fiji</option>
                                    	<option value="Finland">Finland</option>
                                    	<option value="France">France</option>
                                    	<option value="French Guiana">French Guiana</option>
                                    	<option value="French Polynesia">French Polynesia</option>
                                    	<option value="French Southern Territories">French Southern Territories</option>
                                    	<option value="Gabon">Gabon</option>
                                    	<option value="Gambia">Gambia</option>
                                    	<option value="Georgia">Georgia</option>
                                    	<option value="Germany">Germany</option>
                                    	<option value="Ghana">Ghana</option>
                                    	<option value="Gibraltar">Gibraltar</option>
                                    	<option value="Greece">Greece</option>
                                    	<option value="Greenland">Greenland</option>
                                    	<option value="Grenada">Grenada</option>
                                    	<option value="Guadeloupe">Guadeloupe</option>
                                    	<option value="Guam">Guam</option>
                                    	<option value="Guatemala">Guatemala</option>
                                    	<option value="Guernsey">Guernsey</option>
                                    	<option value="Guinea">Guinea</option>
                                    	<option value="Guinea">Guinea-Bissau</option>
                                    	<option value="Guyana">Guyana</option>
                                    	<option value="Haiti">Haiti</option>
                                    	<option value="Heard Island and McDonald Islands">Heard Island and McDonald Islands</option>
                                    	<option value="Holy See (Vatican City State)">Holy See (Vatican City State)</option>
                                    	<option value="Honduras">Honduras</option>
                                    	<option value="Hong Kong">Hong Kong</option>
                                    	<option value="Hungary">Hungary</option>
                                    	<option value="Iceland">Iceland</option>
                                    	<option value="India">India</option>
                                    	<option value="Indonesia">Indonesia</option>
                                    	<option value="Iran, Islamic Republic of">Iran, Islamic Republic of</option>
                                    	<option value="Iraq">Iraq</option>
                                    	<option value="Ireland">Ireland</option>
                                    	<option value="Isle of Man">Isle of Man</option>
                                    	<option value="Israel">Israel</option>
                                    	<option value="Italy">Italy</option>
                                    	<option value="Jamaica">Jamaica</option>
                                    	<option value="Japan">Japan</option>
                                    	<option value="Jersey">Jersey</option>
                                    	<option value="Jordan">Jordan</option>
                                    	<option value="Kazakhstan">Kazakhstan</option>
                                    	<option value="Kenya">Kenya</option>
                                    	<option value="Kiribati">Kiribati</option>
                                    	<option value="Korea, Democratic People's Republic of">Korea, Democratic People's Republic of</option>
                                    	<option value="Korea, Republic of">Korea, Republic of</option>
                                    	<option value="Kuwait">Kuwait</option>
                                    	<option value="Kyrgyzstan">Kyrgyzstan</option>
                                    	<option value="Lao People's Democratic Republic">Lao People's Democratic Republic</option>
                                    	<option value="Latvia">Latvia</option>
                                    	<option value="Lebanon">Lebanon</option>
                                    	<option value="Lesotho">Lesotho</option>
                                    	<option value="Liberia">Liberia</option>
                                    	<option value="Libya">Libya</option>
                                    	<option value="Liechtenstein">Liechtenstein</option>
                                    	<option value="Lithuania">Lithuania</option>
                                    	<option value="Luxembourg">Luxembourg</option>
                                    	<option value="Macao">Macao</option>
                                    	<option value="Macedonia, the former Yugoslav Republic of">Macedonia, the former Yugoslav Republic of</option>
                                    	<option value="Madagascar">Madagascar</option>
                                    	<option value="Malawi">Malawi</option>
                                    	<option value="Malaysia">Malaysia</option>
                                    	<option value="Maldives">Maldives</option>
                                    	<option value="Mali">Mali</option>
                                    	<option value="Malta">Malta</option>
                                    	<option value="Marshall Islands">Marshall Islands</option>
                                    	<option value="Martinique">Martinique</option>
                                    	<option value="Mauritania">Mauritania</option>
                                    	<option value="Mauritius">Mauritius</option>
                                    	<option value="Mayotte">Mayotte</option>
                                    	<option value="Mexico">Mexico</option>
                                    	<option value="Micronesia, Federated States of">Micronesia, Federated States of</option>
                                    	<option value="Moldova, Republic of">Moldova, Republic of</option>
                                    	<option value="Monaco">Monaco</option>
                                    	<option value="Mongolia">Mongolia</option>
                                    	<option value="Montenegro">Montenegro</option>
                                    	<option value="Montserrat">Montserrat</option>
                                    	<option value="Morocco">Morocco</option>
                                    	<option value="Mozambique">Mozambique</option>
                                    	<option value="Myanmar">Myanmar</option>
                                    	<option value="Namibia">Namibia</option>
                                    	<option value="Nauru">Nauru</option>
                                    	<option value="Nepal">Nepal</option>
                                    	<option value="Netherlands">Netherlands</option>
                                    	<option value="New Caledonia">New Caledonia</option>
                                    	<option value="New Zealand">New Zealand</option>
                                    	<option value="Nicaragua">Nicaragua</option>
                                    	<option value="Niger">Niger</option>
                                    	<option value="Nigeria">Nigeria</option>
                                    	<option value="Niue">Niue</option>
                                    	<option value="Norfolk Island">Norfolk Island</option>
                                    	<option value="Northern Mariana Islands">Northern Mariana Islands</option>
                                    	<option value="Norway">Norway</option>
                                    	<option value="Oman">Oman</option>
                                    	<option value="Pakistan">Pakistan</option>
                                    	<option value="Palau">Palau</option>
                                    	<option value="Palestinian Territory, Occupied">Palestinian Territory, Occupied</option>
                                    	<option value="Panama">Panama</option>
                                    	<option value="Papua New Guinea">Papua New Guinea</option>
                                    	<option value="Paraguay">Paraguay</option>
                                    	<option value="Peru">Peru</option>
                                    	<option value="Philippines">Philippines</option>
                                    	<option value="Pitcairn">Pitcairn</option>
                                    	<option value="Poland">Poland</option>
                                    	<option value="Portugal">Portugal</option>
                                    	<option value="Puerto Rico">Puerto Rico</option>
                                    	<option value="Qatar">Qatar</option>
                                    	<option value="Réunion">Réunion</option>
                                    	<option value="Romania">Romania</option>
                                    	<option value="Russian Federation">Russian Federation</option>
                                    	<option value="Rwanda">Rwanda</option>
                                    	<option value="Saint Barthélemy">Saint Barthélemy</option>
                                    	<option value="Saint Helena, Ascension and Tristan da Cunha">Saint Helena, Ascension and Tristan da Cunha</option>
                                    	<option value="Saint Kitts and Nevis">Saint Kitts and Nevis</option>
                                    	<option value="Saint Lucia">Saint Lucia</option>
                                    	<option value="Saint Martin (French part)">Saint Martin (French part)</option>
                                    	<option value="Saint Pierre and Miquelon">Saint Pierre and Miquelon</option>
                                    	<option value="Saint Vincent and the Grenadines">Saint Vincent and the Grenadines</option>
                                    	<option value="Samoa">Samoa</option>
                                    	<option value="San Marino">San Marino</option>
                                    	<option value="Sao Tome and Principe">Sao Tome and Principe</option>
                                    	<option value="Saudi Arabia">Saudi Arabia</option>
                                    	<option value="Senegal">Senegal</option>
                                    	<option value="Serbia">Serbia</option>
                                    	<option value="Seychelles">Seychelles</option>
                                    	<option value="Sierra Leone">Sierra Leone</option>
                                    	<option value="Singapore">Singapore</option>
                                    	<option value="Sint Maarten (Dutch part)">Sint Maarten (Dutch part)</option>
                                    	<option value="Slovakia">Slovakia</option>
                                    	<option value="Slovenia">Slovenia</option>
                                    	<option value="Solomon Islands">Solomon Islands</option>
                                    	<option value="Somalia">Somalia</option>
                                    	<option value="South Africa">South Africa</option>
                                    	<option value="South Georgia and the South Sandwich Islands">South Georgia and the South Sandwich Islands</option>
                                    	<option value="South Sudan">South Sudan</option>
                                    	<option value="Spain">Spain</option>
                                    	<option value="Sri Lanka">Sri Lanka</option>
                                    	<option value="Sudan">Sudan</option>
                                    	<option value="Suriname">Suriname</option>
                                    	<option value="Svalbard and Jan Mayen">Svalbard and Jan Mayen</option>
                                    	<option value="Swaziland">Swaziland</option>
                                    	<option value="Sweden">Sweden</option>
                                    	<option value="Switzerland">Switzerland</option>
                                    	<option value="Syrian Arab Republic">Syrian Arab Republic</option>
                                    	<option value="Taiwan, Province of China">Taiwan, Province of China</option>
                                    	<option value="Tajikistan">Tajikistan</option>
                                    	<option value="Tanzania, United Republic of">Tanzania, United Republic of</option>
                                    	<option value="Thailand">Thailand</option>
                                    	<option value="Timor-Leste">Timor-Leste</option>
                                    	<option value="Togo">Togo</option>
                                    	<option value="Tokelau">Tokelau</option>
                                    	<option value="Tonga">Tonga</option>
                                    	<option value="Trinidad and Tobago">Trinidad and Tobago</option>
                                    	<option value="Tunisia">Tunisia</option>
                                    	<option value="Turkey">Turkey</option>
                                    	<option value="Turkmenistan">Turkmenistan</option>
                                    	<option value="Turks and Caicos Islands">Turks and Caicos Islands</option>
                                    	<option value="Tuvalu">Tuvalu</option>
                                    	<option value="Uganda">Uganda</option>
                                    	<option value="Ukraine">Ukraine</option>
                                    	<option value="United Arab Emirates">United Arab Emirates</option>
                                    	<option value="United Kingdom">United Kingdom</option>
                                    	<option value="United States">United States</option>
                                    	<option value="United States Minor Outlying Islands">United States Minor Outlying Islands</option>
                                    	<option value="Uruguay">Uruguay</option>
                                    	<option value="Uzbekistan">Uzbekistan</option>
                                    	<option value="Vanuatu">Vanuatu</option>
                                    	<option value="Venezuela, Bolivarian Republic of">Venezuela, Bolivarian Republic of</option>
                                    	<option value="Viet Nam">Viet Nam</option>
                                    	<option value="Virgin Islands, British">Virgin Islands, British</option>
                                    	<option value="Virgin Islands, U.S.">Virgin Islands, U.S.</option>
                                    	<option value="Wallis and Futuna">Wallis and Futuna</option>
                                    	<option value="Western Sahara">Western Sahara</option>
                                    	<option value="Yemen">Yemen</option>
                                    	<option value="Zambia">Zambia</option>
                                    	<option value="Zimbabwe">Zimbabwe</option>
                                    </select>
                                </div>
                            </div>
                        </div>

                        <!--Birthday-->
                        <div class = "row">
                            <div class = "col-md-6 col-sm-10">
                                <div class = "input-group">
                                    <span class = "input-group-addon"> <span class = "glyphicon glyphicon-calendar"> </span> </span>
                                    <input type = "text" name = "BirthDay" class = "form-control" id = "BirthDay" size = "30" value = "<?php echo Input::get("BirthDay"); ?>" placeholder="Birthday" required>
                                </div>
                            </div>

                            <div class = "col-md-6 col-sm-10">
                                <div class = "input-group">
                                    <span class = "input-group-addon"> Age </span>
                                    <input type = "number" name = "Age" class = "form-control" id = "Age" placeholder="Age" min = "1" max = "200" value = "<?php echo Input::get("Age"); ?>" required>
                                </div>
                            </div>
                        </div>

                        <div class = "row">
                            <div class = "col-md-10 col-sm-10">
                                <h4> <span class="label label-success">2</span> Account Information </h4>
                            </div>
                        </div>

                        <div class = "row">
                            <div class = "col-md-6 col-sm-10">
                                <div class = "input-group">
                                    <span class = "input-group-addon"> <span class = "glyphicon glyphicon-user"> </span> </span>
                                    <input type = "Text" class = "form-control" id = "Username" name = "Username" placeholder = "Username" value = "<?php echo Input::get("Username"); ?>" required>
                                </div>
                            </div>
                            <div class = "col-md-6 col-sm-10">
                                <div class = "input-group">
                                    <span class = "input-group-addon"> <span class = "glyphicon glyphicon-envelope"> </span> </span>
                                    <input type = "Email" class = "form-control" id = "Email" name = "Email" placeholder = "Email" value = "<?php echo Input::get("Email"); ?>" required>
                                </div>
                            </div>
                        </div>

                        <div class = "row">
                            <div class = "col-md-6 col-sm-10">
                                <div class = "input-group">
                                    <span class = "input-group-addon"> <span class = "glyphicon glyphicon-lock"> </span> </span>
                                    <input type = "Password" class = "form-control" id = "Password" name = "Password" placeholder = "Password" required>
                                </div>
                            </div>
                            <div class = "col-md-6 col-sm-10">
                                <div class = "input-group">
                                    <span class = "input-group-addon"> <span class = "glyphicon glyphicon-lock"> </span> </span>
                                    <input type = "Password" class = "form-control" id = "Confirm_Password" name = "Confirm_Password" placeholder = "Confirm Password" required>
                                </div>
                            </div>
                        </div>

                        <div class = "row">
                            <div class = "col-md-10 col-sm-10">
                                <h4> <span class="label label-success">3</span> A Few Words About Yourself </h4>
                            </div>
                        </div>

                        <div class = "row">
                            <div class = "com-md-12 col-sm-12">
                                <div class="form-group">
                                    <textarea class = "form-control" rows= "5" id = "Description" name = "Description"><?php echo Input::get("Description"); ?></textarea>
                                </div>
                            </div>
                        </div>

                        <div class = "row">
                            <div class = "col-md-offset-10 col-md-2">
                                <input type = "hidden" name = "Token" value = "<?php echo Token::generateToken(); ?>">
                                <input type = "submit" class = "btn btn-success btn-md" id = "Register" value = "Create my Account">


                            </div>
                        </div>

                        <div class = "row">
                            <div class = "col-sm-12" id = "ErrorNotification">
                                <?php
                                if (count($_Errors) > 0) {
                                    foreach ($validation->errors() as $error) {
                                        echo "<div class = 'alert alert-danger fade in'> <a href='#' class='close' data-dismiss='alert' aria-label='close'> &times; </a> <p> {$error} </p> </div>";
                                    }
                                }
                                ?>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
        <script src = "../../Script/jQuery/jquery-2.2.3.min.js"> </script>
        <script src = "../../CSS/bootstrap/js/bootstrap.min.js"> </script>
        <script src = "../../Script/jQuery-UI/jquery-ui.js"> </script>
        <script src = "../../Script/Custom/Register.js"> </script>
    </Body>
</HTML>
