<?php
require_once("../../Tools/Initialization.php");

$user = new User();
$group = new Group();
$friends = new Friend();
$Notification = new Notification();
$Message = new Message();

if(!$user->isLoggedIn()) {
    Redirect::to("../Login.php");
}

$validator = null;
$validation = null;

$_Errors = array();
$_Success = false;

if (Input::exists("POST")) {
    if (Token::checkToken(Input::get("Token"))) {
        $validator = new Validation();
        $validation = $validator->check($_POST, array(
        "Current_Password" => array(
            "Required" => true
        ),

        "New_Password" => array(
            "Required" => true,
            "Minimum" => 6,
            "Maximum" => 25
        ),

        "Confirm_Password" => array(
            "Required" => true,
            "Minimum" => 6,
            "Maximum" => 25,
            "Matches" => "New_Password"
        )
        ));
    }
}

if ($validation != null) {
    if ($validation->passed()) {
        try {
            if (Hash::make(Input::get("Current_Password"), $user->data()->Salt) != $user->data()->Password) {
                $_Errors[] = "The Current Password is Wrong!";
            }
            else {
                $salt = Hash::salt(32);
                $user->update(array(
                    "Password" => Hash::make(Input::get("New_Password"), $salt),
                    "Salt" => $salt
                ));

                $Notification->addNotification($user->data()->User_ID, "You Have Successfully Changed Your Password");
                $_Success = true;
            }
        }
        catch (Exception $e) {
            die($e);
        }
    }

    else {
        $_Success = false;
        $_Errors = $validation->errors();
    }
}
?>

<!DOCTYPE HTML>

<HTML>
    <Head>
        <Title> Change Password </Title>
        <link rel = "Stylesheet" type = "text/css" href = "../../CSS/bootstrap/css/bootstrap.min.css">
        <link rel = "stylesheet" type = "text/css" href = "../../CSS/Custom/Page.css">
        <meta name = "viewport" content="width=device-width, initial-scale=1">
        <meta charset="utf-8">
    </Head>

    <Body>
        <?php require_once("../Template/Navigation.php");?>

        <div class = "jumbotron">
            <div class = "row">
                <div class = "col-md-3 col-sm-10 container">
                    <?php require_once("../Template/SettingSidebar.php"); ?>
                </div>

                <div class = "col-md-offset-1 col-md-6 col-sm-8">
                    <form class = "form-horizontal" role = "form" method = "POST">
                        <fieldset>
                            <legend> Change Password</legend>
                            <div class = "form-group">
                                <label class="control-label col-sm-3" for="Currnet_Password"> Current Password</label>
                                <div class="col-sm-9">
                                    <input type = "Password" class = "form-control" id = "Current_Password" name = "Current_Password" required>
                                </div>
                            </div>

                            <div class = "form-group">
                                <label class="control-label col-sm-3" for="New_Password"> New Password</label>
                                <div class="col-sm-9">
                                    <input type = "Password" class = "form-control" id = "New_Password" name = "New_Password" required>
                                </div>
                            </div>

                            <div class = "form-group">
                                <label class="control-label col-sm-3" for="Confirm_Password"> Confirm Password</label>
                                <div class="col-sm-9">
                                    <input type = "Password" class = "form-control" id = "Confirm_Password" name = "Confirm_Password" required>
                                </div>
                            </div>

                            <div class = "form-group">
                                <div class = "col-sm-offset-3 col-sm-10">
                                    <input type = "hidden" name = "Token" value = "<?php  echo Token::generateToken(); ?>">
                                    <button type = "submit" class = "btn btn-primary"> Change Password </button>
                                </div>
                            </div>
                        </fieldset>
                    </form>

                    <div class = "col-sm-offset-3 col-sm-10">
                        <?php
                        if (count($_Errors) > 0) {
                            foreach ($_Errors as $error) {
                                echo "<div class = 'alert alert-danger' id = 'ErrorNotification'> <a href='#' class='close' data-dismiss='alert' aria-label='close'> &times; </a> <p> {$error} </p> </div>";
                            }
                        }

                        else if ($_Success) {
                            echo "<div class = 'alert alert-success' id = 'ErrorNotification'> <a href='#' class='close' data-dismiss='alert' aria-label='close'> &times; </a> <p> You Have Successfully Changed Your Account Password. </p> </div>";
                        }

                        ?>
                    </div>
                </div>
            </div>
        </div>
        <script src = "../../Script/jQuery/jquery-2.2.3.min.js"> </script>
        <script src = "../../CSS/bootstrap/js/bootstrap.min.js"> </script>
        <script src = "../../Script/jQuery-UI/jquery-ui.js"> </script>
        <script src = "../../Ajax/Search/Search.js"> </script>
    </Body>
</HTML>
