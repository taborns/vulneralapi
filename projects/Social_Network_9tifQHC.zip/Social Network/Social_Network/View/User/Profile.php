<?php
require_once("../../Tools/Initialization.php");

$user = new User();
$group = new Group();
$friends = new Friend();
$Notification = new Notification();
$Comments = new Comment();
$Message = new Message();
$Post = new Post();

$User_ID = $user->data()->User_ID;
$Profile_Picture = $user->data()->Profile_Picture;


if(!$user->isLoggedIn()) {
    Redirect::to("../Login.php");
}
?>

<!DOCTYPE HTML>

<HTML>
    <Head>
        <Title> Your Profile </Title>
        <link rel = "stylesheet" type = "text/css" href = "../../CSS/bootstrap/css/bootstrap.min.css">
        <link rel = "stylesheet" type = "text/css" href = "../../CSS/Custom/Page.css">
        <meta name = "viewport" content="width=device-width, initial-scale=1">
        <meta charset = "utf-8">
    </Head>
    <Body>
        <?php require_once("../Template/Navigation.php"); ?>

        <div class = "jumbotron">
            <div class = "row">
                <div class = "col-md-3 col-sm-10 container">
                    <?php require_once("../Template/LSidebar.php"); ?>
                </div>

                <div class = "col-md-8 col-sm-8">
                    <div class = "row well well-sm">
                        <h4 class = "col-sm-6"> Profile </h4>
                        <a href = "<?php echo Link::get("EditProfile.php"); ?>" class = "col-sm-offset-4 col-sm-2 btn btn-primary"> Edit Profile </a>

                    </div>

                    <div class = "row">
                        <div class = "col-md-3 col-sm-10">
                             <img src="<?php echo $Profile_Picture; ?>" class="img-thumbnail" alt="Profile Picture" width="100%" height="100%">
                             <a href = "<?php echo Link::get("ChangeProfilePicture.php"); ?>" class = "btn btn-primary col-sm-12"> <span class = "glyphicon glyphicon-edit"> </span> Change Profile Picture </a>
                        </div>

                        <div class = "col-md-offset-1 col-md-8 col-sm-10">
                            <table class="table table-hover">
                                <thead>
                                    <tr>
                                        <th> <span class = 'glyphicon glyphicon-info-sign'> </span> Account Information </th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <tr>
                                        <td class = "text-primary"> Username </td>
                                        <td> <?php echo $user->data()->Username; ?> </td>
                                    </tr>
                                    <tr>
                                        <td class = "text-primary"> Fullname </td>
                                        <td> <?php echo $user->data()->First_Name . " " .$user->data()->Last_Name; ?> </td>
                                    </tr>
                                    <tr>
                                        <td class = "text-primary"> Email </td>
                                        <td> <?php echo $user->data()->Email; ?> </td>
                                    </tr>
                                    <tr>
                                        <td class = "text-primary"> Age </td>
                                        <td> <?php echo $user->data()->Age; ?> </td>
                                    </tr>
                                    <tr>
                                        <td class = "text-primary"> Birthday </td>
                                        <td> <?php echo $user->data()->Birthday; ?> </td>
                                    </tr>
                                    <tr>
                                        <td class = "text-primary"> Country </td>
                                        <td> <?php echo $user->data()->Country; ?> </td>
                                    </tr>
                                    <tr>
                                        <td class = "text-primary"> City </td>
                                        <td> <?php echo $user->data()->City; ?> </td>
                                    </tr>
                                    <tr>
                                        <td class = "text-primary"> Gender </td>
                                        <td> <?php echo $user->data()->Gender; ?> </td>
                                    </tr>
                                    <tr>
                                        <td class = "text-primary"> About Me </td>
                                        <td> <?php echo $user->data()->About_Me; ?> </td>
                                    </tr>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>

            <div class = "row">
                <div class = "col-md-offset-3 col-md-8 col-sm-10 container">
                    <div class = "panel panel-default">
                        <div class = "panel-heading">
                            Your Posts
                        </div>

                        <div class = "panel-body" id = "My_Post_List">
                            <?php
                            $MyPosts = $Post->getMyPosts($user->data()->User_ID);

                            if (count($MyPosts) == 0) {
                                echo "<div class = 'alert alert-danger'> <strong> Empty! </strong> No Posts. </div>";
                            }

                            else {
                                foreach ($MyPosts as $Post) {
                                    $_Comments_List = $Comments->getAllPostComments($Post["Post_ID"]);
                                    echo Content::getPostPanel($user->data()->User_ID, $Post["Post_ID"], $Post["Text"], $Post["Date"], $Post["Likes"], $user->data()->User_ID, $user->getUsername($user->data()->User_ID), $_Comments_List, $Post["Image"]);
                                }
                            }
                            ?>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <script src = "../../Script/jQuery/jquery-2.2.3.min.js"> </script>
        <script src = "../../CSS/bootstrap/js/bootstrap.min.js"> </script>
        <script src = "../../Script/jQuery-UI/jquery-ui.js"> </script>
        <script src = "../../Ajax/Search/Search.js"> </script>
    </Body>
</HTML>
