<?php
require_once("../../Tools/Initialization.php");

$user = new User();
$group = new Group();
$friends = new Friend();
$Notification = new Notification();
$Message = new Message();
$Post = new Post();
$Comments = new Comment();


if(!$user->isLoggedIn()) {
    Redirect::to("../Login.php");
}


if (isset($_GET["ID"]) && $user->isPresent($_GET["ID"])) {
    $User_ID = $_GET["ID"];

    if ($user->data()->User_ID == $User_ID) {
        Redirect::to("Profile.php");
    }

}
else {
    Redirect::to("../Errors/UserError.php");
}

$_User_Information = $user->getUserInformation($User_ID);


?>

<!DOCTYPE HTML>

<HTML>
    <Head>
        <Title> <?php echo $user->getUsername($User_ID); ?> </Title>
        <link rel = "stylesheet" type = "text/css" href = "../../CSS/bootstrap/css/bootstrap.min.css">
        <link rel = "stylesheet" type = "text/css" href = "../../CSS/Custom/Page.css">
        <meta name = "viewport" content="width=device-width, initial-scale=1">
        <meta charset = "utf-8">
    </Head>

    <Body>
        <?php require_once("../Template/Navigation.php"); ?>

        <div class = "jumbotron">
            <div class = "row">
                <div class = "col-md-3 col-sm-10 container">
                    <?php require_once("../Template/LSidebar.php"); ?>
                </div>
                <div class = "col-md-8 col-sm-8">
                    <div class = "row">
                        <div class = "col-md-3 col-sm-10">
                            <div class = "row">
                                <img src="<?php echo $_User_Information["Profile_Picture"]; ?>" class="img-thumbnail" alt="Profile Picture" width="100%" height="100%">
                            </div>

                            <div class = "row">

                            </div>
                        </div>

                        <div class = "col-md-offset-1 col-md-8 col-sm-10">
                            <table class="table table-hover">
                                <thead>
                                    <tr>
                                        <th> <span class = 'glyphicon glyphicon-info-sign'> </span>  User Information </th>
                                        <th>
                                            <div id = "AccountOption">
                                            <?php
                                                if ($friends->isFriend($user->data()->User_ID, $User_ID)) {
                                                    $Message_Link = htmlentities(Link::get("Message.php?ID={$User_ID}"));

                                                    echo "<div class = 'row'> <div class = 'col-sm-5'>";
                                                    echo "<button class = 'btn btn-primary' onclick = 'blockUser({$User_ID}, {$user->data()->User_ID})'> <span class = 'glyphicon glyphicon-remove'> </span> Block Friend </button>";
                                                    echo "</div> <div class = 'col-sm-4'>";
                                                    echo "<a href = '{$Message_Link}' title = 'Message' class = 'btn btn-primary'> <span class = 'glyphicon glyphicon-envelope'> </span> Messages </a>";
                                                    echo "</div> </div>";
                                                }

                                                else if ($friends->hasRequested($User_ID, $user->data()->User_ID)) {
                                                    echo "<button class = 'btn btn-primary' onclick = 'cancelRequest({$User_ID}, {$user->data()->User_ID})'> <span class = 'glyphicon glyphicon-remove'> </span> Cancel Request </button>";
                                                }

                                                else if ($friends->hasRequested($user->data()->User_ID, $User_ID)) {
                                                    echo "<button class = 'btn btn-primary'  onclick = 'acceptRequest({$User_ID}, {$user->data()->User_ID})'> <span class = 'glyphicon glyphicon-ok'> </span> Accept Request </button>";

                                                }

                                                else {
                                                    echo "<button class = 'btn btn-primary' onclick = 'sendRequest({$User_ID}, {$user->data()->User_ID})'> <span class = 'glyphicon glyphicon-plus'> </span> Add Friend </button>";
                                                }


                                             ?>
                                            </div>
                                        </th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <tr>
                                        <td class = "text-primary"> Username </td>
                                        <td> <?php echo $_User_Information["Username"]; ?> </td>
                                    </tr>
                                    <tr>
                                        <td class = "text-primary"> Fullname </td>
                                        <td> <?php echo $_User_Information["First_Name"]. " " . $_User_Information["Last_Name"]; ?> </td>
                                    </tr>
                                    <tr>
                                        <td class = "text-primary"> Email </td>
                                        <td> <?php echo $_User_Information["Email"]; ?> </td>
                                    </tr>
                                    <tr>
                                        <td class = "text-primary"> Age </td>
                                        <td> <?php echo $_User_Information["Age"]; ?> </td>
                                    </tr>
                                    <tr>
                                        <td class = "text-primary"> Birthday </td>
                                        <td> <?php echo $_User_Information["Birthday"]; ?> </td>
                                    </tr>
                                    <tr>
                                        <td class = "text-primary"> Country </td>
                                        <td> <?php echo $_User_Information["Country"]; ?> </td>
                                    </tr>
                                    <tr>
                                        <td class = "text-primary"> City </td>
                                        <td> <?php echo $_User_Information["City"]; ?> </td>
                                    </tr>
                                    <tr>
                                        <td class = "text-primary"> Gender </td>
                                        <td> <?php echo $_User_Information["Gender"]; ?> </td>
                                    </tr>
                                    <tr>
                                        <td class = "text-primary"> About Me </td>
                                        <td> <?php echo $_User_Information["About_Me"]; ?> </td>
                                    </tr>
                                </tbody>
                            </table>

                            <div class = "panel panel-primary">
                                <div class = "panel-heading">
                                    <?php echo  $_User_Information["Username"] ."'s Groups"?>
                                </div>
                                <div class = "panel-body">
                                    <table class = "table table-hover">
                                        <tbody>
                                            <?php
                                                $myGroups = $group->getUserGroups($User_ID);

                                                if (count($myGroups) > 0) {
                                                    foreach ($myGroups as $Group) {
                                                        $link = Link::get("Group.php?ID={$Group->Group_ID}");
                                                        echo "<tr> <td> <a href = '{$link}' title = '{$Group->Group_Name}'> {$Group->Group_Name} </a> </td> </tr>";
                                                    }
                                                }
                                                else {
                                                    echo "<tr> <th> <span class = 'glyphicon glyphicon-remove-sign'> </span> No Groups </th> </tr>";
                                                }
                                            ?>
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <div class = "row">
                <div class = "col-md-offset-3 col-md-8 col-sm-10 container">
                    <div class = "panel panel-default">
                        <div class = "panel-heading">
                            <?php echo $user->getUsername($User_ID) . "'s Posts"; ?>
                        </div>

                        <div class = "panel-body" id = "My_Post_List">
                            <?php
                            $MyPosts = $Post->getMyPosts($User_ID);

                            if (count($MyPosts) == 0) {
                                echo "<div class = 'alert alert-danger'> <strong> Empty! </strong> No Posts. </div>";
                            }

                            else {
                                foreach ($MyPosts as $Post) {
                                    $_Comments_List = $Comments->getAllPostComments($Post["Post_ID"]);
                                    echo Content::getPostPanel($user->data()->User_ID, $Post["Post_ID"], $Post["Text"], $Post["Date"], $Post["Likes"], $User_ID, $user->getUsername($User_ID), $_Comments_List, $Post["Image"]);
                                }
                            }
                            ?>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <script src = "../../Script/jQuery/jquery-2.2.3.min.js"> </script>
        <script src = "../../CSS/bootstrap/js/bootstrap.min.js"> </script>
        <script src = "../../Ajax/Comment/PostComment/Comment.js"> </script>
        <script src = "../../Ajax/Friends/Friends.js"> </script>
        <script src = "../../Ajax/Search/Search.js"> </script>
    </Body>
</HTML>
