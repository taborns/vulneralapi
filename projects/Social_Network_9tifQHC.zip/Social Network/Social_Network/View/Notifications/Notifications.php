<?php
require_once("../../Tools/Initialization.php");

$user = new User();
$group = new Group();
$friends = new Friend();
$Notification = new Notification();
$Message = new Message();

if(!$user->isLoggedIn()) {
    Redirect::to("../Login.php");
}

?>

<!DOCTYPE HTML>

<HTML>
    <Head>
        <Title> Notifications </Title>
        <link rel = "stylesheet" type = "text/css" href = "../../CSS/bootstrap/css/bootstrap.min.css">
        <link rel = "stylesheet" type = "text/css" href = "../../CSS/Custom/Page.css">
        <meta name = "viewport" content="width=device-width, initial-scale=1">
        <meta charset = "utf-8">
    </Head>
    <Body>
        <?php require_once("../Template/Navigation.php"); ?>
        <div class = "jumbotron">
            <div class = "row">
                <div class = "col-md-3 col-sm-10 container">
                    <?php require_once("../Template/LSidebar.php"); ?>
                </div>

                <div class = "col-md-8 col-sm-8">
                    <div class = "panel panel-default">
                        <div class = "panel-heading"> Notifications </div>
                        <div class = "panel-body" id = "Notifications_Table">
                            <table class="table table-hover">
                                <tbody>
                                <?php
                                $_All_Notifications = $Notification->getAllNotifications($user->data()->User_ID);

                                if (count($_All_Notifications)) {
                                    foreach ($_All_Notifications as $_Notification) {
                                        echo Content::getNotificationItemPanel($_Notification["Notification_ID"], $_Notification["Notification"], $_Notification["Date"]);
                                    }
                                }
                                else {
                                    echo "<div class = 'alert alert-info'> No Notifications </div>";
                                }

                                ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <script src = "../../Script/jQuery/jquery-2.2.3.min.js"> </script>
        <script src = "../../CSS/bootstrap/js/bootstrap.min.js"> </script>
        <script src = "../../Ajax/Search/Search.js"> </script>
    </Body>
</HTML>
