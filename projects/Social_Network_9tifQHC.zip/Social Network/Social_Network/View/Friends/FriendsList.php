<?php
require_once("../../Tools/Initialization.php");

$user = new User();
$group = new Group();
$friends = new Friend();
$Notification = new Notification();
$Message = new Message();

if(!$user->isLoggedIn()) {
    Redirect::to("../Login.php");
}


?>

<!DOCTYPE HTML>

<HTML>
    <Head>
        <Title> Friends </Title>
        <link rel = "stylesheet" type = "text/css" href = "../../CSS/bootstrap/css/bootstrap.min.css">
        <link rel = "stylesheet" type = "text/css" href = "../../CSS/Custom/Page.css">
        <meta name = "viewport" content="width=device-width, initial-scale=1">
        <meta charset = "utf-8">
    </Head>
    <Body>
        <?php require_once("../Template/Navigation.php"); ?>
        <div class = "jumbotron">
            <div class = "row">
                <div class = "col-md-3 col-sm-10 container">
                    <?php require_once("../Template/LSidebar.php"); ?>
                </div>

                <div class = "col-md-9 col-sm-8">
                    <div class = "row">
                        <div class = "col-md-8 col-sm-10">
                            <div class = "panel panel-default">
                                <?php $_Friends_List = $friends->getFriends($user->data()->User_ID); ?>
                                <div class = "panel-heading"> <span class = 'glyphicon glyphicon-user'> </span> Friends <span id = "Number_Of_Friends"> (<?php echo count($_Friends_List); ?>) </span> </div>
                                <div class = "panel-body" id = "FriendsLists">
                                    <table class = "table table-hover">
                                        <tbody>
                                            <div id = "Friends_Panel">
                                            <?php
                                                if (count($_Friends_List) > 0) {
                                                    foreach ($_Friends_List as $Friend) {
                                                        echo Content::getFriendsItemPanel($Friend["User_ID"], $Friend["Username"], $Friend["Email"], "acceptRequestPage");
                                                    }
                                                }
                                                else {
                                                    echo "<div class = 'alert alert-danger'>No Friends! </div>";
                                                }
                                            ?>
                                            </div>
                                        <tbody>
                                    </table>
                                </div>
                            </div>
                        </div>

                        <div class = "col-md-4">
                            <div class = "panel panel-default">
                                <?php $_Friend_Request_List = $friends->getFriendRequests($user->data()->User_ID); ?>
                                <div class = "panel-heading"> <span class = 'glyphicon glyphicon-user'> </span> Friend Requests <span id = "Number_Of_Requests"> (<?php echo count($_Friend_Request_List); ?>) </span> </div>
                                <div class = "panel-body"  id = "FriendRequestsLists">
                                    <table class = "table table-hover">
                                        <tbody id = "Friend_Request_Panel">
                                        <?php
                                            if (count($_Friend_Request_List) > 0) {
                                                foreach ($_Friend_Request_List as $Friend) {
                                                    echo Content::getFriendRequestItemRow($Friend["User_ID"], $Friend["Username"], $user->data()->User_ID);
                                                }
                                            }
                                            else {
                                                echo "<div class = 'alert alert-danger'>No Friend Requests! </div>";
                                            }
                                        ?>
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <script src = "../../Script/jQuery/jquery-2.2.3.min.js"> </script>
        <script src = "../../CSS/bootstrap/js/bootstrap.min.js"> </script>
        <script src = "../../Ajax/Friends/FriendLists.js"> </script>
        <script src = "../../Ajax/Search/Search.js"> </script>
    </Body>
</HTML>
