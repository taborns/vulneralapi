<div class = "panel panel-default" id = "Menu">
    <div class = "panel-body">
        <table class = "table table-hover">
            <thead>
                <tr> <th> Account Setting </th> </tr>
            </thead>
            <tbody>
                <tr> <th> <a href = "<?php echo Link::get("ChangePassword.php");?>" title = "Change Password"> <span class = "glyphicon glyphicon-lock"> </span> Change Password </a> </th> </tr>
                <tr> <th> <a href = "<?php echo Link::get("EditProfile.php");?>" title = "Edit Profile"> <span class = "glyphicon glyphicon-user"> </span> Edit Profile </a> </th> </tr>
                <tr> <th> <a href = "<?php echo Link::get("Logout.php");?>" title = "Logout"> <span class = "glyphicon glyphicon-off"> </span> Logout </a> </th> </tr>
            </tbody>
        </table>
    </div>
</div>

<div class = "panel panel-default" id = "Groups">
    <div class = "panel-body">
        <table class = "table table-hover">
            <thead>
                <tr> <th> Menu </th> </tr>
            </thead>
            <tbody>
                <tr> <th> <a href = "<?php echo Link::get("Profile.php");?>" title = "Profile"> <span class = "glyphicon glyphicon-user"> </span> Profile </a> </th> </tr>
                <tr> <th> <a href = "<?php echo Link::get("Message.php");?>" title = "Messages"> <span class = "glyphicon glyphicon-envelope"> </span> Message <span class = "badge"> <?php echo $Message->getUnreadMessageNumber($user->data()->User_ID);?> </span> </a> </th> </tr>
                <tr> <th> <a href = "<?php echo Link::get("GroupList.php");?>" title = "Groups"> <span class = "glyphicon glyphicon-globe"> </span> Groups <span class = "badge"> <?php echo $group->getMyGroupsNumber($user->data()->User_ID); ?> </span> </a> </th> </tr>
                <tr> <th> <a href = "<?php echo Link::get("Notification.php");?>" title = "Notifications"> <span class = "glyphicon glyphicon-comment"> </span> Notification <span class = "badge" id = "Sidebar_Notification_Number"> <?php echo $Notification->getNotificationsNumber($user->data()->User_ID); ?></span> </a> </th> </tr>
                <tr> <th> <a href = "<?php echo Link::get("Friends.php");?>" title = "Friends"> <span class = "glyphicon glyphicon-share"> </span> Friends <span class = "badge" id = "Friend_Request_Number"> <?php echo $friends->getFriendRequestsNumber($user->data()->User_ID);?> </span> </a> </th> </tr>
                <tr> <th> <a href = "<?php echo Link::get("Pictures.php");?>.php" title = "Pictures"> <span class = "glyphicon glyphicon-picture"> </span> Pictures </a> </th> </tr>
            </tbody>
        </table>
    </div>
</div>
