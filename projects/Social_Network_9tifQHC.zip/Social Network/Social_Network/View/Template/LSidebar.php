<div class = "panel panel-default" id = "Menu">
    <div class = "panel-body">
        <table class = "table table-hover">
            <thead>
                <tr> <th> Menu </th> </tr>
            </thead>
            <tbody>
                <tr> <th> <a href = "<?php echo Link::get("Profile.php"); ?>" title = "Profile"> <span class = "glyphicon glyphicon-user"> </span> Profile </a> </th> </tr>
                <tr> <th> <a href = "<?php echo Link::get("MessageList.php"); ?>" title = "Messages"> <span class = "glyphicon glyphicon-envelope"> </span> Message <span class = "badge"> <?php echo $Message->getUnreadMessageNumber($user->data()->User_ID);?> </span> </a> </th> </tr>
                <tr> <th> <a href = "<?php echo Link::get("GroupList.php"); ?>" title = "Groups"> <span class = "glyphicon glyphicon-globe"> </span> Groups <span class = "badge"> <?php echo $group->getMyGroupsNumber($user->data()->User_ID); ?> </span> </a> </th> </tr>
                <tr> <th> <a href = "<?php echo Link::get("Notifications.php"); ?>" title = "Notifications"> <span class = "glyphicon glyphicon-comment"> </span> Notification <span class = "badge" id = "Sidebar_Notification_Number"> <?php echo $Notification->getNotificationsNumber($user->data()->User_ID); ?></span> </a> </th> </tr>
                <tr> <th> <a href = "<?php echo Link::get("FriendsList.php"); ?>" title = "Friends"> <span class = "glyphicon glyphicon-share"> </span> Friends <span class = "badge" id = "Friend_Request_Number"> <?php echo $friends->getFriendRequestsNumber($user->data()->User_ID);?> </span> </a> </th> </tr>
                <tr> <th> <a href = "<?php echo Link::get("Pictures.php"); ?>" title = "Pictures"> <span class = "glyphicon glyphicon-picture"> </span> Pictures </a> </th> </tr>
            </tbody>
        </table>
    </div>
</div>

<div class = "panel panel-default" id = "Groups">
    <div class = "panel-body">
        <table class = "table table-hover">
            <thead>
                <tr> <th> Groups </th> </tr>
            </thead>
            <tbody>
                <?php
                    $myGroups = $group->getUserGroups($user->data()->User_ID);

                    if (count($myGroups) > 0) {
                        foreach ($myGroups as $Group) {
                            $link = Link::get("Group.php?ID={$Group->Group_ID}");
                            echo "<tr> <td> <a href = '{$link}' title = '{$Group->Group_Name}'> {$Group->Group_Name} </a> </td> </tr>";
                        }
                    }
                    else {
                        echo "<tr> <th> <span class = 'glyphicon glyphicon-remove-sign'> </span> No Groups </th> </tr>";
                    }
                ?>
            </tbody>
            <tfoot>
                <tr>
                    <td>
                        <a href = "<?php echo Link::get("AddGroup.php"); ?>" title = "Add Group" class = "btn btn-primary col-sm-offset-6 col-sm-6"> <span class = "glyphicon glyphicon-plus"> </span> Add Group </a>
                    </td>
                </tr>
            </tfoot>
        </table>
    </div>
</div>
