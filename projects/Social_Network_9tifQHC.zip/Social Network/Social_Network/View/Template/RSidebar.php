<div class = "panel panel-default">
    <div class = "panel-heading"> <span class = "glyphicon glyphicon-plus-sign"> </span> Friend Requests </div>
    <div class = "panel-body">
        <table class = "table table-hover">
            <tbody id = "Friend_Request_Panel">
                <?php
                    $_Friend_Request_List = $friends->getFriendRequests($user->data()->User_ID);
                    if (count($_Friend_Request_List) > 0) {
                        foreach ($_Friend_Request_List as $Friend) {
                            echo Content::getFriendRequestItemRow($Friend["User_ID"], $Friend["Username"], $user->data()->User_ID, "acceptRequestBar");
                        }
                    }
                    else {
                        echo "<tr> <td> <span class = 'glyphicon glyphicon-remove'> </span> No Friend Requests </td> </tr>";
                    }
                ?>
            </tbody>
        </table>
    </div>
</div>

<div class = "panel panel-default">
    <div class = "panel-heading text-primary"> <span class = "glyphicon glyphicon-comment"> </span> Notifications </div>
    <div class = "panel-body"  >
        <table class = "table table-hover">
            <tbody id = "Notification_Panel">
                <?php
                if (count($_Notifications_List) > 0) {
                    foreach ($_Notifications_List as $_Notification) {
                        echo Content::getNotificationItemRow($_Notification["Notification_ID"], $user->data()->User_ID, $_Notification["Notification"]);
                    }
                }
                else {
                    echo "<tr> <td> <span class = 'glyphicon glyphicon-remove'></span> No Notification </td> </tr>";
                }
                ?>
            </tbody>
        </table>
    </div>
</div>
