<nav class = "navbar navbar-inverse navbar-fixed-top" role = "navigation">
    <div class = "container-fluid">
        <div class = "navbar-header">
            <button type = "button" class = "navbar-toggle" data-toggle = "collapse" data-target = "#navbar-collapse">
                <span class = "sr-only"> Toggle Navigation </span>
                <span class = "icon-bar"> </span>
                <span class = "icon-bar"> </span>
                <span class = "icon-bar"> </span>
            </button>

            <a class = "navbar-brand" href = "#"> Social Network </a>
        </div>

        <div class = "collapse navbar-collapse" id = "navbar-collapse">
            <ul class = "nav navbar-nav">
                <li class = "active"> <a href = "<?php echo Link::get("Index.php"); ?>" title = "Home"> <span class = "glyphicon glyphicon-home"> </span> Home  </a> </li>
                <li> <a href = "<?php echo Link::get("Profile.php"); ?>" title = "Profile"> <span class = "glyphicon glyphicon-user"> </span> Profile </a> </li>
                <li> <a href = "<?php echo Link::get("Notifications.php"); ?>" title = "Notification"> <span class = "glyphicon glyphicon-comment"> </span> Notification <span class = "badge" id = "Navbar_Notification_Number"> <?php echo $Notification->getNotificationsNumber($user->data()->User_ID); ?></span> </a> </li>
                <li> <a href = "<?php echo Link::get("MessageList.php"); ?>" title = "Message"> <span class = "glyphicon glyphicon-envelope"> </span> Message <span class = "badge"> <?php echo $Message->getUnreadMessageNumber($user->data()->User_ID);?> </span> </a> </li>
            </ul>

            <form class = "navbar-form navbar-left" role = "search">
                <div class = "form-group search-query">
                    <input type = "text" class = "form-control" size = "25" placeholder = "Search" id = "Search" autocomplete="off">
                </div>
                <button type = "button" class = "btn btn-primary"> <span class = "glyphicon glyphicon-search"> </span> </button>

                <div>
                    <ul class="list-group" id = "SearchBar">
                    </ul>
                </div>
            </form>

            <ul class="nav navbar-nav navbar-right">
                <li>
                    <a href = "#" title = "Welcome">  Welcome
                        <span id = "Username"><?php echo htmlentities($user->data()->Username);?></span>
                    </a>
                </li>
                <li class = "dropdown">
                    <a href = "#" class = "dropdown-toggle" data-toggle = "dropdown"> <span class = 'glyphicon glyphicon-cog'> </span> Account Setting <span class = "caret"> </span> </a>
                    <ul class="dropdown-menu" role="menu">
                        <li><a href="<?php echo Link::get("EditProfile.php"); ?>" title = "Edit Profile"> <span class = "glyphicon glyphicon-pencil"></span> Edit Profile </a></li>
                        <li><a href="<?php echo Link::get("ChangePassword.php"); ?>" title = "Change Password"> <span class = "glyphicon glyphicon-lock"></span> Change Password </a></li>
                        <li><a href="<?php echo Link::get("Logout.php"); ?>" title = "Logout"> <span class = "glyphicon glyphicon-off"> </span> Logout </a> </li>
                    </ul>
                </li>
            </ul>
        </div>
    </div>
</nav>
