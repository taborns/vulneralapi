<?php
require_once("../../Tools/Initialization.php");

$user = new User();
$group = new Group();
$friends = new Friend();
$Notification = new Notification();
$Message = new Message();

if(!$user->isLoggedIn()) {
    Redirect::to("../Login.php");
}


$_Group_ID = $_GET["ID"];
$_Group_Information = $group->getGroupInformation($_Group_ID);

if ($_Group_Information["Group_Administrator"] != $user->data()->Username) {
    Redirect::to("../Errors/EditError.php");
}

$validator = null;
$validation = null;
$_Errors = null;

$_Success = false;

if (Input::exists("POST")) {
    if (Token::checkToken(Input::get("Token"))) {
        $validator = new Validation();
        $validation = $validator->check($_POST, array(
            "Description" => array(
                "Required" => true
            )
        ));
    }
}

if ($validation != null) {
    if ($validation->passed()) {
        $group->update($_Group_ID, array(
            "Description" => Input::get("Description")
        ));
        $_Success = true;
        $Notification->addNotification($user->data()->User_ID, "You Have Successfully Updated the Group ". $group->getGroupName($_Group_ID));
    }
    else {
        $_Success = false;
        $_Errors = $validation->errors();
    }
}
?>

<!DOCTYPE HTML>

<HTML>
    <Head>
        <Title> Edit <?php echo $_Group_Information["Group_Name"]; ?>  </Title>
        <link rel = "stylesheet" type = "text/css" href = "../../CSS/bootstrap/css/bootstrap.min.css">
        <link rel = "stylesheet" type = "text/css" href = "../../CSS/Custom/Page.css">
        <meta name = "viewport" content="width=device-width, initial-scale=1">
        <meta charset = "utf-8">
    </Head>
    <Body>
        <?php require_once("../Template/Navigation.php"); ?>

        <div class = "jumbotron">
            <div class = "row">
                <div class = "col-md-3 col-sm-10 container">
                    <?php require_once("../Template/LSidebar.php"); ?>
                </div>

                <div class = "col-md-offset-1 col-md-7 col-sm-8">
                    <form class = "form-horizontal" role = "form" method = "POST">
                        <fieldset>
                            <legend> Edit Group </legend>

                            <div class = "form-group">
                                <label class="control-label col-sm-3" for="Group_Name"> Group Name </label>
                                <div class="col-sm-9">
                                    <input type = "Text" class = "form-control" id = "Group_Name" name = "Group_Name" value = "<?php echo htmlentities($group->getGroupName($_Group_ID)); ?>" required disabled>
                                </div>
                            </div>

                            <div class = "form-group">
                                <label class="control-label col-sm-3" for="Description"> Description </label>
                                <div class="col-sm-9">
                                    <textarea class = "form-control" rows= "5" id = "Description" name = "Description"><?php echo htmlentities($group->getGroupDescription($_Group_ID)); ?></textarea>
                                </div>
                            </div>

                            <div class = "form-group">
                                <div class = "col-sm-offset-3 col-sm-10">
                                    <input type = "hidden" name = "Token" value = "<?php  echo Token::generateToken(); ?>">
                                    <button type = "submit" class = "btn btn-primary"> <span class = "glyphicon glyphicon-pencil"></span>Edit Group </button>
                                </div>
                            </div>
                        </fieldset>
                    </form>

                    <div class = "col-sm-offset-3 col-sm-10" id = "ErrorNotification">
                        <?php
                        if (count($_Errors) > 0) {
                            foreach ($_Errors as $error) {
                                echo "<div class = 'alert alert-danger' id = 'ErrorNotification'> <a href='#' class='close' data-dismiss='alert' aria-label='close'> &times; </a> <p> {$error} </p> </div>";
                            }
                        }

                        else if ($_Success) {
                            echo "<div class = 'alert alert-success' id = 'ErrorNotification'> <a href='#' class='close' data-dismiss='alert' aria-label='close'> &times; </a> <p> You Have Successfully Updated The Group. </p> </div>";
                        }

                        ?>
                    </div>
                </div>
            </div>
        </div>

        <script src = "../../Script/jQuery/jquery-2.2.3.min.js"> </script>
        <script src = "../../CSS/bootstrap/js/bootstrap.min.js"> </script>
        <script src = "../../Ajax/Search/Search.js"> </script>
    </Body>
</HTML>
