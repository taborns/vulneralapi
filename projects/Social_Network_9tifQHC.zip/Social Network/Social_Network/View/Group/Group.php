<?php
require_once("../../Tools/Initialization.php");

$user = new User();
$group = new Group();
$friends = new Friend();
$Notification = new Notification();
$Comments = new Comment();
$Message = new Message();

if(!$user->isLoggedIn()) {
    Redirect::to("../Login.php");
}

$_Group_ID = $_GET["ID"];
if (!$group->exists($_Group_ID)) {
    Redirect::to("../Errors/GroupError.php");
}
$_Group_Information = $group->getGroupInformation($_Group_ID);
?>

<!DOCTYPE HTML>

<HTML>
    <Head>
        <Title> <?php echo $_Group_Information["Group_Name"]; ?>  </Title>
        <link rel = "stylesheet" type = "text/css" href = "../../CSS/bootstrap/css/bootstrap.min.css">
        <link rel = "stylesheet" type = "text/css" href = "../../CSS/Custom/Page.css">
        <meta name = "viewport" content="width=device-width, initial-scale=1">
        <meta charset = "utf-8">
    </Head>
    <Body>
        <?php require_once("../Template/Navigation.php"); ?>

        <div class = "jumbotron">
            <div class = "row">
                <div class = "col-md-3 col-sm-10 container">
                    <?php require_once("../Template/LSidebar.php"); ?>
                </div>

                <div class = "col-md-5 col-sm-10">
                    <div class = "panel panel-default" id = "Content">
                        <?php
                            if ($group->hasMember($_Group_ID, $user->data()->User_ID)) {
                                echo '<form role = "form">
                                    <div class="form-group">
                                        <label for="comment"> Post </label>
                                        <textarea class="form-control" rows="2" id="Message"></textarea>
                                        <button type = "button" id = "PostButton" class = "btn btn-primary"> <span class = "glyphicon glyphicon-upload">  Post </button>
                                    </div>
                                </form>';
                            }
                        ?>
                        <div id = "Group_Posts">
                            <?php
                                $Posts = $group->getGroupPosts($_Group_ID);

                                if (count($Posts) == 0){
                                    echo "<div class = 'alert alert-info'> No Posts </div>";
                                }
                                else {
                                    foreach ($Posts as $Post) {
                                        $Username = ($Post->User_ID == $user->data()->User_ID) ? "You" : $user->getUsername($Post->User_ID);
                                        $_Comments_List = $Comments->getAllGroupPostComments($Post->Post_ID);
                                        echo Content::getGroupPostPanel($Post->Post_ID, $user->data()->User_ID ,$Post->User_ID, $Username , $Post->Date, $Post->Message, $Post->Likes, $Post->Group_ID, $_Comments_List);
                                    }
                                }

                            ?>
                        </div>
                    </div>
                </div>

                <div class = "col-md-4 col-sm-8">
                    <div class = "row">
                        <div class = "col-sm-12">
                            <div class = "panel panel-default">
                                <div class="panel-heading">
                                    <div class = "row">
                                        <div class= "col-sm-6 text-primary">
                                            <?php echo $_Group_Information["Group_Name"]; ?>
                                        </div>
                                        <div class = "col-sm-offset-2 col-sm-4">
                                            <a href = "
                                            <?php
                                                $linkText = null;
                                                if ($user->getUsername($user->data()->User_ID) == $_Group_Information["Group_Administrator"]) {
                                                    $linkText = "Edit Group";
                                                    $link = "EditGroup.php?ID=" . $_Group_ID;
                                                    echo htmlentities(Link::get($link));
                                                }

                                                else if ($group->hasMember($_Group_ID, $user->data()->User_ID)) {
                                                    $linkText = "Leave Group";
                                                    $link = "LeaveGroup.php?Group_ID=" . $_Group_ID . "&User_ID=" . $user->data()->User_ID;
                                                    echo htmlentities(Link::get($link));
                                                }
                                                else {
                                                    $linkText = "Join Group";
                                                    $link = "JoinGroup.php?Group_ID=" . $_Group_ID . "&User_ID=" . $user->data()->User_ID;
                                                    echo htmlentities(Link::get($link));
                                                }
                                            ?>
                                            " class = "btn btn-success btn-sm" id = "GroupOption"> <?php echo htmlentities($linkText); ?> </a>
                                        </div>
                                    </div>
                                </div>
                                <div class="panel-body" id = "DescriptionPanel">
                                    <table class="table table-hover">
                                        <thead>
                                            <tr>
                                                <th class = "sr-only" id = "Group_ID"><?php echo htmlentities($_Group_ID);?></th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <tr>
                                                <td class = "text-primary"> Group Name </td>
                                                <td class = "text-muted"> <?php echo htmlentities($_Group_Information["Group_Name"]); ?> </td>
                                            </tr>
                                            <tr>
                                                <td class = "text-primary"> Group Description </td>
                                                <td class = "text-muted"> <?php echo htmlentities($_Group_Information["Group_Description"]); ?> </td>
                                            </tr>

                                            <tr>
                                                <td class = "text-primary"> Administrator </td>
                                                <td class = "text-muted">
                                                    <?php
                                                        if ($_Group_Information["Group_Administrator"] == $user->data()->Username) {
                                                            echo "You";
                                                        }
                                                        else {
                                                            echo htmlentities($_Group_Information["Group_Administrator"]);
                                                        }
                                                    ?>
                                                </td>
                                            </tr>
                                            <tr>
                                                <td class = "text-primary"> Date </td>
                                                <td class = "text-muted"> <?php echo htmlentities($_Group_Information["Group_Date"]); ?> </td>
                                            </tr>
                                            <tr>
                                                <td class = "text-primary"> Number of Members </td>
                                                <td class = "text-muted"> <?php echo htmlentities($_Group_Information["Number_of_Members"]); ?> </td>
                                            </tr>
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                </div>

                <div class = "row">
                    <div class = "col-md-12 col-sm-10">
                        <div class = "panel panel-default">
                            <div class = "panel-heading"> Group Members </div>
                            <div class = "panel-body" id= "MemberPanel">
                                <table class="table table-hover" >
                                    <tbody>
                                        <?php
                                            if (count($_Group_Information["Group_Members"]) > 0) {
                                                foreach ($_Group_Information["Group_Members"] as $member) {
                                                    $member_ID = htmlentities($user->getUserID($member));
                                                    $link = htmlentities(Link::get("User.php?ID={$member_ID}"));
                                                    echo "<tr> <td> <a href = '$link' title = '{".htmlentities($member)."'> ".htmlentities($member)." </a> </td> </tr>";
                                                }
                                            }
                                            else {
                                                echo "<tr> <td> <span class = 'glyphicon glyphicon-remove'> </span> No Group Members </td> </tr>";
                                            }
                                        ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <script src = "../../Script/jQuery/jquery-2.2.3.min.js"> </script>
        <script src = "../../CSS/bootstrap/js/bootstrap.min.js"> </script>
        <script src = "../../Ajax/Group/Post/Group_Post.js"> </script>
        <script src = "../../Ajax/Like/Like.js"> </script>
        <script src = "../../Ajax/Comment/GroupComment/GroupComment.js"> </script>
        <script src = "../../Ajax/Search/Search.js"> </script>
    </Body>
</HTML>
