<?php
require_once("../../Tools/Initialization.php");

$user = new User();
$group = new Group();
$Notification = new Notification();

$_Database = Database::getInstance();

if(!$user->isLoggedIn()) {
    Redirect::to("../Login.php");
}

if (isset($_GET["Group_ID"]) && isset($_GET["User_ID"])) {
    $_Group_ID = $_GET["Group_ID"];
    $_User_ID = $_GET["User_ID"];
    $sql_one = "INSERT INTO `Group_Members` VALUES (?, ?)";

    $_Group_Member_Numbers = $group->getGroupMembersNumber($_Group_ID) + 1;
    $sql_two = "UPDATE `Groups` SET `Number_of_Members` = ? WHERE `Group_ID` = ?";

    if (!$_Database->query($sql_one, array($_Group_ID, $_User_ID))->error() && !$_Database->query($sql_two, array($_Group_Member_Numbers, $_Group_ID))->error()) {
        $Notification->addNotification($user->data()->User_ID, "You Have Joined ". $group->getGroupName($_Group_ID));
        Redirect::to("Group.php?ID=".$_Group_ID);
    }
    else {
        die();
    }
}
?>
