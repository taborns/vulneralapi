<?php
require_once("../../Tools/Initialization.php");

$user = new User();
$group = new Group();
$friends = new Friend();
$Notification = new Notification();
$Message = new Message();

if(!$user->isLoggedIn()) {
    Redirect::to("../Login.php");
}


$validator = null;
$validation = null;
$_Errors = null;

$_Success = false;

if (Input::exists("POST")) {
    if (Token::checkToken(Input::get("Token"))) {
        $validator = new Validation();
        $validation = $validator->check($_POST, array(
            "Group_Name" => array(
                "Required" => true,
                "Minimum" => 3,
                "Maximum" => 100,
                "Unique" => "Groups"
            ),
            "Description" => array(
                "Required" => true
            )
        ));
    }
}

if ($validation != null) {
    if ($validation->passed()) {
        $group_ID = Hash::make(Input::get("Group_Name"));
        $group->create(array(
            "Group_ID" => $group_ID,
            "Group_Name" => Input::get("Group_Name"),
            "Date" => date("Y-m-d H:i:s"),
            "Description" => Input::get("Description"),
            "Administrator" => $user->data()->User_ID,
            "Number_of_Members" => 1
        ));

        $user->addToGroup(array(
            "Group_ID" => $group_ID,
            "User_ID" => $user->data()->User_ID
        ));
        $Notification->addNotification($user->data()->User_ID, "You Have Successfully Created the Group " . Input::get("Group_Name"));
        $_Success = true;
    }
    else {
        $_Success = false;
        foreach ($validation->errors() as $error) {
            $_Errors[] = $error;
        }
    }
}
?>

<!DOCTYPE HTML>

<HTML>
    <Head>
        <Title> Add Group </Title>
        <link rel = "stylesheet" type = "text/css" href = "../../CSS/bootstrap/css/bootstrap.min.css">
        <link rel = "stylesheet" type = "text/css" href = "../../CSS/Custom/Page.css">
        <meta name = "viewport" content="width=device-width, initial-scale=1">
        <meta charset = "utf-8">
    </Head>

    <Body>
        <?php require_once("../Template/Navigation.php"); ?>

        <div class = "jumbotron">
            <div class = "row">
                <div class = "col-md-3 col-sm-10 container">
                    <?php require_once("../Template/LSidebar.php"); ?>
                </div>

                <div class = "col-md-offset-1 col-md-6 col-sm-8">
                    <form class = "form-horizontal" role = "form" method = "POST">
                        <fieldset>
                            <legend> Add Group </legend>

                            <div class = "form-group">
                                <label class="control-label col-sm-3" for="Group_Name"> Group Name </label>
                                <div class="col-sm-9">
                                    <input type = "Text" class = "form-control" id = "Group_Name" name = "Group_Name" required>
                                </div>
                            </div>

                            <div class = "form-group">
                                <label class="control-label col-sm-3" for="Description"> Description </label>
                                <div class="col-sm-9">
                                    <textarea class = "form-control" rows= "5" id = "Description" name = "Description"></textarea>
                                </div>
                            </div>

                            <div class = "form-group">
                                <div class = "col-sm-offset-3 col-sm-10">
                                    <input type = "hidden" name = "Token" value = "<?php  echo Token::generateToken(); ?>">
                                    <button type = "submit" class = "btn btn-primary"> <span class = "glyphicon glyphicon-plus"></span>Add Group </button>
                                </div>
                            </div>
                        </fieldset>
                    </form>

                    <div class = "col-sm-offset-3 col-sm-10" id = "ErrorNotification">
                        <?php
                        if (count($_Errors) > 0) {
                            foreach ($_Errors as $error) {
                                echo "<div class = 'alert alert-danger' id = 'ErrorNotification'> <a href='#' class='close' data-dismiss='alert' aria-label='close'> &times; </a> <p> {$error} </p> </div>";
                            }
                        }

                        else if ($_Success) {
                            echo "<div class = 'alert alert-success' id = 'ErrorNotification'> <a href='#' class='close' data-dismiss='alert' aria-label='close'> &times; </a> <p> You Have Successfully Created A Group. </p> </div>";
                        }

                        ?>
                    </div>
                </div>
            </div>
        </div>
        <script src = "../../Script/jQuery/jquery-2.2.3.min.js"> </script>
        <script src = "../../CSS/bootstrap/js/bootstrap.min.js"> </script>
        <script src = "../../Script/jQuery-UI/jquery-ui.js"> </script>
    </Body>
</HTML>
