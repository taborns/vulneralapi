<?php
require_once("../../Tools/Initialization.php");

$user = new User();
$group = new Group();
$friends = new Friend();
$Notification = new Notification();
$Message = new Message();

if(!$user->isLoggedIn()) {
    Redirect::to("../Login.php");
}

?>

<!DOCTYPE HTML>

<HTML>
    <Head>
        <Title> Groups </Title>
        <link rel = "stylesheet" type = "text/css" href = "../../CSS/bootstrap/css/bootstrap.min.css">
        <link rel = "stylesheet" type = "text/css" href = "../../CSS/Custom/Page.css">
        <meta name = "viewport" content="width=device-width, initial-scale=1">
        <meta charset = "utf-8">
    </Head>

    <Body>
        <?php require_once("../Template/Navigation.php"); ?>
        <div class = "jumbotron">
            <div class = "row">
                <div class = "col-md-3 col-sm-10 container">
                    <?php require_once("../Template/LSidebar.php"); ?>
                </div>

                <div class = "col-md-8 col-sm-8">
                    <div class = "row">
                        <div class = "panel panel-default">
                            <div class="panel-heading"> My Groups </div>
                            <div class = "panel-body" id = "MyGroups">
                                <?php
                                $myGroups = $group->getUserGroups($user->data()->User_ID);
                                if (count($myGroups) > 0) {
                                    foreach ($myGroups as $Group) {
                                        echo Content::getGroupItemPanel($Group->Group_ID, $Group->Group_Name, $Group->Description, $Group->Number_of_Members);
                                    }
                                }
                                else {
                                    echo "<div class = 'alert alert-danger'> Not A Member Of Any Group! </div>";
                                }

                                ?>
                            </div>
                        </div>
                    </div>

                    <div class = "row">
                        <div class = "panel panel-default">
                            <div class="panel-heading"> Other Groups </div>
                            <div class = "panel-body" id = "OtherGroups">
                                <?php
                                $otherGroups = $group->getAllOtherGroups($user->data()->User_ID);
                                if (count($otherGroups) > 0) {
                                    foreach ($otherGroups as $Group) {
                                        echo Content::getGroupItemPanel($Group->Group_ID, $Group->Group_Name, $Group->Description, $Group->Number_of_Members);
                                    }
                                }
                                else {
                                    echo "<div class = 'alert alert-danger'> No Other Groups! </div>";
                                }

                                ?>
                            </div>
                        </div>
                    </div>

                </div>
            </div>
        </div>

        <script src = "../../Script/jQuery/jquery-2.2.3.min.js"> </script>
        <script src = "../../CSS/bootstrap/js/bootstrap.min.js"> </script>
        <script src = "../../Ajax/Search/Search.js"> </script>
    </Body>
</HTML>
