<?php
require_once("../../Tools/Initialization.php");

$user = new User();
$group = new Group();
$friends = new Friend();
$Notification = new Notification();
$Message = new Message();

if(!$user->isLoggedIn()) {
    Redirect::to("../Login.php");
}

$_User_ID = $_GET["ID"];
$_Username = $user->getUsername($_User_ID);

if (!$user->areFriends($user->data()->User_ID, $_User_ID)) {
    Redirect::to("../Errors/MessageError.php");
}
?>

<!DOCTYPE HTML>

<HTML>
    <Head>
        <Title> Friends </Title>
        <link rel = "stylesheet" type = "text/css" href = "../../CSS/bootstrap/css/bootstrap.min.css">
        <link rel = "stylesheet" type = "text/css" href = "../../CSS/Custom/Page.css">
        <meta name = "viewport" content="width=device-width, initial-scale=1">
        <meta charset = "utf-8">
    </Head>
    <Body>
        <?php require_once("../Template/Navigation.php"); ?>
        <div class = "jumbotron">
            <div class = "row">
                <div class = "col-md-3 col-sm-10 container">
                    <?php require_once("../Template/LSidebar.php"); ?>
                </div>

                <div class = "col-md-8 col-sm-8">
                    <div class = "panel panel-default">
                        <div class = "panel-heading"> Conversation With <span id = "Conversation_Username"> <?php echo $user->getUsername($_User_ID);?> </span> </div>
                        <div class = "panel-body" id = "Conversation">
                            <ul class = "list-group">
                                <?php
                                $My_Messages = $Message->getAllConversation($user->data()->User_ID, $_User_ID);

                                if (count($My_Messages) > 0) {
                                    foreach ($My_Messages as $_Message) {
                                        echo Content::getMessagePanel($_User_ID, $user->getUsername($_User_ID), $_Message["Message"], $_Message["Date"], $_Message["Type"], $_Message["Seen"]);
                                    }
                                }

                                else {
                                    echo "<div class = 'alert alert-info'> <b> Empty : </b> You Have No Messages! </div>";
                                }

                                $Message->setConversationMessageSeen($user->data()->User_ID, $_User_ID);

                                ?>
                            </ul>
                        </div>
                        <div class = "panel-footer">
                            <div class = "form-group" id = "Message_Send_Panel">
                                <label for = "Message"> Message </label>
                                <textarea class = "form-control" rows = "3" id = "Message"></textarea>
                                <button type = "button" class = 'btn btn-primary' id = "Send" onclick="<?php echo "sendMessage({$user->data()->User_ID}, {$_User_ID})"; ?>"> Send <span class = "glyphicon glyphicon-transfer"> </span> </button>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <script src = "../../Script/jQuery/jquery-2.2.3.min.js"> </script>
        <script src = "../../CSS/bootstrap/js/bootstrap.min.js"> </script>
        <script src = "../../Ajax/Message/Message.js"> </script>
        <script src = "../../Ajax/Search/Search.js"> </script>
    </Body>
</HTML>
