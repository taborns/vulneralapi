<?php
require_once("../../Tools/Initialization.php");

$user = new User();
$group = new Group();
$friends = new Friend();
$Notification = new Notification();
$Message = new Message();

if(!$user->isLoggedIn()) {
    Redirect::to("../Login.php");
}

?>

<!DOCTYPE HTML>

<HTML>
    <Head>
        <Title> Messages </Title>
        <link rel = "stylesheet" type = "text/css" href = "../../CSS/bootstrap/css/bootstrap.min.css">
        <link rel = "stylesheet" type = "text/css" href = "../../CSS/Custom/Page.css">
        <meta name = "viewport" content="width=device-width, initial-scale=1">
        <meta charset = "utf-8">
    </Head>
    <Body>
        <?php require_once("../Template/Navigation.php"); ?>
        <div class = "jumbotron">
            <div class = "row">
                <div class = "col-md-3 col-sm-10 container">
                    <?php require_once("../Template/LSidebar.php"); ?>
                </div>

                <div class = "col-md-8 col-sm-8">
                    <div class = "panel panel-default">
                        <div class = "panel-heading">
                            Conversations
                        </div>
                        <div class = "panel-body" id = "Messages_Panel">
                            <ul class = "list-group">
                            <?php
                            $_Message_Groups = $Message->getMessageGroups($user->data()->User_ID);

                            if (count($_Message_Groups)) {
                                foreach ($_Message_Groups as $Group) {
                                    $Last_Message = $Message->getLastMessage($user->data()->User_ID, $Group);
                                    echo Content::getMessageGroupPanel($Group, $user->getUsername($Group), $Last_Message["Message"],$Last_Message["Date"], $Last_Message["Seen"]);
                                }
                            }

                            else {
                                echo "<div class = 'alert alert-info'> <b> Empty : </b> You Have No Conversations! </div>";
                            }

                            ?>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <script src = "../../Script/jQuery/jquery-2.2.3.min.js"> </script>
        <script src = "../../CSS/bootstrap/js/bootstrap.min.js"> </script>
        <script src = "../../Ajax/Search/Search.js"> </script>
    </Body>
</HTML>
