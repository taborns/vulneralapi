<?php
require_once("../Tools/Initialization.php");

$user = new User();
$user->logout();

Redirect::to("Login.php");
?>
