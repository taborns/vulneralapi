<?php
require_once("../../Tools/Initialization.php");

$user = new User();
$group = new Group();
$friends = new Friend();
$Notification = new Notification();
$Comments = new Comment();
$Message = new Message();

if(!$user->isLoggedIn()) {
    Redirect::to("../Login.php");
}


?>

<!DOCTYPE HTML>

<HTML>
    <Head>
        <Title> Group Error  </Title>
        <link rel = "stylesheet" type = "text/css" href = "../../CSS/bootstrap/css/bootstrap.min.css">
        <link rel = "stylesheet" type = "text/css" href = "../../CSS/Custom/Page.css">
        <meta name = "viewport" content="width=device-width, initial-scale=1">
        <meta charset = "utf-8">
    </Head>
    <Body>
        <?php require_once("../Template/Navigation.php"); ?>

        <div class = "jumbotron">
            <div class = "row">
                <div class = "col-md-3 col-sm-10 container">
                    <?php require_once("../Template/LSidebar.php"); ?>
                </div>

                <div class = "col-md-offset-1 col-md-7 col-sm-8">
                    <div class = "alert alert-danger">
                        <h4> <b> Error </b> :  There exist no Group With The Provided ID </h4>
                    </div>
                </div>
            </div>
        </div>

        <script src = "../../Script/jQuery/jquery-2.2.3.min.js"> </script>
        <script src = "../../CSS/bootstrap/js/bootstrap.min.js"> </script>
        <script src = "../../Ajax/Search/Search.js"> </script>
    </Body>
</HTML>
