<?php
session_start();

$GLOBALS["Configuration"] = array(
    "MySQL" => array(
        "Host" => "127.0.0.1",
        "Username" => "root",
        "Password" => "B@rcelon@10",
        "Database" => "Social_Network"
    ),
    "Remember" => array(
        "Cookie_Name" => "Hash",
        "Cookie_Expiry" => 604800
    ),
    "Session" => array(
        "Session_Name" => "User",
        "Token_Name" => "Token"
    ),
    "Directory" => array(
        "Root" => "/Files/PHP/Social_Network"
    )
);

spl_autoload_register(function($class) {
    if (file_exists("../Model/".$class.".php")) {
        require_once("../Model/".$class.".php");
    }
    else if (file_exists("../../Model/".$class.".php")){
        require_once("../../Model/".$class.".php");
    }
    else {
        require_once("../../../Model/".$class.".php");
    }
});


if (Cookie::exists(Configuration::get("Remember/Cookie_Name")) && !Session::exists(Configuration::get("Session/Session_Name"))) {
    $hash = Cookie::get(Configuration::get("Remember/Cookie_Name"));
    $hashCheck = Database::getInstance()->get("Session", array("Hash", "=", $hash));

    if ($hashCheck->count()) {
		$user = new User($hashCheck->first_Result()->User_ID);
		$user->login();
	}
}
?>
