-- phpMyAdmin SQL Dump
-- version 4.5.4.1deb2ubuntu2
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Feb 01, 2017 at 02:26 PM
-- Server version: 5.7.16-0ubuntu0.16.04.1
-- PHP Version: 7.0.8-0ubuntu0.16.04.3

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `Social_Network`
--

-- --------------------------------------------------------

--
-- Table structure for table `Albums`
--

CREATE TABLE `Albums` (
  `Album_ID` int(11) NOT NULL,
  `User_ID` int(11) DEFAULT NULL,
  `Name` varchar(25) NOT NULL,
  `Date` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `Albums`
--

INSERT INTO `Albums` (`Album_ID`, `User_ID`, `Name`, `Date`) VALUES
(1, 6, 'Trip', '2016-09-05 21:51:01'),
(2, 1, 'Vacation', '2016-09-05 22:19:11'),
(3, 1, 'Wallpapers', '2016-09-06 12:31:15'),
(4, 14, 'Trip', '2016-09-13 20:25:57');

-- --------------------------------------------------------

--
-- Table structure for table `Comments`
--

CREATE TABLE `Comments` (
  `User_ID` int(11) DEFAULT NULL,
  `Post_ID` int(11) DEFAULT NULL,
  `Date` datetime DEFAULT NULL,
  `Comment` text
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `Comments`
--

INSERT INTO `Comments` (`User_ID`, `Post_ID`, `Date`, `Comment`) VALUES
(1, 2, '2016-09-03 23:44:18', 'Why'),
(1, 1, '2016-09-03 23:46:09', 'Me too!!!'),
(1, 1, '2016-09-03 23:46:11', 'Me too!!!'),
(1, 2, '2016-09-03 23:46:19', '??'),
(1, 2, '2016-09-03 23:49:02', 'I hate You'),
(2, 8, '2016-09-06 00:05:29', 'Ohhhh!');

-- --------------------------------------------------------

--
-- Table structure for table `Friends`
--

CREATE TABLE `Friends` (
  `User_ID` int(11) NOT NULL,
  `Friend_ID` int(11) NOT NULL,
  `Date` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `Friends`
--

INSERT INTO `Friends` (`User_ID`, `Friend_ID`, `Date`) VALUES
(1, 2, '2016-09-02 23:22:02'),
(2, 1, '2016-09-02 23:22:02'),
(2, 6, '2016-09-03 23:54:16'),
(6, 2, '2016-09-03 23:54:16'),
(2, 4, '2016-09-03 23:54:17'),
(4, 2, '2016-09-03 23:54:17'),
(3, 2, '2016-09-03 23:54:43'),
(2, 3, '2016-09-03 23:54:43'),
(3, 4, '2016-09-03 23:54:48'),
(4, 3, '2016-09-03 23:54:48'),
(5, 6, '2016-09-03 23:57:38'),
(6, 5, '2016-09-03 23:57:38'),
(1, 5, '2016-09-03 23:59:50'),
(5, 1, '2016-09-03 23:59:50'),
(1, 6, '2016-09-04 00:01:56'),
(6, 1, '2016-09-04 00:01:56'),
(12, 1, '2016-09-07 20:59:01'),
(1, 12, '2016-09-07 20:59:01'),
(3, 1, '2016-10-01 22:49:53'),
(1, 3, '2016-10-01 22:49:53');

-- --------------------------------------------------------

--
-- Table structure for table `Friend_Request`
--

CREATE TABLE `Friend_Request` (
  `User_ID` int(11) DEFAULT NULL,
  `Friend_ID` int(11) DEFAULT NULL,
  `Date` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `Friend_Request`
--

INSERT INTO `Friend_Request` (`User_ID`, `Friend_ID`, `Date`) VALUES
(4, 6, '2016-09-03 23:54:00'),
(4, 1, '2016-09-04 00:01:47'),
(1, 13, '2016-09-07 20:58:53'),
(1, 10, '2016-09-08 23:22:54'),
(2, 5, '2016-10-09 11:57:08');

-- --------------------------------------------------------

--
-- Table structure for table `Groups`
--

CREATE TABLE `Groups` (
  `Group_ID` varchar(128) NOT NULL,
  `Group_Name` varchar(25) NOT NULL,
  `Date` datetime NOT NULL,
  `Description` varchar(1000) DEFAULT NULL,
  `Administrator` int(11) NOT NULL,
  `Number_of_Members` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `Groups`
--

INSERT INTO `Groups` (`Group_ID`, `Group_Name`, `Date`, `Description`, `Administrator`, `Number_of_Members`) VALUES
('09c58af5e0ed9ebb10922ebc55ceacbb6ea1dc78d6b0237fe5e37b408d9a84d6', 'FC Barcelona', '2016-08-29 03:41:28', 'Messi , Neymar, Suarez', 1, 6),
('851ce777f121a02afa077b1e6c599f31cd53756921e9e8dea5f38e524b019c8f', 'Manchester United FC', '2016-09-01 01:25:53', 'We are the Red Devils. We are the only ones.', 1, 1),
('b127335128e30bc48c7126c0665b2260b487064f513429d7ad02c3fc2d88f463', 'AAiT', '2016-08-29 03:31:53', 'Welcome To The Official Group of AAiT', 2, 2),
('e4930484fce2c7aa61b850266f64bc68a7e30a4cbc425bc1fb6576a888adf3b2', 'Arsenal FC', '2016-08-29 03:33:00', 'We are the Gunners.', 3, 1);

-- --------------------------------------------------------

--
-- Table structure for table `Group_Likes`
--

CREATE TABLE `Group_Likes` (
  `Like_ID` int(11) NOT NULL,
  `Post_ID` int(11) DEFAULT NULL,
  `User_ID` int(11) DEFAULT NULL,
  `Group_ID` varchar(128) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `Group_Likes`
--

INSERT INTO `Group_Likes` (`Like_ID`, `Post_ID`, `User_ID`, `Group_ID`) VALUES
(1, 3, 1, 'b127335128e30bc48c7126c0665b2260b487064f513429d7ad02c3fc2d88f463'),
(2, 4, 2, 'b127335128e30bc48c7126c0665b2260b487064f513429d7ad02c3fc2d88f463'),
(3, 5, 2, 'b127335128e30bc48c7126c0665b2260b487064f513429d7ad02c3fc2d88f463'),
(4, 2, 1, '09c58af5e0ed9ebb10922ebc55ceacbb6ea1dc78d6b0237fe5e37b408d9a84d6'),
(5, 6, 1, 'e4930484fce2c7aa61b850266f64bc68a7e30a4cbc425bc1fb6576a888adf3b2'),
(9, 7, 1, 'b127335128e30bc48c7126c0665b2260b487064f513429d7ad02c3fc2d88f463'),
(12, 7, 2, 'b127335128e30bc48c7126c0665b2260b487064f513429d7ad02c3fc2d88f463'),
(13, 2, 2, '09c58af5e0ed9ebb10922ebc55ceacbb6ea1dc78d6b0237fe5e37b408d9a84d6'),
(14, 4, 1, 'b127335128e30bc48c7126c0665b2260b487064f513429d7ad02c3fc2d88f463'),
(15, 5, 1, 'b127335128e30bc48c7126c0665b2260b487064f513429d7ad02c3fc2d88f463'),
(16, 2, 5, '09c58af5e0ed9ebb10922ebc55ceacbb6ea1dc78d6b0237fe5e37b408d9a84d6'),
(17, 2, 6, '09c58af5e0ed9ebb10922ebc55ceacbb6ea1dc78d6b0237fe5e37b408d9a84d6'),
(18, 3, 2, 'b127335128e30bc48c7126c0665b2260b487064f513429d7ad02c3fc2d88f463'),
(19, 30, 1, '09c58af5e0ed9ebb10922ebc55ceacbb6ea1dc78d6b0237fe5e37b408d9a84d6'),
(20, 31, 1, '851ce777f121a02afa077b1e6c599f31cd53756921e9e8dea5f38e524b019c8f'),
(21, 30, 6, '09c58af5e0ed9ebb10922ebc55ceacbb6ea1dc78d6b0237fe5e37b408d9a84d6');

-- --------------------------------------------------------

--
-- Table structure for table `Group_Members`
--

CREATE TABLE `Group_Members` (
  `Group_ID` varchar(128) DEFAULT NULL,
  `User_ID` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `Group_Members`
--

INSERT INTO `Group_Members` (`Group_ID`, `User_ID`) VALUES
('b127335128e30bc48c7126c0665b2260b487064f513429d7ad02c3fc2d88f463', 2),
('e4930484fce2c7aa61b850266f64bc68a7e30a4cbc425bc1fb6576a888adf3b2', 3),
('09c58af5e0ed9ebb10922ebc55ceacbb6ea1dc78d6b0237fe5e37b408d9a84d6', 1),
('09c58af5e0ed9ebb10922ebc55ceacbb6ea1dc78d6b0237fe5e37b408d9a84d6', 3),
('b127335128e30bc48c7126c0665b2260b487064f513429d7ad02c3fc2d88f463', 1),
('09c58af5e0ed9ebb10922ebc55ceacbb6ea1dc78d6b0237fe5e37b408d9a84d6', 2),
('09c58af5e0ed9ebb10922ebc55ceacbb6ea1dc78d6b0237fe5e37b408d9a84d6', 5),
('09c58af5e0ed9ebb10922ebc55ceacbb6ea1dc78d6b0237fe5e37b408d9a84d6', 6),
('851ce777f121a02afa077b1e6c599f31cd53756921e9e8dea5f38e524b019c8f', 1),
('09c58af5e0ed9ebb10922ebc55ceacbb6ea1dc78d6b0237fe5e37b408d9a84d6', 4);

-- --------------------------------------------------------

--
-- Table structure for table `Group_Post`
--

CREATE TABLE `Group_Post` (
  `Post_ID` int(11) NOT NULL,
  `Group_ID` varchar(128) DEFAULT NULL,
  `User_ID` int(11) DEFAULT NULL,
  `Date` datetime DEFAULT NULL,
  `Message` text NOT NULL,
  `Likes` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `Group_Post`
--

INSERT INTO `Group_Post` (`Post_ID`, `Group_ID`, `User_ID`, `Date`, `Message`, `Likes`) VALUES
(2, '09c58af5e0ed9ebb10922ebc55ceacbb6ea1dc78d6b0237fe5e37b408d9a84d6', 1, '2016-08-29 22:13:04', 'I am a Great Fan', 4),
(3, 'b127335128e30bc48c7126c0665b2260b487064f513429d7ad02c3fc2d88f463', 1, '2016-08-29 23:47:49', 'I am a software Engineer at AAiT.', 2),
(4, 'b127335128e30bc48c7126c0665b2260b487064f513429d7ad02c3fc2d88f463', 2, '2016-08-30 21:50:34', 'Me too', 2),
(5, 'b127335128e30bc48c7126c0665b2260b487064f513429d7ad02c3fc2d88f463', 2, '2016-08-30 23:14:10', 'But I hate it there', 2),
(6, 'e4930484fce2c7aa61b850266f64bc68a7e30a4cbc425bc1fb6576a888adf3b2', 1, '2016-08-30 23:33:03', 'We are the Gunners', 1),
(7, 'b127335128e30bc48c7126c0665b2260b487064f513429d7ad02c3fc2d88f463', 1, '2016-08-30 23:41:23', 'Why', 2),
(30, '09c58af5e0ed9ebb10922ebc55ceacbb6ea1dc78d6b0237fe5e37b408d9a84d6', 1, '2016-09-04 01:16:13', 'I am', 2),
(31, '851ce777f121a02afa077b1e6c599f31cd53756921e9e8dea5f38e524b019c8f', 1, '2016-09-04 13:17:17', 'I am a Fan of Manchester United!', 1);

-- --------------------------------------------------------

--
-- Table structure for table `Group_Post_Comments`
--

CREATE TABLE `Group_Post_Comments` (
  `Comment_ID` int(11) NOT NULL,
  `User_ID` int(11) DEFAULT NULL,
  `Post_ID` int(11) DEFAULT NULL,
  `Date` datetime DEFAULT NULL,
  `Comment` text
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `Group_Post_Comments`
--

INSERT INTO `Group_Post_Comments` (`Comment_ID`, `User_ID`, `Post_ID`, `Date`, `Comment`) VALUES
(1, 1, 3, '2016-09-14 06:20:17', 'I hate you'),
(2, 2, 3, '2016-09-02 01:35:40', 'Why??'),
(3, 2, 3, '2016-09-02 01:48:11', 'Ha Ha'),
(4, 2, 3, '2016-09-02 01:48:42', 'Fuck You!'),
(5, 2, 4, '2016-09-02 01:49:08', 'Comment Please!'),
(6, 2, 4, '2016-09-02 01:49:15', 'Please'),
(17, 1, 5, '2016-09-02 02:15:56', 'Why No Comment.'),
(18, 1, 3, '2016-09-03 23:49:29', 'Ehh'),
(19, 1, 3, '2016-09-03 23:49:48', 'Menew'),
(20, 1, 31, '2016-09-04 13:17:28', 'Who else??');

-- --------------------------------------------------------

--
-- Table structure for table `Likes`
--

CREATE TABLE `Likes` (
  `Post_ID` int(11) DEFAULT NULL,
  `User_ID` int(11) DEFAULT NULL,
  `Time` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `Likes`
--

INSERT INTO `Likes` (`Post_ID`, `User_ID`, `Time`) VALUES
(2, 1, '2016-09-03 23:26:37'),
(1, 1, '2016-09-03 23:26:40'),
(6, 2, '2016-09-05 23:19:58'),
(7, 1, '2016-09-05 23:50:57'),
(8, 2, '2016-09-06 00:05:15'),
(8, 1, '2016-09-06 00:05:41'),
(3, 2, '2016-09-06 02:22:39'),
(9, 1, '2016-09-07 20:59:16'),
(9, 6, '2016-09-13 04:27:12'),
(2, 6, '2016-09-13 04:27:16'),
(10, 1, '2016-09-13 20:39:50'),
(12, 1, '2016-09-20 17:19:55'),
(13, 1, '2016-09-28 02:12:55');

-- --------------------------------------------------------

--
-- Table structure for table `Messages`
--

CREATE TABLE `Messages` (
  `Message_ID` int(11) NOT NULL,
  `Sender_ID` int(11) NOT NULL,
  `Reciever_ID` int(11) NOT NULL,
  `Message` varchar(500) NOT NULL,
  `Date` datetime NOT NULL,
  `Seen` tinyint(1) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `Messages`
--

INSERT INTO `Messages` (`Message_ID`, `Sender_ID`, `Reciever_ID`, `Message`, `Date`, `Seen`) VALUES
(1, 1, 3, 'Hi', '2016-09-03 14:35:36', 1),
(2, 3, 1, 'Peace new', '2016-09-03 14:38:10', 1),
(3, 3, 1, 'Endet neh?', '2016-09-03 14:38:18', 1),
(4, 1, 3, 'Alehu', '2016-09-03 14:45:53', 1),
(5, 2, 1, 'Ehh BK', '2016-09-03 15:10:56', 1),
(6, 1, 2, 'Ehh Abela Peace New', '2016-09-04 00:06:30', 1),
(7, 2, 1, 'Alehu', '2016-09-04 13:18:00', 1),
(8, 1, 6, 'Heyyy', '2016-09-07 21:04:10', 1),
(9, 1, 6, 'Ehh Peace new', '2016-09-28 02:13:39', 1),
(10, 1, 12, 'Hi', '2016-10-09 11:50:00', 1),
(11, 12, 1, 'Ehh BK', '2016-10-09 11:50:12', 1);

-- --------------------------------------------------------

--
-- Table structure for table `Notifications`
--

CREATE TABLE `Notifications` (
  `Notification_ID` int(11) NOT NULL,
  `User_ID` int(11) DEFAULT NULL,
  `Notification` text,
  `Date` datetime DEFAULT NULL,
  `Seen` tinyint(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `Notifications`
--

INSERT INTO `Notifications` (`Notification_ID`, `User_ID`, `Notification`, `Date`, `Seen`) VALUES
(1, 1, 'You Have Joined Social Network', '2016-09-01 08:50:11', 1),
(2, 2, 'Biruk Accepted Your Friend Request.', '2016-09-01 23:20:12', 1),
(3, 5, 'Biruk Has Blocked Your Account.', '2016-09-02 03:25:30', 0),
(4, 6, 'Biruk Has Blocked Your Account.', '2016-09-02 03:25:36', 1),
(5, 1, 'Abela Has Blocked Your Account.', '2016-09-02 22:43:01', 1),
(6, 6, 'Abela Has Blocked Your Account.', '2016-09-02 23:09:39', 0),
(7, 2, 'You Have Cancelled Your Friend Request For Biruk', '2016-09-02 23:10:35', 1),
(8, 2, 'Biruk Accepted Your Friend Request.', '2016-09-02 23:11:23', 1),
(9, 2, 'Biruk Has Blocked Your Account.', '2016-09-02 23:11:30', 1),
(10, 1, 'You Have Cancelled Your Friend Request For Abela', '2016-09-02 23:15:04', 1),
(11, 1, 'Abela Accepted Your Friend Request.', '2016-09-02 23:21:37', 1),
(12, 1, 'Abela Has Blocked Your Account.', '2016-09-02 23:21:47', 1),
(13, 2, 'Biruk Accepted Your Friend Request.', '2016-09-02 23:22:02', 1),
(14, 1, 'Kirubel Accepted Your Friend Request.', '2016-09-03 22:08:23', 1),
(15, 3, 'Biruk Has Blocked Your Account.', '2016-09-03 22:10:15', 0),
(16, 4, 'You Have Joined FC Barcelona', '2016-09-03 23:53:44', 0),
(17, 6, 'Abela Accepted Your Friend Request.', '2016-09-03 23:54:16', 0),
(18, 4, 'Abela Accepted Your Friend Request.', '2016-09-03 23:54:17', 0),
(19, 2, 'Kirubel Accepted Your Friend Request.', '2016-09-03 23:54:43', 0),
(20, 4, 'Kirubel Accepted Your Friend Request.', '2016-09-03 23:54:48', 0),
(21, 6, 'Yabetse Accepted Your Friend Request.', '2016-09-03 23:57:38', 0),
(22, 6, 'Biruk Accepted Your Friend Request.', '2016-09-03 23:57:53', 0),
(23, 6, 'Biruk Has Blocked Your Account.', '2016-09-03 23:58:49', 0),
(24, 5, 'Biruk Accepted Your Friend Request.', '2016-09-03 23:59:50', 0),
(25, 4, 'Biruk Has Blocked Your Account.', '2016-09-04 00:01:37', 1),
(26, 6, 'Biruk Accepted Your Friend Request.', '2016-09-04 00:01:56', 0),
(27, 1, 'Simon Accepted Your Friend Request.', '2016-09-07 20:59:02', 0),
(28, 1, 'Kirubel Accepted Your Friend Request.', '2016-10-01 22:49:53', 0);

-- --------------------------------------------------------

--
-- Table structure for table `Posts`
--

CREATE TABLE `Posts` (
  `Post_ID` int(11) NOT NULL,
  `User_ID` int(11) NOT NULL,
  `Text` varchar(500) NOT NULL,
  `Image` varchar(5000) DEFAULT NULL,
  `Date` datetime NOT NULL,
  `Likes` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `Posts`
--

INSERT INTO `Posts` (`Post_ID`, `User_ID`, `Text`, `Image`, `Date`, `Likes`) VALUES
(1, 2, 'I Love Barcelona', NULL, '2016-09-01 04:24:23', 1),
(2, 2, 'I Hate Real Madrid', NULL, '2016-09-02 05:18:18', 2),
(3, 3, 'I Hate Barcelona', NULL, '2016-09-04 03:18:23', 1),
(6, 1, 'Images', '../../Images/Posts/Biruk/a3b56cb56b8db591b0486fa56b8fbaac1473106458.png*../../Images/Posts/Biruk/99b33a72039dd025319b34438a60aa641473106458.png*', '2016-09-05 23:14:18', 1),
(7, 2, 'Technology', '../../Images/Posts/Abela/e0db70ce468d4035144ff69ea7977dd01473108646.png*../../Images/Posts/Abela/feb7012db7467ebecbe36010091ea5f71473108646.png*../../Images/Posts/Abela/04c76a80977c5014374db6a1394d35701473108646.png*../../Images/Posts/Abela/fd22fc8eb51f97f2206e990fca72cf5f1473108646.png*../../Images/Posts/Abela/03de9e5dd549f3dabe3da1c6b0a88acf1473108646.png*../../Images/Posts/Abela/3c18c531f450f5284547fe77182222821473108646.png*', '2016-09-05 23:50:46', 1),
(8, 6, 'Come to my Restaurant', '../../Images/Posts/Nathan/941b04d34b27da6d69b755ed9e98e34e1473109493.png*../../Images/Posts/Nathan/776e16f26226a229514f4d63674efbaf1473109493.png*../../Images/Posts/Nathan/d74d189db2df52b657f094c46de5fd8d1473109493.png*../../Images/Posts/Nathan/8bd341d530fa943a29e6a042fffdc3451473109493.png*../../Images/Posts/Nathan/c23396390ed6f4f6069d9633d523fdb21473109493.png*../../Images/Posts/Nathan/c27ef28481c14859296b10d79b51a06e1473109493.png*', '2016-09-06 00:04:53', 2),
(9, 5, 'Transportation', '../../Images/Posts/Yabetse/38e1a79f32e8ca1b368ee4b9c6d310e61473164009.png*../../Images/Posts/Yabetse/b3ecad0ebd522bfc4111859d7143e64d1473164009.png*../../Images/Posts/Yabetse/04e3a7d1d840b147de87d711a77097881473164009.png*', '2016-09-06 15:13:29', 2),
(10, 2, '', '../../Images/Posts/Abela/14cea0e7d40fa55671dad5c4c7cc1c641473788325.jpg*../../Images/Posts/Abela/ad6a58875fc0c881453caccd7bc5a2901473788325.jpg*../../Images/Posts/Abela/d8d0d92ad53c1d936c09a53ad1c8111d1473788325.jpg*../../Images/Posts/Abela/34981f5c67092ebf58a24c73d33b64c31473788325.jpg*../../Images/Posts/Abela/d289e61bed86e87837a6b1a80112986f1473788325.jpg*../../Images/Posts/Abela/18bcd93db7c15c4942b87171ef7a28541473788325.jpg*../../Images/Posts/Abela/ed8ccf44e8330beb0263661b8e779e911473788325.jpg*', '2016-09-13 20:38:45', 1),
(11, 1, '', '../../Images/Posts/Biruk/9d19339d4037e0afe0b2ff22b2323ffd1474381156.png*../../Images/Posts/Biruk/ecd7e226cbc47b5d63a72c69085e718c1474381156.png*../../Images/Posts/Biruk/7bcb12df0a2b47a984c8677034428d831474381156.png*../../Images/Posts/Biruk/1ba53727d32b8913b89678e2dc79b7801474381156.png*../../Images/Posts/Biruk/181fda446564c4adaee70b7deb8af9781474381156.png*../../Images/Posts/Biruk/4170528b332ad7c74cbfe68852c628fe1474381156.png*../../Images/Posts/Biruk/32fe34a16d104929b364adf14c398dab1474381156.png*../../Images/Posts/Biruk/5712bce029253ab97b89797e7443bff51474381156.png*', '2016-09-20 17:19:16', 0),
(12, 2, '', '../../Images/Posts/Abela/42f14bbbd4ebb076d578d187d82e92d21474381181.png*', '2016-09-20 17:19:41', 1),
(13, 6, '', '../../Images/Posts/Nathan/bac225a6c9cda658c575bd7840aef28a1474381227.png*../../Images/Posts/Nathan/972ecece837ceb338fe04316cecbfea11474381227.png*../../Images/Posts/Nathan/fb196bf300785ce38adb769ae381c2e61474381227.png*../../Images/Posts/Nathan/3c14058d3a5941840c4f6c877827369a1474381227.png*', '2016-09-20 17:20:27', 1),
(14, 6, '', '../../Images/Posts/Nathan/b871cbd29df79250c4953ff16a7785bc1474400565.png*../../Images/Posts/Nathan/c0f97df78fed2b3fd6c7bc121569d8e71474400565.png*../../Images/Posts/Nathan/d1c7b89433403b9aba42dfee22ef7ff41474400565.png*../../Images/Posts/Nathan/c84d54b21930d5d071eee4338e39e0861474400565.png*', '2016-09-20 22:42:45', 0);

-- --------------------------------------------------------

--
-- Table structure for table `Session`
--

CREATE TABLE `Session` (
  `ID` int(11) NOT NULL,
  `User_ID` int(11) DEFAULT NULL,
  `Hash` varchar(128) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `Users`
--

CREATE TABLE `Users` (
  `User_ID` int(11) NOT NULL,
  `Username` varchar(25) NOT NULL,
  `Password` varchar(128) NOT NULL,
  `Salt` varchar(128) DEFAULT NULL,
  `First_Name` varchar(25) NOT NULL,
  `Last_Name` varchar(25) NOT NULL,
  `Email` varchar(25) NOT NULL,
  `Age` int(11) NOT NULL,
  `Birthday` date NOT NULL,
  `Profile_Picture` varchar(5000) DEFAULT NULL,
  `About_Me` varchar(500) DEFAULT NULL,
  `Country` varchar(25) DEFAULT NULL,
  `City` varchar(50) DEFAULT NULL,
  `Gender` varchar(15) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `Users`
--

INSERT INTO `Users` (`User_ID`, `Username`, `Password`, `Salt`, `First_Name`, `Last_Name`, `Email`, `Age`, `Birthday`, `Profile_Picture`, `About_Me`, `Country`, `City`, `Gender`) VALUES
(1, 'Biruk', 'ca3f823a369c15c4c988268a296932a0d976f482aa8df838974d8f7d36092bf8', 'Ï+kVà¯5oèOP9Ÿø¯®\nÄº‡(ìN¦ÞLêM', 'Biruk', 'Adera', 'aderabiruk@gmail.com', 21, '1996-07-08', '../../Images/Default.png', 'I am a Software Engineer.            ', 'Ethiopia', 'Addis Ababa', 'Male'),
(2, 'Abela', 'ab1eeaa3c3a7a530b007617ff835c905d60d12b4e28816a13c87f089062db2e4', 'ìó"5	>Î÷MZû\r:@amQ^˜Õ%òÉk<w\0e', 'Abel', 'Mandefro', 'aderabiruk@gmail.com', 21, '1996-10-10', '../../Images/Users/Abela/843753e8bd0d0bcda9b3e9da619ad1711473180327.png', '', 'Ethiopia', 'Addis Ababa', 'Male'),
(3, 'Kirubel', '24ea90d91fde7f555a5873294b0006604e5bf1f0cb9b557ac8a79bbb73f6101d', 'çù‡.·l`³E‚ÿ‚À–\'æCç™frõåñ¦', 'Kirubel', 'Getachew', 'kirubel@yahoo.com', 20, '2000-08-01', '../../Images/Users/Kirubel/f7b597adbf019a3a4afc81df617139701473176362.png', '', 'Ethiopia', 'Addis Ababa', 'Male'),
(4, 'Zemene', '1465a2b13198808cbcf824a2100cdba0bffbc03e3810104292a9abe884c3218f', '÷hOE­¯ßAæ§u)æž/Geê‚œÚ}¯lù\næßþÒi', 'Zemene', 'Yohannes', 'aderabiruk@gmail.com', 16, '2000-08-02', '../../Images/Default.png', 'No words', 'Ethiopia', 'Addis Ababa', 'Male'),
(5, 'Yabetse', '08420c25ca095cd22fc1b50376a33cd42a2f0f12d12efb9cc7d189678317f020', '>ÑxÏ|a¼$8„-xPÔÖ¤>ÝÈ$©°Lg¾êª—g', 'Yabetse', 'Genene', 'aderabiruk@gmail.com', 20, '1996-08-02', '../../Images/Users/Yabetse/d143284552c20dbe20643ae08a7f5c4e1473542492.png', '', 'Ethiopia', 'Addis Ababa', 'Male'),
(6, 'Nathan', 'a1ad8c5a4beba046a84e09766a23334bfff9a5d344d15af258e3bfca0c6e5196', '€„cbF^"¥wBjÑ~Pýû\Zf7i¡éÔ<Õh1)R±', 'Nathan', 'Tsegaye', 'aderabiruk@gmail.com', 20, '1996-08-02', '../../Images/Users/Nathan/f9f454f0f3d8162ea8dc605bcaf17b7b1473100967.png', '', 'Ethiopia', 'Addis Ababa', 'Male'),
(10, 'Abenezer', '7905398d06590e3c69c7adb5dce09188b38673a9006e594f02569a9bb38eff7a', 'íhc:Ãÿ’©ÍÛê>_AŽïÜ7”\'Bjb+ÝÐÉÇ', 'Abenezer', 'Mengistu', 'aderabiruk@gmail.com', 16, '2000-09-13', '../../Images/Default.png', '', 'Ethiopia', 'Addis Ababa', 'Male'),
(12, 'Simon', '7ab7b5ca6865230ea26b3c041e19997f5e49f535617e8950cb48d5a4b5a41d8f', 'ƒCRX/@+Æèf ´R!h’h^ëå¨Âý*–€Æ¤:nQ', 'Simon', 'Asfaw', 'aderabiruk@gmail.com', 16, '2000-09-14', '../../Images/Default.png', 'I am Simon', 'Ethiopia', 'Addis Ababa', 'Male'),
(13, 'Dawit', '52bdf5fb7facc7609ac76031c7fcbc83367ad4775b6795f10dd234ff409935ae', '¥ö#Àk4ƒCRèì»Jqè“”]Mâ­uÄCîô(³i', 'Dawit', 'Abebe', 'aderabiruk@gmail.com', 20, '1996-09-08', '../../Images/Default.png', '', 'Ethiopia', 'Addis Ababa', 'Male'),
(14, 'Kidist', '2f54a37deaf90b225f1acc291f1738fcfb4a1e21ba3b5ba3a98a290e89da7d7b', 'w›]ózlÄ\nÄ½Ñ¥|¦«EvSi`t%Á¼œN€', 'Kidist', 'Adera', 'aderabiruk@gmail.com', 16, '2000-09-01', '../../Images/Default.png', 'I am hopeless...Kill Me...Please!!!!!', 'Ethiopia', 'Addis Ababa', 'Female');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `Albums`
--
ALTER TABLE `Albums`
  ADD PRIMARY KEY (`Album_ID`,`Name`),
  ADD KEY `User_ID` (`User_ID`);

--
-- Indexes for table `Comments`
--
ALTER TABLE `Comments`
  ADD KEY `Post_ID` (`Post_ID`),
  ADD KEY `User_ID` (`User_ID`);

--
-- Indexes for table `Friends`
--
ALTER TABLE `Friends`
  ADD KEY `User_ID` (`User_ID`),
  ADD KEY `Friend_ID` (`Friend_ID`);

--
-- Indexes for table `Friend_Request`
--
ALTER TABLE `Friend_Request`
  ADD KEY `User_ID` (`User_ID`),
  ADD KEY `Friend_ID` (`Friend_ID`);

--
-- Indexes for table `Groups`
--
ALTER TABLE `Groups`
  ADD PRIMARY KEY (`Group_ID`,`Group_Name`),
  ADD KEY `Administrator` (`Administrator`);

--
-- Indexes for table `Group_Likes`
--
ALTER TABLE `Group_Likes`
  ADD PRIMARY KEY (`Like_ID`),
  ADD KEY `Post_ID` (`Post_ID`),
  ADD KEY `User_ID` (`User_ID`),
  ADD KEY `Group_ID` (`Group_ID`);

--
-- Indexes for table `Group_Members`
--
ALTER TABLE `Group_Members`
  ADD KEY `User_ID` (`User_ID`),
  ADD KEY `Group_ID` (`Group_ID`);

--
-- Indexes for table `Group_Post`
--
ALTER TABLE `Group_Post`
  ADD PRIMARY KEY (`Post_ID`),
  ADD KEY `Group_ID` (`Group_ID`),
  ADD KEY `User_ID` (`User_ID`);

--
-- Indexes for table `Group_Post_Comments`
--
ALTER TABLE `Group_Post_Comments`
  ADD PRIMARY KEY (`Comment_ID`),
  ADD KEY `User_ID` (`User_ID`),
  ADD KEY `Post_ID` (`Post_ID`);

--
-- Indexes for table `Likes`
--
ALTER TABLE `Likes`
  ADD KEY `Post_ID` (`Post_ID`),
  ADD KEY `User_ID` (`User_ID`);

--
-- Indexes for table `Messages`
--
ALTER TABLE `Messages`
  ADD PRIMARY KEY (`Message_ID`),
  ADD KEY `Sender_ID` (`Sender_ID`),
  ADD KEY `Reciever_ID` (`Reciever_ID`);

--
-- Indexes for table `Notifications`
--
ALTER TABLE `Notifications`
  ADD PRIMARY KEY (`Notification_ID`),
  ADD KEY `User_ID` (`User_ID`);

--
-- Indexes for table `Posts`
--
ALTER TABLE `Posts`
  ADD PRIMARY KEY (`Post_ID`),
  ADD KEY `User_ID` (`User_ID`);

--
-- Indexes for table `Session`
--
ALTER TABLE `Session`
  ADD PRIMARY KEY (`ID`),
  ADD KEY `User_ID` (`User_ID`);

--
-- Indexes for table `Users`
--
ALTER TABLE `Users`
  ADD PRIMARY KEY (`User_ID`,`Username`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `Albums`
--
ALTER TABLE `Albums`
  MODIFY `Album_ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;
--
-- AUTO_INCREMENT for table `Group_Likes`
--
ALTER TABLE `Group_Likes`
  MODIFY `Like_ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=22;
--
-- AUTO_INCREMENT for table `Group_Post`
--
ALTER TABLE `Group_Post`
  MODIFY `Post_ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=32;
--
-- AUTO_INCREMENT for table `Group_Post_Comments`
--
ALTER TABLE `Group_Post_Comments`
  MODIFY `Comment_ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=21;
--
-- AUTO_INCREMENT for table `Messages`
--
ALTER TABLE `Messages`
  MODIFY `Message_ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;
--
-- AUTO_INCREMENT for table `Notifications`
--
ALTER TABLE `Notifications`
  MODIFY `Notification_ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=29;
--
-- AUTO_INCREMENT for table `Posts`
--
ALTER TABLE `Posts`
  MODIFY `Post_ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;
--
-- AUTO_INCREMENT for table `Session`
--
ALTER TABLE `Session`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `Users`
--
ALTER TABLE `Users`
  MODIFY `User_ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;
--
-- Constraints for dumped tables
--

--
-- Constraints for table `Albums`
--
ALTER TABLE `Albums`
  ADD CONSTRAINT `Albums_ibfk_1` FOREIGN KEY (`User_ID`) REFERENCES `Users` (`User_ID`);

--
-- Constraints for table `Comments`
--
ALTER TABLE `Comments`
  ADD CONSTRAINT `Comments_ibfk_1` FOREIGN KEY (`Post_ID`) REFERENCES `Posts` (`Post_ID`),
  ADD CONSTRAINT `Comments_ibfk_2` FOREIGN KEY (`User_ID`) REFERENCES `Users` (`User_ID`);

--
-- Constraints for table `Friends`
--
ALTER TABLE `Friends`
  ADD CONSTRAINT `Friends_ibfk_1` FOREIGN KEY (`User_ID`) REFERENCES `Users` (`User_ID`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `Friends_ibfk_2` FOREIGN KEY (`Friend_ID`) REFERENCES `Users` (`User_ID`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `Friend_Request`
--
ALTER TABLE `Friend_Request`
  ADD CONSTRAINT `Friend_Request_ibfk_1` FOREIGN KEY (`User_ID`) REFERENCES `Users` (`User_ID`),
  ADD CONSTRAINT `Friend_Request_ibfk_2` FOREIGN KEY (`Friend_ID`) REFERENCES `Users` (`User_ID`);

--
-- Constraints for table `Groups`
--
ALTER TABLE `Groups`
  ADD CONSTRAINT `Groups_ibfk_1` FOREIGN KEY (`Administrator`) REFERENCES `Users` (`User_ID`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `Group_Likes`
--
ALTER TABLE `Group_Likes`
  ADD CONSTRAINT `Group_Likes_ibfk_1` FOREIGN KEY (`Post_ID`) REFERENCES `Group_Post` (`Post_ID`),
  ADD CONSTRAINT `Group_Likes_ibfk_2` FOREIGN KEY (`User_ID`) REFERENCES `Users` (`User_ID`),
  ADD CONSTRAINT `Group_Likes_ibfk_3` FOREIGN KEY (`Group_ID`) REFERENCES `Groups` (`Group_ID`);

--
-- Constraints for table `Group_Members`
--
ALTER TABLE `Group_Members`
  ADD CONSTRAINT `Group_Members_ibfk_1` FOREIGN KEY (`User_ID`) REFERENCES `Users` (`User_ID`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `Group_Members_ibfk_2` FOREIGN KEY (`Group_ID`) REFERENCES `Groups` (`Group_ID`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `Group_Post`
--
ALTER TABLE `Group_Post`
  ADD CONSTRAINT `Group_Post_ibfk_1` FOREIGN KEY (`Group_ID`) REFERENCES `Groups` (`Group_ID`),
  ADD CONSTRAINT `Group_Post_ibfk_2` FOREIGN KEY (`User_ID`) REFERENCES `Users` (`User_ID`);

--
-- Constraints for table `Group_Post_Comments`
--
ALTER TABLE `Group_Post_Comments`
  ADD CONSTRAINT `Group_Post_Comments_ibfk_1` FOREIGN KEY (`User_ID`) REFERENCES `Users` (`User_ID`),
  ADD CONSTRAINT `Group_Post_Comments_ibfk_2` FOREIGN KEY (`Post_ID`) REFERENCES `Group_Post` (`Post_ID`);

--
-- Constraints for table `Likes`
--
ALTER TABLE `Likes`
  ADD CONSTRAINT `Likes_ibfk_1` FOREIGN KEY (`Post_ID`) REFERENCES `Posts` (`Post_ID`),
  ADD CONSTRAINT `Likes_ibfk_2` FOREIGN KEY (`User_ID`) REFERENCES `Users` (`User_ID`);

--
-- Constraints for table `Messages`
--
ALTER TABLE `Messages`
  ADD CONSTRAINT `Messages_ibfk_1` FOREIGN KEY (`Sender_ID`) REFERENCES `Users` (`User_ID`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `Messages_ibfk_2` FOREIGN KEY (`Reciever_ID`) REFERENCES `Users` (`User_ID`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `Notifications`
--
ALTER TABLE `Notifications`
  ADD CONSTRAINT `Notifications_ibfk_1` FOREIGN KEY (`User_ID`) REFERENCES `Users` (`User_ID`);

--
-- Constraints for table `Posts`
--
ALTER TABLE `Posts`
  ADD CONSTRAINT `Posts_ibfk_1` FOREIGN KEY (`User_ID`) REFERENCES `Users` (`User_ID`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `Session`
--
ALTER TABLE `Session`
  ADD CONSTRAINT `Session_ibfk_1` FOREIGN KEY (`User_ID`) REFERENCES `Users` (`User_ID`) ON DELETE CASCADE ON UPDATE CASCADE;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
